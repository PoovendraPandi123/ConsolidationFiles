import { Component, OnInit } from '@angular/core';
import { VrReconReportService } from 'src/app/services/recon/vendor-recon/vr-recon-report.service';
import { NgxUiLoaderService } from "ngx-ui-loader"; // Import NgxUiLoaderService

@Component({
  selector: 'app-vr-recon-report',
  templateUrl: './vr-recon-report.component.html',
  styleUrls: ['./vr-recon-report.component.css']
})
export class VrReconReportComponent implements OnInit {

  public userModelList: any;
  public tenantId : any;
  public groupId : any;
  public entityId : any;
  public mProcessingLayerId : any;
  public mProcessingSubLayerId : any;
  public userId : any;
  public processingLayerIdsUser : any;
  public processingLayerList : any;
  public selectProcessingLayer : any;
  public processing_layer_id : Number;
  public FromDateChosen: string;
  public ToDateChosen: string;
  public reportFileGenerated: string;
  public reportDownload: boolean;

  constructor(private reportService: VrReconReportService, private ngxService: NgxUiLoaderService) {
    this.FromDateChosen = '';
    this.ToDateChosen = '';
    this.reportFileGenerated = '';
    this.reportDownload = false;
    this.processing_layer_id = 0;
   }

  ngOnInit(): void {
    this.userModelList = JSON.parse(sessionStorage.getItem("user_model_list"));
    this.userId = JSON.parse(sessionStorage.getItem("user_details"))["user_id"];
    this.tenantId = this.userModelList["tenant_id"];
    this.groupId = this.userModelList["group_id"];
    this.entityId = this.userModelList["entity_id"];
    this.mProcessingLayerId = this.userModelList["m_processing_layer_id"];
    this.mProcessingSubLayerId = this.userModelList["m_processing_sub_layer_id"];
    this.processingLayerIdsUser = this.userModelList["processing_layer_ids"];
    this.getProcessingLayerList();
    this.selectProcessingLayer = {
      "processing_layer_id":0
    };
  }

  public getProcessingLayerList() : void {
    this.ngxService.start();
    // console.log(this.userModelList);
    let data = {
      "tenantId" : this.tenantId,
      "groupId" : this.groupId,
      "entityId" : this.entityId,
      "mProcessingLayerId" : this.mProcessingLayerId,
      "mProcessingSubLayerId" : this.mProcessingSubLayerId,
      "typeId": JSON.parse(sessionStorage.getItem("user_model_list"))["type_id"]
    };

    this.reportService.getProcessingLayerListFromServer(data)
    .subscribe(
      received_data => {
        let response_data = received_data;
        console.log("Processing Layer List Response: ", response_data);
        this.processingLayerList = response_data["processing_layer_list"];
        this.ngxService.stop();
      }
    ),
    (error : any) => {
      this.HandleErrorResponse(error);
      this.ngxService.stop();
    }

  }

  public getSelectedProcessingLayer(data : any) : void {
    this.processing_layer_id = Number(data);
    this.reportDownload = false;
  }

  public reportDownloadClick() : void {
    this.reportDownload = false;
    if (this.processing_layer_id == 0)
    {
      alert("Kindly Choose Reconciliation Type!!!");
    }
    else if (this.FromDateChosen == '')
    {
      alert("Kindly Choose From Date!!!");
    }
    else if (this.ToDateChosen == '')
    {
      alert("Kindly Choose To Date!!!");
    }
    else
    {
      this.ngxService.start();
      let data = {
        "tenantId": this.tenantId,
        "groupId": this.groupId,
        "entityId": this.entityId,
        "mProcessingLayerId": this.mProcessingLayerId,
        "mProcessingSubLayerId": this.mProcessingSubLayerId,
        "processingLayerId": this.processing_layer_id,
        "reportFromDate": this.FromDateChosen,
        "reportToDate": this.ToDateChosen
      };
  
      this.reportService.getVrsReportFromServer(data)
      .subscribe(
        receivedData => {
          let responseData = receivedData;
          console.log("VRS Report Response ", responseData);
          if(responseData["Status"] == "Success")
          {
            this.reportFileGenerated = responseData["file_generated"];
            this.reportDownload = true;
            this.ngxService.stop();
          }
          else if(responseData["Status"] === "Error")
          {
            console.log("Error");
            this.ngxService.stop();
            alert("Error in Getting Report. Please Contact Advent Support!!!");
          }
          else if(responseData["Status"] === "Report Generating")
          {
            console.log("Another user is currently generating report");
            this.ngxService.stop();
            alert("Another User is Currently Generating Report. Kindly try after some time!!!");
          }
          else if(responseData["Status"] === "VNR")
          {
            console.log("Vendor Not Registered in System");
            this.ngxService.stop();
            alert("Vendor Not Registered in System. Kindly contact Advents Support!!!");
          }
        }
      ),
      (error : any) => {
        this.HandleErrorResponse(error);
        this.ngxService.stop();
      }
    }
  }

  public HandleErrorResponse(err : any) : void {
    console.log(err);
  }

}
