import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VrReconReportComponent } from './vr-recon-report.component';

describe('VrReconReportComponent', () => {
  let component: VrReconReportComponent;
  let fixture: ComponentFixture<VrReconReportComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ VrReconReportComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(VrReconReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
