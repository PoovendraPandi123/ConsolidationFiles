import { Component, OnInit, ViewChild } from '@angular/core';
import { ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { VrMatchingCommentsService } from 'src/app/services/recon/vendor-recon/vr-matching-comments.service';
import { NgxUiLoaderService } from "ngx-ui-loader"; // Import NgxUiLoaderService

@Component({
  selector: 'app-vr-matching-comments',
  templateUrl: './vr-matching-comments.component.html',
  styleUrls: ['./vr-matching-comments.component.css']
})
export class VrMatchingCommentsComponent implements OnInit {

  public paginationSize: number;
  public externalRowData: any;
  public externalColumnDefs: any;
  public pagination: boolean;
  public searchValue: string;
  public gridRowApi: any;
  public gridColumnApi: any;
  public closeResult: any;
  public comment: string;
  public matchingCommentDescription: string;
  public userModelList: any;
  public tenantId : any;
  public groupId : any;
  public entityId : any;
  public mProcessingLayerId : any;
  public mProcessingSubLayerId : any;
  public userId : any;

  constructor(private commentsService: VrMatchingCommentsService, private ngxService: NgxUiLoaderService, public modalService: NgbModal) { 
    this.paginationSize = null;
    this.externalRowData = [];
    this.externalColumnDefs = [];
    this.pagination = false;
    this.searchValue = '';
    this.gridColumnApi = [];
    this.gridRowApi = [];
    this.comment = '';
    this.matchingCommentDescription = '';
  }

  public ngOnInit(): void {
    this.paginationSize = 15;
    this.pagination = true;
    this.userModelList = JSON.parse(sessionStorage.getItem("user_model_list"));
    this.userId = JSON.parse(sessionStorage.getItem("user_details"))["user_id"];
    this.tenantId = this.userModelList["tenant_id"];
    this.groupId = this.userModelList["group_id"];
    this.entityId = this.userModelList["entity_id"];
    this.mProcessingLayerId = this.userModelList["m_processing_layer_id"];
    this.mProcessingSubLayerId = this.userModelList["m_processing_sub_layer_id"];
    this.initializeMatchingComments();
  }

  public open(content) {
    this.modalService.open(content, {ariaLabelledBy: 'modal-basic-title'}).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }

  public onGridReady(params : any) : void {
    this.gridRowApi = params.api;
    this.gridColumnApi = params.columnApi;
  }

  public onRowClicked(e : any) : void {

  }

  public quickSearch() : void {
    this.gridRowApi.setQuickFilter(this.searchValue);
  }

  public initializeMatchingComments() : void {
    this.ngxService.start();
    this.externalColumnDefs = [
      {headerName: 'Comment Name', field: 'name', sortable: true, filter: true, resizable: true},
      {headerName: 'Comment Description', field: 'description', sortable: true, filter: true, resizable: true, width: 470}
    ];

    let params = {};

    this.commentsService.getMatchingCommentsFromServer(params)
    .subscribe(
      receivedData => {
        let responseData = receivedData;
        this.externalRowData = responseData;
        this.ngxService.stop();
      }
    ),
    (error : any) => {
      this.HandleErrorResponse(error);
      this.ngxService.stop();
    }
  }

  public onSaveButtonClick() : void {
    if (this.comment == '' && this.matchingCommentDescription == '')
    {
      alert("Kindly Enter the Comment and Comment Description!!!");
    }
    else if (this.comment == '')
    {
      alert("Kindly Enter the Comment!!!");
    }
    else if (this.matchingCommentDescription == '')
    {
      alert("Kindly Enter the Matching Comment Description!!!");
    }
    else
    {
      this.ngxService.start();

      let data = {
        "tenants_id": this.tenantId,
        "groups_id": this.groupId,
        "entities_id": this.entityId,
        "m_processing_layer_id": this.mProcessingLayerId,
        "m_processing_sub_layer_id": this.mProcessingSubLayerId,
        "name": this.comment,
        "description": this.matchingCommentDescription,
        "is_active": 1,
        "created_by": this.userId,
        "created_date": "{date}",
        "modified_by": this.userId,
        "modified_date": "{date}"
      };

      this.commentsService.postMatchingCommentsToServer(data)
      .subscribe(
        receiveData => {
          let responseData = receiveData;
          console.log("Post Matching Comments Response ", responseData);
          if ("id" in responseData)
          {
            alert("Comments Added Successfully!!!");
            this.initializeMatchingComments();
            this.ngxService.stop();
          }
          else
          {
            alert("Error in Adding Comments. Please Contact Advents Support!!!");
            this.ngxService.stop();
          }
        }
      ),
      (error : any) => {
        this.HandleErrorResponse(error);
      }
    }
  }

  public HandleErrorResponse(err : any) : void {
    console.log(err);
  }

}
