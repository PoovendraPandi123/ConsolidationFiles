import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VrPeriodAssignmentComponent } from './vr-period-assignment.component';

describe('VrPeriodAssignmentComponent', () => {
  let component: VrPeriodAssignmentComponent;
  let fixture: ComponentFixture<VrPeriodAssignmentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ VrPeriodAssignmentComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(VrPeriodAssignmentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
