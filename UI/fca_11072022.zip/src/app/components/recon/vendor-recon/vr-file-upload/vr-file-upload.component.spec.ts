import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VrFileUploadComponent } from './vr-file-upload.component';

describe('VrFileUploadComponent', () => {
  let component: VrFileUploadComponent;
  let fixture: ComponentFixture<VrFileUploadComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ VrFileUploadComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(VrFileUploadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
