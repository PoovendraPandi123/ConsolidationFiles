import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { AgGridAngular } from 'ag-grid-angular';
import { BrsFileUploadService } from 'src/app/services/recon/bank-recon/brs-file-upload.service';
import { NgxUiLoaderService } from "ngx-ui-loader"; // Import NgxUiLoaderService
import { BrsFileUpload } from './brs-file-upload.model'

@Component({
  selector: 'app-brs-file-upload',
  templateUrl: './brs-file-upload.component.html',
  styleUrls: ['./brs-file-upload.component.css']
})
export class BrsFileUploadComponent implements OnInit {

  @ViewChild('externalFileInput', {static: false})
  externalFileInput: ElementRef;

  @ViewChild('internalFileInput', {static: false})
  internalFileInput : ElementRef;

  @ViewChild('agGrid')
  agGrid!: AgGridAngular;

  public userdtl;
  public sourcedata;
  public processinglayerlist;
  public objprocessid;
  public fileupload;
  public fileuploadlist;

  public paginationSize;
  public file_records;
  public pagination;
  public fileData;

  public userModelList :  any;
  public processingLayerIdsUser :  any;
  public selectProcessingLayer : any;
  public fileUploaded : any;
  public fileRowData : any;
  public fileColumnDefs :  any;

  public brsFileUpload : BrsFileUpload;

  public columnDefs = [
    { field: 'File Name', headerText: 'File Name', sortable: true, filter: true},
    { field: 'Size(mb)', sortable: true, filter: true },
    { field: 'UploadDate', sortable: true, filter: true },
    { field: 'UploadBy', sortable: true, filter: true },
    { field: 'UploadStatus', sortable: true, filter: true },
    { field: 'Validation', sortable: true, filter: true },
    { field: 'Status', sortable: true, filter: true },
    { field: 'ProcessTime', sortable: true, filter: true },
  ];

  public rowData : any;

  constructor(private fileUploadService: BrsFileUploadService, private ngxService: NgxUiLoaderService) { }

  shortLink: string = "";
  loading: boolean = false; 
  file: File = null; 

  public ngOnInit(): void {

    this.brsFileUpload = new BrsFileUpload();
    this.userModelList = JSON.parse(sessionStorage.getItem("user_model_list"));
    this.brsFileUpload.userId = JSON.parse(sessionStorage.getItem("user_details"))["user_id"];
    this.brsFileUpload.tenantId = this.userModelList["tenant_id"];
    this.brsFileUpload.groupId = this.userModelList["group_id"];
    this.brsFileUpload.entityId = this.userModelList["entity_id"];
    this.brsFileUpload.mProcessingLayerId = this.userModelList["m_processing_layer_id"];
    this.brsFileUpload.mProcessingSubLayerId = this.userModelList["m_processing_sub_layer_id"];
    this.processingLayerIdsUser = this.userModelList["processing_layer_ids"];

    this.userdtl=JSON.parse(sessionStorage.getItem('user_details'));
    this.getProcessingLayerList();
    this.selectProcessingLayer = {
      "processing_layer_id" : 0
    };
    this.getFileUploadList();

    this.pagination=true;
    this.paginationSize = 15;
    this.file_records=[];

    this.fileColumnDefs =  [
      {headerName: 'Relationship Name', field: 'processing_layer_name', resizable: true},
      {headerName: 'Extraction Type', field: 'extraction_type', resizable: true},
      {headerName: 'File Name', field: 'file_name', resizable: true},
      {headerName: 'File Size (Bytes)', field: 'file_size_bytes', resizable: true},
      {headerName: 'Status', field: 'status', resizable: true},
      {headerName: 'Comments', field: 'comments', resizable: true, width: 300},
      {headerName: 'Uploaded Date', field: 'created_date', resizable: true}
    ];

    this.getFileUploadedList();

  }

  public getProcessingLayerList() : void {
    this.ngxService.start();
    // console.log("userdetails ",this.userdtl);
    let Indata = {
      "tenantId" : this.brsFileUpload.tenantId,
      "groupId" : this.brsFileUpload.groupId,
      "entityId" : this.brsFileUpload.entityId,
      "mProcessingLayerId" : this.brsFileUpload.mProcessingLayerId,
      "mProcessingSubLayerId" : this.brsFileUpload.mProcessingSubLayerId,
      "typeId": JSON.parse(sessionStorage.getItem("user_model_list"))["type_id"]
    }
    // console.log("inputfilterrecon",Indata);
    this.fileUploadService.getProcessingLayerListFromServer(Indata)
    .subscribe(
    recieveddata  => {
      let tempresponsedata = recieveddata;
      console.log("filterlistresponse---",tempresponsedata)
      this.sourcedata=tempresponsedata;
      this.processinglayerlist=this.sourcedata.processing_layer_list;
      this.ngxService.stop();
    });
  }

  public getFileUploadList() : void {
    let Indata={
      "tenant_id": this.brsFileUpload.tenantId,
      "group_id": this.brsFileUpload.groupId,
      "entity_id": this.brsFileUpload.entityId,
      "user_id": this.brsFileUpload.userId
    }
    console.log("fileuploadlistdata",Indata);
    this.fileUploadService.getFileListFromServer(Indata).subscribe(
      recieveddata  => {
        let tempresponsedata = recieveddata;
        console.log("filelistresponse---",tempresponsedata)
        this.sourcedata=tempresponsedata;
        this.fileuploadlist=this.sourcedata.recon_file_upload_list;
        console.log("FIle Upload List ",this.fileuploadlist);
        this.rowData = this.fileuploadlist;
        this.file_records = this.fileuploadlist;
    });
  }

  public onChange(event : any) {
    this.file = event.target.files[0];
  }

  public extFileOnChanged(event:any) {
    let files = event.target.files;
    this.brsFileUpload.externalFileName = files[0];
    console.log(files);
    console.log(this.brsFileUpload.externalFileName);
  }

  public intFileOnChanged(event:any) {
    let files = event.target.files;
    this.brsFileUpload.internalFileName = files[0];
    console.log(files);
    console.log(this.brsFileUpload.internalFileName);
  }

  public uploadAll() : void {

    console.log(this.brsFileUpload.processingLayerId);
  
    if (this.brsFileUpload.processingLayerId == "0" || this.brsFileUpload.processingLayerId === undefined)
    {
      alert("Kindly choose the Reconciliation Type!!!");
    }
    else if (this.brsFileUpload.externalFileName === undefined && this.brsFileUpload.internalFileName === undefined)
    {
      alert("Kindly Choose File and Upload!!!");
    }
    else
    {
      this.ngxService.start();
  
      if(this.brsFileUpload.externalFileName !== undefined && this.brsFileUpload.internalFileName !== undefined)
      {
        this.fileUploaded = "BOTH";
      }
      else if(this.brsFileUpload.externalFileName !== undefined && this.brsFileUpload.internalFileName === undefined)
      {
        this.fileUploaded = "EXTERNAL";
      }
      else if(this.brsFileUpload.externalFileName === undefined && this.brsFileUpload.internalFileName !== undefined)
      {
        this.fileUploaded = "INTERNAL";
      }
  
      const formData = new FormData();
  
      formData.append("internalFileName", this.brsFileUpload.internalFileName);
      formData.append("externalFileName ", this.brsFileUpload.externalFileName);
      formData.append("processingLayerId", this.brsFileUpload.processingLayerId);
      formData.append("tenantId", this.brsFileUpload.tenantId);
      formData.append("groupId", this.brsFileUpload.groupId);
      formData.append("entityId", this.brsFileUpload.entityId);
      formData.append("mProcessingLayerId", this.brsFileUpload.mProcessingLayerId);
      formData.append("mProcessingSubLayerId", this.brsFileUpload.mProcessingSubLayerId);
      formData.append("userId", this.brsFileUpload.userId);
      formData.append("fileUploaded", this.fileUploaded);
  
      this.fileupload = formData;
  
      console.log("Data  ",this.fileupload);
      this.fileUploadService.postFileToServer(this.fileupload)
        .subscribe(
        recieveddata  => {   
          let tempresponsedata = recieveddata;
          console.log("Fileuploadresponse---", tempresponsedata)
          this.fileupload="";
          this.fileupload = tempresponsedata;
          if(this.fileupload.Status === "Success")
          {
            alert("File Uploaded Successfully!!!");
            this.externalFileInput.nativeElement.value = '';
            this.internalFileInput.nativeElement.value = '';
            this.brsFileUpload.externalFileName = undefined;
            this.brsFileUpload.internalFileName = undefined;
            this.getFileUploadedList();
            this.ngxService.stop();
          }
          else if(this.fileupload.Status === "Error")
          {
            alert("Error in Upload File. Kindly Contact Advents Support!!!");
            this.externalFileInput.nativeElement.value = '';
            this.internalFileInput.nativeElement.value = '';
            this.brsFileUpload.externalFileName = undefined;
            this.brsFileUpload.internalFileName = undefined;
            this.getFileUploadedList();
            this.ngxService.stop();
          }
          else if(this.fileupload.Status === "File Exists")
          {
            alert("File already exists in Batch for the choosen Relationship Type. Kindly Upload after some time!!!");
            this.externalFileInput.nativeElement.value = '';
            this.internalFileInput.nativeElement.value = '';
            this.brsFileUpload.externalFileName = undefined;
            this.brsFileUpload.internalFileName = undefined;
            this.getFileUploadedList();
            this.ngxService.stop();
          }
        },
        (error: any) => { 
          this.HandleErrorResponse(error);
          this.externalFileInput.nativeElement.value = '';
          this.internalFileInput.nativeElement.value = '';
          this.brsFileUpload.externalFileName = undefined;
          this.brsFileUpload.internalFileName = undefined;
          this.getFileUploadedList();
          this.ngxService.stop();
      });
    }
  }

  public getSelectedProcessingLayer(processingLayerId) : void {
    this.brsFileUpload.processingLayerId = processingLayerId;
  }

  public getFileUploadedList() : void {
    this.ngxService.start();
    let data = {
      "tenantId": this.brsFileUpload.tenantId,
      "groupId": this.brsFileUpload.groupId,
      "entityId": this.brsFileUpload.entityId,
      "mProcessingLayerId": this.brsFileUpload.mProcessingLayerId,
      "mProcessingSubLayerId": this.brsFileUpload.mProcessingSubLayerId,
      "userId": this.brsFileUpload.userId
    };

    this.fileUploadService.getFileListFromServer(data).subscribe(
      receivedData => {
        let responseData = receivedData;
        console.log("File Data Response, ", responseData);
        this.fileRowData = responseData;
        this.ngxService.stop();
      },
      (error : any) => {
        this.HandleErrorResponse(error);
        this.ngxService.stop();
      }
    );

  }

  public refreshFileUploadList() : void {
    this.getFileUploadedList();
  }

  public HandleErrorResponse(err : any) : void {
    console.log(err);
  }

}
