import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AlcsOperationsComponent } from './alcs-operations.component';

describe('AlcsOperationsComponent', () => {
  let component: AlcsOperationsComponent;
  let fixture: ComponentFixture<AlcsOperationsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AlcsOperationsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AlcsOperationsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
