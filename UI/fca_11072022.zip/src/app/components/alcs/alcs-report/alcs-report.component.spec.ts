import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AlcsReportComponent } from './alcs-report.component';

describe('AlcsReportComponent', () => {
  let component: AlcsReportComponent;
  let fixture: ComponentFixture<AlcsReportComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AlcsReportComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AlcsReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
