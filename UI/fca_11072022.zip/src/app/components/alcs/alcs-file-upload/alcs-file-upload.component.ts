import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { AlcsfileuploadService } from 'src/app/service/alcsfileupload.service';
import { NgxUiLoaderService } from "ngx-ui-loader"; // Import NgxUiLoaderService
import { AgGridAngular } from 'ag-grid-angular';
import { HttpClient  } from '@angular/common/http';
import { AlcsFileUpload } from 'src/app/models/alcs-file-upload-model';

@Component({
  selector: 'app-alcs-file-upload',
  templateUrl: './alcs-file-upload.component.html',
  styleUrls: ['./alcs-file-upload.component.css']
})
export class AlcsFileUploadComponent implements OnInit {

  public fileTypeList: any;
  public fileType: string;
  public alcsFileUpload: AlcsFileUpload;
  public userModelList: any;
  public fileUpload: any;
  public pagination: boolean;
  public paginationSize: number;
  public fileRowData: any;
  public fileColumnDefs: any;
  public inputDate: string;

  @ViewChild('fileInput',  {static: false}) 
  fileInput : ElementRef;

  @ViewChild('agGrid')
  agGrid!: AgGridAngular;

  constructor(private alcsFileUploadService: AlcsfileuploadService, private http: HttpClient, public ngxService: NgxUiLoaderService) 
  { 
    this.fileTypeList = [];
    this.fileType = '';
    this.userModelList = {};
    this.fileUpload = {};
    this.pagination = false;
    this.paginationSize = 0;
    this.fileRowData = [];
    this.fileColumnDefs = [];
    this.inputDate = '';
  }

  public ngOnInit(): void {
    this.alcsFileUpload = new AlcsFileUpload();

    this.userModelList = JSON.parse(sessionStorage.getItem("user_model_list"));
    this.alcsFileUpload.tenantId = this.userModelList["tenant_id"];
    this.alcsFileUpload.groupId = this.userModelList["group_id"];
    this.alcsFileUpload.entityId = this.userModelList["entity_id"];
    this.alcsFileUpload.mProcessingLayerId = this.userModelList["m_processing_layer_id"];
    this.alcsFileUpload.mProcessingSubLayerId = this.userModelList["m_processing_sub_layer_id"];
    this.alcsFileUpload.userId = JSON.parse(sessionStorage.getItem("user_details"))["user_id"];
    this.alcsFileUpload.processingLayerId = 404;

    this.initFileTypeList();
    this.getFileUploadedList();
    this.fileType = '0';
    this.pagination = true;
    this.paginationSize = 15;

    this.fileColumnDefs = [
      {headerName: 'File Type', field: 'file_upload_type', resizable: true},
      {headerName: 'Source Type', field: 'source_type', resizable: true},
      {headerName: 'ALCS Date', field: 'input_date', resizable: true},
      {headerName: 'File Name', field: 'file_name', resizable: true},
      {headerName: 'Size(bytes)', field: 'file_size_bytes', resizable: true},
      {headerName: 'Upload Status', field: 'status', resizable: true},
      {headerName: 'Comments', field: 'comments', resizable: true, width: 300},
      {headerName: 'Uploaded Date', field: 'created_date', resizable: true}
    ];

    // this.disableBackButton();
  };

  public initFileTypeList() : void {
    this.fileTypeList = this.alcsFileUploadService.getFileTypeList();
    // console.log("File Type List", this.fileTypeList);
  };

  public fileOnChange(event : any) : void {
    let files = event.target.files;
    this.alcsFileUpload.fileInputName = files[0];
  };

  public getFileTypeExtension(fileType : string) : void {
    for (var i=0; i<this.fileTypeList.length; i++)
    {
      if (this.fileTypeList[i]["fileType"] == fileType)
      {
        return this.fileTypeList[i]["extension"];
      }
    }
  };

  public getFileTypeName(fileType: string) : void {
    for (var i=0; i<this.fileTypeList.length; i++)
    {
      if(this.fileTypeList[i]["fileType"] == fileType)
      {
        return this.fileTypeList[i]["fileName"];
      }
    }
  };

  public getFileUploadedList() : void {
    this.ngxService.start()
    let params = {
      "recordCount": '100'
    }
    this.alcsFileUploadService.getFileUploadListFromServer(params)
    .subscribe(
      (receivedData : any) => {
        let responseData = receivedData;
        // console.log("Response Data File List", responseData);
        let rowData = responseData;
        rowData.forEach((item, index) => {
          let date = item['created_date'].split("T")[0];
          item["created_date"] = date.split("-")[2] + "/" + date.split("-")[1] + "/" + date.split("-")[0];
          item["input_date"] = item["input_date"].split("-")[2] + "/" + item["input_date"].split("-")[1] + "/" + item["input_date"].split("-")[0];
          item["file_upload_type"] = this.getFileTypeName(item["file_upload_type"]);
        });
        this.fileRowData = responseData;
        this.ngxService.stop();
      },
      (error : any) => {
        this.HandleErrorResponse(error);
        this.ngxService.stop();
      }
    )
  };

  public refreshFileUploadList() : void {
    this.getFileUploadedList();
  }

  public postFile() : void {
    if (this.fileType == '0')
    {
      alert("Please choose File Type for Upload!!!");
    }
    else if (this.inputDate == '')
    {
      alert("Please Choose the Input Date!!!");
    }
    else if (this.alcsFileUpload.fileInputName === undefined)
    {
      alert("Please Choose the File for Upload!!!");
    }
    else if(this.alcsFileUpload.fileInputName.name.split(".")[this.alcsFileUpload.fileInputName.name.split(".").length - 1] == this.getFileTypeExtension(this.fileType))
    {
      this.ngxService.start();
      const formData = new FormData();

      formData.append("fileName", this.alcsFileUpload.fileInputName);
      formData.append("processingLayerId", this.alcsFileUpload.processingLayerId);
      formData.append("tenantsId", this.alcsFileUpload.tenantId);
      formData.append("groupsId", this.alcsFileUpload.groupId);
      formData.append("entityId", this.alcsFileUpload.entityId);
      formData.append("mProcessingLayerId", this.alcsFileUpload.mProcessingLayerId);
      formData.append("mProcessingSubLayerId", this.alcsFileUpload.mProcessingSubLayerId);
      formData.append("userId", this.alcsFileUpload.userId);
      formData.append("fileUploadType", this.fileType);
      formData.append("inputDate", this.inputDate);
  
      this.fileUpload = formData;
      
      this.alcsFileUploadService.postFileToServer(this.fileUpload)
      .subscribe(
        receivedData => {
          let responseData = receivedData;
          if (responseData["Status"] == "Success")
          {
            alert("File Uploaded Successfully!!!");
            this.fileInput.nativeElement.value = '';
            this.alcsFileUpload.fileInputName = undefined;
            this.getFileUploadedList();
            this.ngxService.stop();
          }
          else if (responseData["Status"] == "Error")
          {
            alert("Error in File Upload. Please Contact Advents Support!!!");
            this.fileInput.nativeElement.value = '';
            this.alcsFileUpload.fileInputName = undefined;
            this.ngxService.stop();
          }
          else if (responseData["Status"] == "Exists")
          {
            alert("File Already Exists in BATCH!!!");
            this.fileInput.nativeElement.value = '';
            this.alcsFileUpload.fileInputName = undefined;
            this.ngxService.stop();
          }
        }
      ),
      (error : any) => {
        this.HandleErrorResponse(error);
        this.fileInput.nativeElement.value = '';
        this.alcsFileUpload.fileInputName = undefined;
      };
    }
    else
    {
      alert("Please choose Proper File for the chosen File Type!!!");
    }
  };

  public HandleErrorResponse(err : any) : void {
    console.log("Error", err);
  };

  public disableBackButton() : void {
    window.onpopstate = function (e) { 
      window.history.forward(); 
    }
  };

}
