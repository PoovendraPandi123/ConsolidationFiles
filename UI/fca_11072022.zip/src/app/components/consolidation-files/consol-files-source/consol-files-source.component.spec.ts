import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ConsolFilesSourceComponent } from './consol-files-source.component';

describe('ConsolFilesSourceComponent', () => {
  let component: ConsolFilesSourceComponent;
  let fixture: ComponentFixture<ConsolFilesSourceComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ConsolFilesSourceComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ConsolFilesSourceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
