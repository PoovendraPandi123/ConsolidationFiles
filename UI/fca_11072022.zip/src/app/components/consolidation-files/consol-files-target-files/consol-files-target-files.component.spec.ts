import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ConsolFilesTargetFilesComponent } from './consol-files-target-files.component';

describe('ConsolFilesTargetFilesComponent', () => {
  let component: ConsolFilesTargetFilesComponent;
  let fixture: ComponentFixture<ConsolFilesTargetFilesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ConsolFilesTargetFilesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ConsolFilesTargetFilesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
