import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-consol-files-dashboard',
  templateUrl: './consol-files-dashboard.component.html',
  styleUrls: ['./consol-files-dashboard.component.css']
})
export class ConsolFilesDashboardComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
