import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-consol-files-draft-report',
  templateUrl: './consol-files-draft-report.component.html',
  styleUrls: ['./consol-files-draft-report.component.css']
})
export class ConsolFilesDraftReportComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
