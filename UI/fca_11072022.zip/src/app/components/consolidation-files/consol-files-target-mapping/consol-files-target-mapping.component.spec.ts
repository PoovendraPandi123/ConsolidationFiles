import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ConsolFilesTargetMappingComponent } from './consol-files-target-mapping.component';

describe('ConsolFilesTargetMappingComponent', () => {
  let component: ConsolFilesTargetMappingComponent;
  let fixture: ComponentFixture<ConsolFilesTargetMappingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ConsolFilesTargetMappingComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ConsolFilesTargetMappingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
