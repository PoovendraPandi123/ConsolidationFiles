import { Component, OnInit } from '@angular/core';
import { NgxUiLoaderService } from "ngx-ui-loader"; // Import NgxUiLoaderService
import { ITargetDefinitionMapping } from './consol-files-target-mapping.model';
import { ConsolFilesTargetMappingService } from 'src/app/service/consol-files-target-mapping.service';

@Component({
  selector: 'app-consol-files-target-mapping',
  templateUrl: './consol-files-target-mapping.component.html',
  styleUrls: ['./consol-files-target-mapping.component.css']
})
export class ConsolFilesTargetMappingComponent implements OnInit {

  public targetDefinitionsMappingList: ITargetDefinitionMapping[];
  public isTargetDefinitionRequired: boolean[];
  public userModelList: any;
  public userDetails: any;
  public tenantId: number;
  public groupId: number;
  public entityId: number;
  public mProcessingLayerId: number;
  public mProcessingSubLayerId: number;
  public processingLayerId: number;
  public userId: any;
  public targetList: any;
  public targetDefinitionsList: any;
  public targetChosenId: string;
  public targetDefinitionChosenId: string;
  public sourceList: any;
  public sourceDefinitionsList: any;
  public sourceIdChosen: any;
  public requiredTargetDefinitionsMappingList: any;
  public createEnable: boolean;
  public pagination: boolean;
  public paginationSize: number;
  public targetRowData: any;
  public targetColumDefs: any;

  constructor(private ngxService: NgxUiLoaderService, private mappingService: ConsolFilesTargetMappingService) { 
    this.targetDefinitionsMappingList = [];
    this.isTargetDefinitionRequired = [];
    this.userModelList = [];
    this.userDetails = [];
    this.tenantId = null;
    this.groupId = null;
    this.entityId = null;
    this.mProcessingLayerId = null;
    this.mProcessingSubLayerId = null;
    this.processingLayerId = null;
    this.userId = null;
    this.targetList = [];
    this.targetDefinitionsList = [];
    this.targetChosenId = '-1';
    this.targetDefinitionChosenId = '-1';
    this.sourceList = [];
    this.sourceDefinitionsList = [];
    this.sourceIdChosen = '-1';
    this.requiredTargetDefinitionsMappingList = [];
    this.createEnable = false;
    this.pagination = false;
    this.paginationSize = null;
    this.targetRowData = [];
    this.targetColumDefs = [];
  }

  public ngOnInit(): void {
    this.userModelList = JSON.parse(sessionStorage.getItem('user_model_list'));
    this.userDetails = JSON.parse(sessionStorage.getItem('user_details'));
    this.userId = this.userDetails["user_id"];
    this.tenantId = this.userModelList["tenant_id"];
    this.groupId = this.userModelList["group_id"];
    this.entityId = this.userModelList["entity_id"];
    this.mProcessingLayerId = this.userModelList["m_processing_layer_id"];
    this.mProcessingSubLayerId = this.userModelList["m_processing_sub_layer_id"];
    this.processingLayerId = 1000;
    this.createEnable = false;
    this.pagination = true;
    this.paginationSize = 15;
    this.getSourceList();
    this.getTargetList();
    this.setFileColumnDefs();
    this.setDefaultTableMapping();
  }

  public setDefaultTableMapping() : void {
    this.targetDefinitionsMappingList = [
      {
        sourceId: "-1",
        sourceDefinitionId: "-1"
      }
    ];
    this.isTargetDefinitionRequired = [true];
    this.sourceDefinitionsList = [[]];
  }

  public getSourceList() : void {

    this.ngxService.start();

    let params = {
      "tenants_id": this.tenantId,
      "groups_id": this.groupId,
      "entities_id": this.entityId,
      "m_processing_layer_id": this.mProcessingLayerId,
      "m_processing_sub_layer_id": this.mProcessingSubLayerId,
      "processing_layer_id": this.processingLayerId
    };
    this.mappingService.getActiveSourceListFromServer(params)
    .subscribe(
      (receivedData : any) => {
        let responseData = receivedData;
        console.log("Get Source List Response ", responseData);
        this.sourceList = responseData;
        this.ngxService.stop();
      }
    ),
    (error : any) => {
      this.HandleErrorResponse(error);
      this.ngxService.stop();
    }
  }

  public getTargetList() : void {
    this.addButtonClick();
    this.ngxService.start();
    let data = {
      "tenants_id": this.tenantId,
      "groups_id": this.groupId,
      "entities_id": this.entityId,
      "m_processing_layer_id": this.mProcessingLayerId,
      "m_processing_sub_layer_id": this.mProcessingSubLayerId,
      "processing_layer_id": this.processingLayerId,
      "is_active": "yes"
    };

    this.mappingService.getTragetListFromServer(data)
    .subscribe(
      (receivedData : any) => {
        let responseData = receivedData;
        console.log("Get Target List Response ", responseData);
        this.targetList = responseData;
        this.ngxService.stop();
      }
    ),
    (error : any) => {
      this.HandleErrorResponse(error);
      this.ngxService.stop();
    }

  }

  public targetChange() : void {
    console.log("Target Chosen Id", this.targetChosenId);
    if (this.targetChosenId != '-1')
    {
      this.ngxService.start();
      let prminputs = {
        "tenants_id": this.tenantId,
        "groups_id": this.groupId,
        "entities_id": this.entityId,
        "m_processing_layer_id": this.mProcessingLayerId,
        "m_processing_sub_layer_id": this.mProcessingSubLayerId,
        "processing_layer_id": this.processingLayerId,
        "target_files_id": this.targetChosenId,
        "is_active": "yes",
      };

      this.mappingService.getTargetDefinitionListFromServer(prminputs)
      .subscribe({
        next : (receivedData : any) => {
          let responseData = receivedData;
          console.log("Get Target Definitions List Response ", responseData);
          let targetFileDefinitions = responseData;
          this.targetDefinitionsList = targetFileDefinitions;
          this.ngxService.stop();
          // window.location.reload();
        },
        error : (error : any) => {
          console.log("Get Target Definition List Error ", error);
          this.ngxService.stop();
        }
      });
    }
    else if (this.targetChosenId == '-1')
    {
      this.targetDefinitionChosenId = '-1';
    }
  }

  public addButtonClick() : void {
    this.targetDefinitionsMappingList.push(
      {
        sourceId: "-1",
        sourceDefinitionId: "-1"
      }
    );
    this.isTargetDefinitionRequired.push(true);
    this.sourceDefinitionsList.push([]);
  }

  public deleteTargetDefinitionClick(index : number) : void {
    this.isTargetDefinitionRequired[index] = false;
  }

  public sourceChange(sourceId : any, index : any) : void {
    // console.log("Source Index", index);
    // console.log("Source Change", sourceId);
    if (sourceId != "-1")
    {
      this.sourceIdChosen = sourceId;

      let prminputs = {
        "tenants_id": this.tenantId,
        "groups_id": this.groupId,
        "entities_id": this.entityId,
        "m_processing_layer_id": this.mProcessingLayerId,
        "m_processing_sub_layer_id": this.mProcessingSubLayerId,
        "processing_layer_id": this.processingLayerId,
        "sources_id": this.sourceIdChosen,
        "is_active": "yes"
      };

      this.mappingService.getSourceDefinitionsListFromServer(prminputs)
      .subscribe({
        next : (receivedData : any) => {
          let responseData = receivedData;
          console.log("Get Source Definitions List Response ", responseData);
          let sourceDefinitions = responseData;
          this.sourceDefinitionsList[index] = sourceDefinitions;
          // this.ngxService.stop();
          // window.location.reload();
        },
        error : (error : any) => {
          console.log("Get Source Definition List Error ", error);
          // this.ngxService.stop();
        }
      });

      // for (var i=0; i<this.sourceList.length; i++)
      // {
      //   if (sourceId == this.sourceList[i]["id"])
      //   {
      //     this.sourceDefinitionsList[index] = this.sourceList[i]["source_definitions"];
      //   }
      // }
    }
  }

  public sourceDefinitionChange(sourceDefinitionId : any, index : any) : void {
    this.targetDefinitionsMappingList[index] = {
      sourceId: this.sourceIdChosen,
      sourceDefinitionId: sourceDefinitionId
    };

  }

  public targetMappingSaveClick() : void {

    let requiredTargetDefinitionsMappingList = [];

    for (var i=0; i<this.targetDefinitionsMappingList.length; i++)
    {
      if (this.isTargetDefinitionRequired[i])
      {
        requiredTargetDefinitionsMappingList.push(this.targetDefinitionsMappingList[i]);
      }
    }

    this.requiredTargetDefinitionsMappingList = requiredTargetDefinitionsMappingList;

    if (this.targetChosenId == "-1")
    {
      alert("Kindly choose Target Name!!!");
    }
    else if (this.targetDefinitionChosenId == "-1")
    {
      alert("Kindly choose Target Definition Column Name!!!");
    }
    else
    {

      var targetDefinitionMappingOut = this.targetDefinitionMappingCheck();

      if (targetDefinitionMappingOut)
      {
        var targetMappingOut = this.targetMappingCheck();
      }
      else
      {
        var targetMappingOut = false;
      };

      var targetDefinitionMappingRowsSourceCheck = this.targetDefinitionMappingRowsSourceCheck();

      if (targetDefinitionMappingRowsSourceCheck)
      {
        alert("Kindly Check the Source Mapped. One of the source is defined twice in the added rows!!!");
      }
      else if (targetMappingOut && targetDefinitionMappingOut)
      {
        this.ngxService.start();
        let params = {
          "target_id": this.targetChosenId,
          "target_def_id": this.targetDefinitionChosenId,
          "target_def_list": this.requiredTargetDefinitionsMappingList
        };

        this.mappingService.getCreateTargetMappingToServer(params)
        .subscribe(
          (receivedData : any) => {
            let responseData = receivedData;
            console.log("Create Target Mapping Response ", responseData);
            if (responseData["Status"] == "Success")
            {
              this.setDefaultTableMapping();
              this.targetDefinitionChosenId = '-1';
              alert("Data Saved Successfully!!!");
              this.ngxService.stop();
            }
            else if (responseData["Status"] == "Error")
            {
              alert("Error in Mapping Target Definition. Kindly Contact Advents Support!!!");
              this.ngxService.stop();
            }
          }
        ),
        (error : any) => {
          this.HandleErrorResponse(error);
          this.ngxService.stop();
        }
      };
    }
  }

  public targetMappingCheck() : boolean {
    let sourceChosenCount = 0;
    for (var i=0; i<this.requiredTargetDefinitionsMappingList.length; i++)
    {
      if (this.requiredTargetDefinitionsMappingList[i]["sourceId"] == "-1")
      {
        alert("Kindly choose Source Name -" + String(i+1) + "- Row!!!");
      }
      else
      {
        sourceChosenCount = sourceChosenCount + 1;
      }
    }
    
    if (sourceChosenCount == this.requiredTargetDefinitionsMappingList.length)
    {
      return true;
    }
    else
    {
      return false;
    }
  }

  public targetDefinitionMappingCheck() : boolean {
    let sourceDefinitionChosenCount = 0;
    for (var i=0; i<this.requiredTargetDefinitionsMappingList.length; i++)
    {
      if (this.requiredTargetDefinitionsMappingList[i]["sourceDefinitionId"] == "-1")
      {
        alert("Kindly choose Source Definition Name -" + String(i+1) + "- Row!!!");
      }
      else
      {
        sourceDefinitionChosenCount = sourceDefinitionChosenCount + 1;
      }
    }

    if (sourceDefinitionChosenCount == this.requiredTargetDefinitionsMappingList.length)
    {
      return true;
    }
    else
    {
      return false;
    }
  }

  public targetDefinitionMappingRowsSourceCheck() : boolean {

    // console.log("requiredTargetDefinitionsMappingList", this.requiredTargetDefinitionsMappingList);

    let sourceIds = [];

    for (var i=0; i<this.requiredTargetDefinitionsMappingList.length; i++)
    {
      sourceIds.push(this.requiredTargetDefinitionsMappingList[i]["sourceId"]);
    };

    // console.log("sourceIds", sourceIds);

    var duplicateSourceIds = sourceIds.reduce(function(acc, el, i, arr) {
      if (arr.indexOf(el) !== i && acc.indexOf(el) < 0) acc.push(el); return acc;
    }, []);

    // console.log("duplicateSourceIds", duplicateSourceIds);

    if (duplicateSourceIds.length == 0)
    {
      return false;
    }
    else
    {
      return true;
    }

  }

  public onGridReady(event : any) : void {

  }

  public setFileColumnDefs() : void {
    this.targetColumDefs = [
      {
        headerName: 'Action',
        width: 80,
        template:
        `
        <a>
          <i class='far fa-edit' data-action-type="Edit" title="Edit" aria-hidden="true"></i>
        </a>
        `
      },
      {headerName: 'Target', field: 'target', sortable: true, filter: true, resizable: true, width: 150},
      {headerName: 'Mapping Details', field: 'mapping', sortable: true, filter: true, resizable: true, width: 1100},
    ]
  }


  public targetChangeList() : void {
    this.ngxService.start();

    let prminputs = {
      "tenants_id": this.tenantId,
      "groups_id": this.groupId,
      "entities_id": this.entityId,
      "m_processing_layer_id": this.mProcessingLayerId,
      "m_processing_sub_layer_id": this.mProcessingSubLayerId,
      "processing_layer_id": this.processingLayerId,
      "target_files_id": this.targetChosenId
    };

    this.mappingService.getTargetMappingDetailsFromServer(prminputs)
    .subscribe({
      next : (receivedData : any) => {
        let responseData = receivedData;
        console.log("Traget Mapping Details From Server Response ", responseData);
        let data = responseData["data"];
        let targetRowData = [];

        
        for (var i=0; i<data.length; i++)
        {
            let mappingList = [];
            for (var j=0; j<data[i]["mapping"].length; j++)
            {
              mappingList.push(
                data[i]["mapping"][j]["Source Name"] + " : " + data[i]["mapping"][j]["Source Def Name"] + ", "
              )
            };
            targetRowData.push(
              {
                "target": data[i]["target"],
                "mapping": mappingList
              }
            );
        };

        console.log("After Mapping to string", targetRowData);

        this.targetRowData = targetRowData;
        this.ngxService.stop();
      },
      error : (error : any) => {
        let responseError = error;
        console.log("Target Mapping Details Error ", responseError);
        this.ngxService.stop();
      }
    });

  }

  public targetMappingCreateClick() : void {
    this.createEnable = true;
  }

  public targetMappingListClick() : void {
    this.createEnable = false;
  }

  public HandleErrorResponse(error : any) : void {
    console.log(error);
  }

}
