import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AsTanReportComponent } from './as-tan-report.component';

describe('AsTanReportComponent', () => {
  let component: AsTanReportComponent;
  let fixture: ComponentFixture<AsTanReportComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AsTanReportComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AsTanReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
