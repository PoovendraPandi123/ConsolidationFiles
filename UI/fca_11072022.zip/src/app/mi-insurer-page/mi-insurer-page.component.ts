import { Component, OnInit, ViewChild } from '@angular/core';
import { MIInsurer } from './mi-insurer.model';
import { HttpClient  } from '@angular/common/http';
import { AuthService } from '../service/mi.auth.service';
import { NgxUiLoaderService } from "ngx-ui-loader"; // Import NgxUiLoaderService
import { AgGridAngular } from 'ag-grid-angular';
import { ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-mi-insurer-page',
  templateUrl: './mi-insurer-page.component.html',
  styleUrls: ['./mi-insurer-page.component.css']
})
export class MiInsurerPageComponent implements OnInit {

  @ViewChild('agGrid')
  agGrid!: AgGridAngular;

  public miInsurer : MIInsurer

  public selectedInsurerRow : any;
  public selectedClientRow : any;
  public selectedMailIdRow : any;
  public insurerName : any;
  public clientName : any;
  public closeResult : any;

  constructor(public http:HttpClient, public obj_auth_service: AuthService, public ngxService: NgxUiLoaderService, public modalService: NgbModal) { }

  ngOnInit(): void {
    this.miInsurer = new MIInsurer();
    this.miInsurer.userModelList = JSON.parse(sessionStorage.getItem("user_model_list"));
    this.miInsurer.userId = JSON.parse(sessionStorage.getItem("user_details"))["user_id"];
    this.miInsurer.tenantId = this.miInsurer.userModelList["tenant_id"];
    this.miInsurer.groupId = this.miInsurer.userModelList["group_id"];
    this.miInsurer.entityId = this.miInsurer.userModelList["entity_id"];
    this.miInsurer.mProcessingLayerId = this.miInsurer.userModelList["m_processing_layer_id"];
    this.miInsurer.mProcessingSubLayerId = this.miInsurer.userModelList["m_processing_sub_layer_id"];
    this.miInsurer.processingLayerId = 600;
    this.miInsurer.pagination = true;
    this.miInsurer.paginationSize = 20;
    this.miInsurer.policyStartDateAdd = 'Empty';
    this.miInsurer.policyEndDateAdd = 'Empty';
    this.getInsuerDetails();
  };

  getInsuerDetails()
  {
    this.ngxService.start();
    let data = {
      "tenantId" : this.miInsurer.tenantId,
      "groupId" : this.miInsurer.groupId,
      "entityId" : this.miInsurer.entityId,
      "mProcessingLayerId" : this.miInsurer.mProcessingLayerId,
      "mProcessingSubLayerId" : this.miInsurer.mProcessingSubLayerId
    };

    this.obj_auth_service.getMasterDetailsFromServer(data)
    .subscribe(
      receivedData => {
        let responseData = receivedData;
        // console.log(responseData);
        if (responseData["Status"] === "Success")
        {

          let insurerRowData = responseData["data"]["insurer_details"]["data"];
          let insurerColumnDefs = responseData["data"]["insurer_details"]["headers"];

          insurerColumnDefs.forEach((item, index) => {
            if(item.sortable=="true"){
              if(index === 0){
                item["checkboxSelection"] = true;
                item["maxWidth"] = 40;
                item["pinned"] = 'left';
                item.sortable=true;
                item.filter=false;
                item.resizable=false;
                item.suppressAutoSize=true;
                item.suppressSizeToFit=true;
                item.lockPosition=true;
              }
              else if (index !== 0){
                item.sortable=true;
                item.filter=true;
                item.resizable=true;
                item.suppressAutoSize=true;
                item.suppressSizeToFit=true;
                item["minWidth"] = 50;
                item["width"] = 380;
              }
  
              // Hiding
              if (item.field === "id")
              {
                item["hide"] = true;
              }
            }
          });

          this.miInsurer.insurerColumnDefs = insurerColumnDefs;
          this.miInsurer.insurerRowData = insurerRowData

          this.ngxService.stop();
        }
      },
      (error:any) => {
        this.HandleErrorResponse(error);
        this.ngxService.stop();
      }
    )

  };

  onInsurerSelectionChanged(params)
  {
    let selectedInsurerRow = params.api.getSelectedRows();
    if (selectedInsurerRow.length == 0)
    {
      this.miInsurer.insurerEditButtonDisabled = true;
      this.miInsurer.insurerClientDetailsButtonDisabled = true;
      this.miInsurer.insurerAddButtonDisabled = false;
      this.miInsurer.clientAndMailIdSide = false;
      this.miInsurer.clientDetailsDisplay = false;
      this.miInsurer.mailIdDisplay = false;
    }
    else if (selectedInsurerRow.length > 0)
    {
      this.miInsurer.insurerEditButtonDisabled = false;
      this.miInsurer.insurerClientDetailsButtonDisabled = false;
      this.miInsurer.insurerAddButtonDisabled = true;
      this.miInsurer.clientAndMailIdSide = true;
      this.miInsurer.clientDetailsDisplay = true;
      this.miInsurer.mailIdDisplay = false;
      this.selectedInsurerRow = selectedInsurerRow;
      this.getClientDetails();
      this.miInsurer.clientAddButtonDisabled = false;
      this.insurerName = selectedInsurerRow[0]["insurer_name"];
      this.miInsurer.insurerNameEdit = this.insurerName;
    };
  };

  onClientDetailsSelectionChanged(params)
  {
    let selectedClientRow = params.api.getSelectedRows();
    if (selectedClientRow.length == 0)
    {
      this.miInsurer.clientAddButtonDisabled = false;
      this.miInsurer.clientEditButtonDisabled = true;
      this.miInsurer.clientMailIdButtonDisabled = true;
      this.miInsurer.mailIdDisplay = false;
    }
    else if (selectedClientRow.length > 0)
    {
      this.miInsurer.clientAddButtonDisabled = true;
      this.miInsurer.clientEditButtonDisabled = false;
      this.miInsurer.clientMailIdButtonDisabled = false;
      this.selectedClientRow = selectedClientRow;
      this.miInsurer.mailIdDisplay = true;
      this.getMailId();
      this.miInsurer.mailIdAddButtonDisabled = false;
      this.clientName = selectedClientRow[0]["client_details"];
    }
  }

  onMailIdSelectionChanged(params)
  {
    let selectedMailId = params.api.getSelectedRows();
    this.selectedMailIdRow = selectedMailId;
    if (selectedMailId.length == 0)
    {
      this.miInsurer.mailIdEditButtonDisabled = true;
      this.miInsurer.mailIdAddButtonDisabled = false;
    }
    else if (selectedMailId.length > 0)
    {
      this.miInsurer.mailIdEditButtonDisabled = false;
      this.miInsurer.mailIdAddButtonDisabled = true;
      this.miInsurer.mailAddressEdit = this.selectedMailIdRow[0]["email_address"];
    }
  }

  getClientDetails()
  {
    this.ngxService.start();
    let insurerId = this.selectedInsurerRow[0]["id"];
    this.miInsurer.insurerId = insurerId;
    let data = {
      "tenantId" : this.miInsurer.tenantId,
      "groupId" : this.miInsurer.groupId,
      "entityId" : this.miInsurer.entityId,
      "mProcessingLayerId" : this.miInsurer.mProcessingLayerId,
      "mProcessingSubLayerId" : this.miInsurer.mProcessingSubLayerId,
      "insurerId" : insurerId
    };

    this.obj_auth_service.getClientDetailsListFromServer(data)
    .subscribe(
      receivedData => {
        let responseData = receivedData;
        // console.log(responseData);
        if (responseData["Status"] === "Success")
        {
          let clientRowData = responseData["data"]["client_details"]["data"];
          let clientColumnDefs = responseData["data"]["client_details"]["headers"];
          
          clientColumnDefs.forEach((item, index) => {
            if(item.sortable=="true"){
              if(index === 0){
                item["checkboxSelection"] = true;
                item["maxWidth"] = 40;
                item["pinned"] = 'left';
                item.sortable=true;
                item.filter=false;
                item.resizable=false;
                item.suppressAutoSize=true;
                item.suppressSizeToFit=true;
                item.lockPosition=true;
              }
              else if (index !== 0){
                item.sortable=true;
                item.filter=true;
                item.resizable=true;
                item.suppressAutoSize=true;
                item.suppressSizeToFit=true;
                item["minWidth"] = 50;
              }
  
              // Hiding
              if (item.field === "id" || item.field === "policy_start_date_changed" || item.field === "policy_end_date_changed")
              {
                item["hide"] = true;
              }
            }
          });

          this.miInsurer.clientRowData = clientRowData;
          this.miInsurer.clientColumnDefs = clientColumnDefs;
          this.ngxService.stop();
        };
      },
      (error:any) => {
        this.HandleErrorResponse(error);
        this.ngxService.stop();
      }
    );

  };

  getMailId()
  {
    this.ngxService.start();
    let clientId = this.selectedClientRow[0]["id"];
    let insurerId = this.selectedInsurerRow[0]["id"];
    this.miInsurer.clientNameEdit = this.selectedClientRow[0]["client_details"];
    this.miInsurer.policyStartDateEdit = this.selectedClientRow[0]["policy_start_date_changed"];
    this.miInsurer.policyEndDateEdit = this.selectedClientRow[0]["policy_end_date_changed"];
    this.miInsurer.addressEdit = this.selectedClientRow[0]["insurer_address"];
    this.miInsurer.gstNumberEdit = this.selectedClientRow[0]["insurer_gst_number"];
    this.miInsurer.clientId = clientId;
    let data = {
      "tenantId" : this.miInsurer.tenantId,
      "groupId" : this.miInsurer.groupId,
      "entityId" : this.miInsurer.entityId,
      "mProcessingLayerId" : this.miInsurer.mProcessingLayerId,
      "mProcessingSubLayerId" : this.miInsurer.mProcessingSubLayerId,
      "insurerId" : insurerId,
      "clientId" : clientId
    };

    this.obj_auth_service.getMailIdListFromServer(data)
    .subscribe(
      receivedData => {
        let responseData = receivedData;
        if (responseData["Status"] === "Success")
        {
          let mailRowData = responseData["data"]["mail_id"]["data"];
          let mailColumnDefs = responseData["data"]["mail_id"]["headers"];
          mailColumnDefs.forEach((item, index) => {
            if(item.sortable=="true"){
              if(index === 0){
                item["checkboxSelection"] = true;
                item["maxWidth"] = 40;
                item["pinned"] = 'left';
                item.sortable=true;
                item.filter=false;
                item.resizable=false;
                item.suppressAutoSize=true;
                item.suppressSizeToFit=true;
                item.lockPosition=true;
              }
              else if (index !== 0){
                item.sortable=true;
                item.filter=true;
                item.resizable=true;
                item.suppressAutoSize=true;
                item.suppressSizeToFit=true;
                item["minWidth"] = 50;
                item["width"] = 380;
              }
  
              // Hiding
              if (item.field === "id")
              {
                item["hide"] = true;
              }
            }
          });

          this.miInsurer.mailRowData = mailRowData;
          this.miInsurer.mailColumnDefs = mailColumnDefs;
          this.ngxService.stop();
        }
      },
      (error : any) => {
        this.HandleErrorResponse(error);
        this.ngxService.stop();
      }
    )

  }

  onInsuerGridReady(params)
  {
    this.miInsurer.insurerGridApi = params.api;
    this.miInsurer.insurerGridColumnApi = params.columnApi;
  };

  onClientGridReady(params)
  {
    this.miInsurer.clientGridApi = params.api;
    this.miInsurer.clientGridColumnApi = params.columnApi;
  };

  onMailGridReady(params)
  {
    this.miInsurer.mailIdGridApi = params.api;
    this.miInsurer.mailIdGridColumnApi = params.columnApi;
  };

  onInsurerExportButtonClick()
  {
    const params = {
      columnGroups: true,
      allColumns: true,
      fileName: 'InsuerList.csv'
    };
    this.miInsurer.insurerGridApi.exportDataAsCsv(params);
  };

  onClientExportButtonClick()
  {
    const params = {
      columnGroups: true,
      allColumns: false,
      fileName: 'ClientDetails_' + this.insurerName.replaceAll(" ", "_") + "_" + '.csv'
    };
    this.miInsurer.clientGridApi.exportDataAsCsv(params);
  };

  onMailExportButtonClick()
  {
    const params = {
      columnGroups: true,
      allColumns: false,
      fileName: 'MailAddress_' + this.clientName.replaceAll(" ", "_") + "_" + '.csv'
    };
    this.miInsurer.mailIdGridApi.exportDataAsCsv(params);
  };

  InsurerAddModelopen(content) {
    this.modalService.open(content, {ariaLabelledBy: 'modal-insurer-add'}).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  };

  InsurerEditModalOpen(content) {
    this.modalService.open(content, {ariaLabelledBy: 'modal-insurer-edit'}).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  };

  ClientAddModalOpen(content) {
    this.modalService.open(content, {ariaLabelledBy: 'modal-client-add'}).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  ClientEditModalOpen(content) {
    this.modalService.open(content, {ariaLabelledBy: 'modal-client-edit'}).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  MailIdAddModalOpen(content) {
    this.modalService.open(content, {ariaLabelledBy: 'modal-mailId-add'}).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  MailIdEditModalOpen(content) {
    this.modalService.open(content, {ariaLabelledBy: 'modal-mailId-edit'}).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  };

  onInsurerAddSaveButtonClick()
  {
    console.log("Insurer Name Add ", this.miInsurer.insurerNameAdd);
    if (this.miInsurer.insurerNameAdd == '')
    {
      alert("Please Add Insurer Name!!!");
    }
    else if (this.miInsurer.insurerNameAdd != '')
    {
      this.ngxService.start();
      let data = {
        "tenantId" : this.miInsurer.tenantId,
        "groupId" : this.miInsurer.groupId,
        "entityId" : this.miInsurer.entityId,
        "mProcessingLayerId" : this.miInsurer.mProcessingLayerId,
        "mProcessingSubLayerId" : this.miInsurer.mProcessingSubLayerId,
        "processingLayerId" : this.miInsurer.processingLayerId,
        "userId" : this.miInsurer.userId,
        "insurerName" : this.miInsurer.insurerNameAdd
      };
      
      this.obj_auth_service.postInsurerNameToServer(data)
      .subscribe(
        receivedData => {
          let responseData = receivedData;
          if (responseData["Status"] === "Success")
          {
            alert("Insurer Name Added Successfully!!!");
            this.miInsurer.insurerNameAdd = '';
            this.getInsuerDetails();
            this.ngxService.stop();
          }
          else if (responseData["Status"] === "Error")
          {
            alert("Error in Adding Insurer Name. Kindly contact Advents Support!!!");
            this.ngxService.stop();
          }
        },
        (error : any) => {
          this.HandleErrorResponse(error);
          this.ngxService.stop();
        }
      )
    }
  }

  onInsurerEditSaveButtonClick()
  {
    if (this.miInsurer.insurerNameEdit == "")
    {
      alert("Insuer Name Cannot be Empty!!!");
    }
    else if (this.miInsurer.insurerActiveStatus == "")
    {
      alert("Please Choose the Insuer Status whether active or not!!!");
    }
    else
    {
      this.ngxService.start();
      let data = {
        "tenantId" : this.miInsurer.tenantId,
        "groupId" : this.miInsurer.groupId,
        "entityId" : this.miInsurer.entityId,
        "mProcessingLayerId" : this.miInsurer.mProcessingLayerId,
        "mProcessingSubLayerId" : this.miInsurer.mProcessingSubLayerId,
        "processingLayerId" : this.miInsurer.processingLayerId,
        "userId" : this.miInsurer.userId,
        "insurerId" : this.miInsurer.insurerId,
        "insurerName" : this.miInsurer.insurerNameEdit,
        "insurerActiveStatus" : this.miInsurer.insurerActiveStatus
      };

      this.obj_auth_service.updateInsurerNameToServer(data)
      .subscribe(
        receivedData => {
          let responseData = receivedData;
          if (responseData["Status"] === "Success")
          {
            alert("Insurer Details Updated Successfully!!!");
            this.getInsuerDetails();
            this.ngxService.stop();
          }
          else if (responseData["Status"] === "Error")
          {
            alert("Error in Updating Insurer Details. Kindly contact Advents Support!!!");
            this.ngxService.stop();
          }
        },
        (error : any) => {
          this.HandleErrorResponse(error);
          this.ngxService.stop();
        }
      );
    };
  };

  onClientAddSaveButtonClick()
  {
    if (this.miInsurer.clientNameAdd == "")
    {
      alert("Client Name cannot be Empty!!!");
    }
    else if (this.miInsurer.policyStartDateAdd == "Empty")
    {
      alert("Please Choose Policy Start Date!!!");
    }
    else if (this.miInsurer.policyEndDateAdd == "Empty")
    {
      alert("Please Choose Policy End Date!!!");
    }
    else
    {
      this.ngxService.start();
      let data = {
        "tenantId" : this.miInsurer.tenantId,
        "groupId" : this.miInsurer.groupId,
        "entityId" : this.miInsurer.entityId,
        "mProcessingLayerId" : this.miInsurer.mProcessingLayerId,
        "mProcessingSubLayerId" : this.miInsurer.mProcessingSubLayerId,
        "processingLayerId" : this.miInsurer.processingLayerId,
        "userId" : this.miInsurer.userId,
        "insurerId" : this.miInsurer.insurerId,
        "clientName" : this.miInsurer.clientNameAdd,
        "policyStartDate" : this.miInsurer.policyStartDateAdd,
        "policyEndDate" : this.miInsurer.policyEndDateAdd,
        "address" : this.miInsurer.addressAdd,
        "gstNumber" : this.miInsurer.gstNumberAdd
      };

      this.obj_auth_service.postClientDetailsToServer(data)
      .subscribe(
        receivedData => {
          let responseData = receivedData;
          if (responseData["Status"] === "Success")
          {
            alert("Client Details Added Successfully!!!");
            this.getClientDetails();
            this.ngxService.stop();
          }
          else if (responseData["Status"] === "Error")
          {
            alert("Error in Adding Client Details. Kindly contact Advents Support!!!");
            this.ngxService.stop();
          }
        },
        (error : any) => {
          this.HandleErrorResponse(error);
          this.ngxService.stop();
        }
      );

    };
  };

  onClientEditSaveButtonClick()
  {
    if (this.miInsurer.clientNameEdit == '')
    {
      alert("Client Name cannot be Empty!!!");
    }
    else if (this.miInsurer.clientActiveStatus == '')
    {
      alert("Please Choose the Client Status whether Active or Not!!!");
    }
    else
    {
      this.ngxService.start();
      let clientId = this.selectedClientRow[0]["id"];
      let insurerId = this.selectedInsurerRow[0]["id"];
      let data = {
        "tenantId" : this.miInsurer.tenantId,
        "groupId" : this.miInsurer.groupId,
        "entityId" : this.miInsurer.entityId,
        "mProcessingLayerId" : this.miInsurer.mProcessingLayerId,
        "mProcessingSubLayerId" : this.miInsurer.mProcessingSubLayerId,
        "processingLayerId" : this.miInsurer.processingLayerId,
        "userId" : this.miInsurer.userId,
        "insurerId" : insurerId,
        "clientId" : clientId,
        "clientName" : this.miInsurer.clientNameEdit,
        "policyStartDate" : this.miInsurer.policyStartDateEdit,
        "policyEndDate" : this.miInsurer.policyEndDateEdit,
        "address" : this.miInsurer.addressEdit,
        "gstNumber" : this.miInsurer.gstNumberEdit,
        "clientActiveStatus" : this.miInsurer.clientActiveStatus
      };

      this.obj_auth_service.updateClientDetailsToServer(data)
      .subscribe(
        receivedData => {
          let responseData = receivedData;
          if (responseData["Status"] === "Success")
          {
            alert("Client Details Updated Successfully!!!");
            this.getClientDetails();
            this.ngxService.stop();
          }
          else if (responseData["Status"] === "Error")
          {
            alert("Error in Updating Client Details. Kindly contact Advents Support!!!");
            this.ngxService.stop();
          }
        },
        (error : any) => {
          this.HandleErrorResponse(error);
          this.ngxService.stop();
        }
      );

    };
  };

  onMailIdAddSaveButtonClick()
  {
    if (this.miInsurer.mailAddressAdd == '')
    {
      alert("Please Enter the Email Address!!!");
    }
    else
    {
      this.ngxService.start();
      let clientId = this.selectedClientRow[0]["id"];
      let insurerId = this.selectedInsurerRow[0]["id"];
      let data = {
        "tenantId" : this.miInsurer.tenantId,
        "groupId" : this.miInsurer.groupId,
        "entityId" : this.miInsurer.entityId,
        "mProcessingLayerId" : this.miInsurer.mProcessingLayerId,
        "mProcessingSubLayerId" : this.miInsurer.mProcessingSubLayerId,
        "processingLayerId" : this.miInsurer.processingLayerId,
        "userId" : this.miInsurer.userId,
        "insurerId" : insurerId,
        "clientId" : clientId,
        "mailAddress" : this.miInsurer.mailAddressAdd
      };

      this.obj_auth_service.postMailAddressToServer(data)
      .subscribe(
        receivedData => {
          let responseData = receivedData;
          if (responseData["Status"] === "Success")
          {
            alert("Mail Address added Successfully");
            this.getMailId();
            this.ngxService.stop();
          }
          else if (responseData["Status"] === "Error")
          {
            alert("Error in Adding Mail Address. Kindly Contact Advents Support!!!");
            this.ngxService.stop();
          }
        },
        (error : any) => {
          this.HandleErrorResponse(error);
          this.ngxService.stop();
        }
      );
    };
  };

  onMailIdEditSaveButtonClick()
  {
    if (this.miInsurer.mailAddressEdit == '')
    {
      alert("Mail Address Cannot Be Empty!!!");
    }
    else if (this.miInsurer.mailIdActiveStatus == '')
    {
      alert("Please Choose Mail Address Status whether it is active or not!!!");
    }
    else
    {
      this.ngxService.start();
      let clientId = this.selectedClientRow[0]["id"];
      let insurerId = this.selectedInsurerRow[0]["id"];
      let mailAddressId = this.selectedMailIdRow[0]["id"];
      let data = {
        "tenantId" : this.miInsurer.tenantId,
        "groupId" : this.miInsurer.groupId,
        "entityId" : this.miInsurer.entityId,
        "mProcessingLayerId" : this.miInsurer.mProcessingLayerId,
        "mProcessingSubLayerId" : this.miInsurer.mProcessingSubLayerId,
        "processingLayerId" : this.miInsurer.processingLayerId,
        "userId" : this.miInsurer.userId,
        "insurerId" : insurerId,
        "clientId" : clientId,
        "mailAddressId" : mailAddressId,
        "mailAddress" : this.miInsurer.mailAddressEdit,
        "mailIdActiveStatus" : this.miInsurer.mailIdActiveStatus
      };

      this.obj_auth_service.updateMailAddressToServer(data)
      .subscribe(
        receivedData => {
          let responseData = receivedData;
          if (responseData["Status"] === "Success")
          {
            alert("Mail Address Updated Successfully!!!");
            this.getMailId();
            this.ngxService.stop();
          }
          else if (responseData["Status"] === "Error")
          {
            alert("Error in Updating Mail Address. Kindly Contact Advents Support!!!");
            this.ngxService.stop();
          }
        },
        (error : any) => {
          this.HandleErrorResponse(error);
          this.ngxService.stop();
        }
      );

    };
  };

  HandleErrorResponse(err: any)
  {
    //  this.objerrhandler.handleError(String(err));
   console.log("Error",err);
  };

}
