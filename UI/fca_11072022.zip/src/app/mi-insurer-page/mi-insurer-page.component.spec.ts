import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MiInsurerPageComponent } from './mi-insurer-page.component';

describe('MiInsurerPageComponent', () => {
  let component: MiInsurerPageComponent;
  let fixture: ComponentFixture<MiInsurerPageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MiInsurerPageComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MiInsurerPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
