import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PoIssueLandingPageComponent } from './po-issue-landing-page.component';

describe('PoIssueLandingPageComponent', () => {
  let component: PoIssueLandingPageComponent;
  let fixture: ComponentFixture<PoIssueLandingPageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PoIssueLandingPageComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PoIssueLandingPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
