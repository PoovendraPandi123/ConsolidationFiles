import { Injectable } from '@angular/core';
import { CommonService } from 'src/app/service/common.service';

@Injectable({
  providedIn: 'root'
})
export class VrMatchingCommentsService {

  public reconPort = '50013';

  constructor(private CS: CommonService) { }

  public getMatchingCommentsFromServer(prminputs) : any {
    var resData = CommonService.authReq(this.reconPort+'/api/v1/vendor_recon/m_matching_comments/');
    return this.CS.SendToAPI("get", resData, prminputs);
  }

  public postMatchingCommentsToServer(prminputs) : any {
    var resData = CommonService.authReq(this.reconPort+'/api/v1/vendor_recon/m_matching_comments/');
    return this.CS.SendToAPI("post", resData, prminputs);
  }
}
