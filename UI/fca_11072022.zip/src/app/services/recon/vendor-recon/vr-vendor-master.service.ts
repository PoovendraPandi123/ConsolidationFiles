import { Injectable } from '@angular/core';
import { CommonService } from 'src/app/service/common.service';

@Injectable({
  providedIn: 'root'
})
export class VrVendorMasterService {

  public reconPort = "50013";

  constructor(private CS: CommonService) { }

  public getVendorMasterListFromServer(prminputs : any) : any {
    var resData = CommonService.authReq(this.reconPort+'/api/v1/vendor_recon/vendor_master/');
    return this.CS.SendToAPI("get", resData, prminputs);
  }

}
