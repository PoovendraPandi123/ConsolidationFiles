import { TestBed } from '@angular/core/testing';

import { VrLandingPageService } from './vr-landing-page.service';

describe('VrLandingPageService', () => {
  let service: VrLandingPageService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(VrLandingPageService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
