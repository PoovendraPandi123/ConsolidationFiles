import { TestBed } from '@angular/core/testing';

import { BrsConsolidationReportService } from './brs-consolidation-report.service';

describe('BrsConsolidationReportService', () => {
  let service: BrsConsolidationReportService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(BrsConsolidationReportService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
