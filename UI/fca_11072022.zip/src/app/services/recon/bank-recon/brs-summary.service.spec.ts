import { TestBed } from '@angular/core/testing';

import { BrsSummaryService } from './brs-summary.service';

describe('BrsSummaryService', () => {
  let service: BrsSummaryService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(BrsSummaryService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
