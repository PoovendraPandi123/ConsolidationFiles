import { Injectable } from '@angular/core';
import { CommonService } from 'src/app/service/common.service';

@Injectable({
  providedIn: 'root'
})
export class BrsSummaryService {

  public sourcePort = '50003';
  public reconPort = '5004';

  constructor(private CS : CommonService) { }

  public getProcessingLayerListFromServer(prminputs) : any {
    var resData = CommonService.authReq(this.sourcePort+'/source/get_processing_layer_list/');
    return this.CS.SendToAPI("post", resData, prminputs);
  }

  public getTransactionCountFromServer(prminputs) : any {
    var resData = CommonService.authReq(this.reconPort+'/api/v1/bank_recon/get_transaction_count/');
    return this.CS.SendToAPI("post", resData, prminputs);
  }

  public getTransactionRecordsFromServer(prminputs) : any {
    var resData = CommonService.authReq(this.reconPort+'/api/v1/bank_recon/get_transaction_records/');
    return this.CS.SendToAPI("post", resData, prminputs);
  }

  public getIntExtRecordsFromServer(prminputs) : any {
    var resData = CommonService.authReq(this.reconPort+'/api/v1/bank_recon/get_int_ext_transactions/');
    return this.CS.SendToAPI("post", resData, prminputs);
  }

  public getInternalExternalHeadersFromServer(prminputs) : any {
    var resData = CommonService.authReq(this.reconPort+'/api/v1/bank_recon/get_internal_external_headers/');
    return this.CS.SendToAPI("post", resData, prminputs);
  }

  public getMatchingCommentsFromServer(prminputs) : any {
    var resData = CommonService.authReq(this.reconPort+'/api/v1/bank_recon/m_matching_comments/');
    return this.CS.SendToAPI("get", resData, prminputs);
  }

  public sendUnMatchedToMatchToServer(prminputs) : any {
    var resData = CommonService.authReq(this.reconPort+'/api/v1/bank_recon/get_update_unmatched_matched/');
    return this.CS.SendToAPI("post", resData, prminputs);
  }

  public sendUnmatchedToContraToServer(prminputs) : any {
    var resData = CommonService.authReq(this.reconPort+'/api/v1/bank_recon/get_update_contra/');
    return this.CS.SendToAPI("post", resData, prminputs);
  }

  public sendMatchedToUnMatchToServer(prminputs) : any {
    var resData = CommonService.authReq(this.reconPort+'/api/v1/bank_recon/get_update_matched_unmatched/');
    return this.CS.SendToAPI("post", resData, prminputs);
  }

  public getGroupIdTransactionsFromServer(prminputs) : any {
    var resData = CommonService.authReq(this.reconPort+'/api/v1/bank_recon/get_group_id_transactions/');
    return this.CS.SendToAPI("post", resData, prminputs);
  }

  public setGroupMatchedToUnMatchToServer(prminputs) : any {
    var resData = CommonService.authReq(this.reconPort+'/api/v1/bank_recon/get_update_group_records_unmatched/');
    return this.CS.SendToAPI("post", resData, prminputs);
  }

  public getSelectedContraRecordsFromServer(prminputs) : any {
    var resData = CommonService.authReq(this.reconPort+'/api/v1/bank_recon/get_selected_contra_records/');
    return this.CS.SendToAPI("post", resData, prminputs);
  }

  public setContraMatchedToUnMatchedToServer(prminputs) : any {
    var resData = CommonService.authReq(this.reconPort+'/api/v1/bank_recon/get_unmatch_matched_contra/');
    return this.CS.SendToAPI("post", resData, prminputs);
  }

  public getGroupUnMatchedTransactionsFromServer(prminputs) : any {
    let resData = CommonService.authReq(this.reconPort+'/api/v1/bank_recon/get_grouped_unmatch_transactions/');
    return this.CS.SendToAPI("post", resData, prminputs);
  }

  public getUpdateGroupUnMatchedUnMatchToServer(prminputs){
    let resData = CommonService.authReq(this.reconPort+'/api/v1/bank_recon/get_unmatch_grouped_unmatched_transactions/');
    return this.CS.SendToAPI("post", resData, prminputs);
  }

  public getUpdateGroupUnMatchedMatchToServer(prminputs){
    let resData = CommonService.authReq(this.reconPort+'/api/v1/bank_recon/get_match_grouped_unmatched_transactions/');
    return this.CS.SendToAPI("post", resData, prminputs);
  }

  public getUpdateDuplicateRecordsToServer(prminputs){
    let resData = CommonService.authReq(this.reconPort+'/api/v1/bank_recon/get_update_duplicates/');
    return this.CS.SendToAPI("post", resData, prminputs);
  }
}
