import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AsErpTanUpdateComponent } from './as-erp-tan-update.component';

describe('AsErpTanUpdateComponent', () => {
  let component: AsErpTanUpdateComponent;
  let fixture: ComponentFixture<AsErpTanUpdateComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AsErpTanUpdateComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AsErpTanUpdateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
