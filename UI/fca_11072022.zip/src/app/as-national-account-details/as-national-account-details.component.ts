import { Component, OnInit, ViewChild } from '@angular/core';
import { AgGridAngular } from 'ag-grid-angular';
import { HttpClient  } from '@angular/common/http';
import { AuthService } from '../service/as.auth.service';
import { ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { NgxUiLoaderService } from "ngx-ui-loader"; // Import NgxUiLoaderService

@Component({
  selector: 'app-as-national-account-details',
  templateUrl: './as-national-account-details.component.html',
  styleUrls: ['./as-national-account-details.component.css']
})
export class AsNationalAccountDetailsComponent implements OnInit {

  @ViewChild('agGrid')
  agGrid!: AgGridAngular;

  public userModelList: any;
  public userId: any;
  public tenantId: any;
  public groupId: any;
  public entityId: any;
  public mProcessingLayerId: any;
  public mProcessingSubLayerId: any;
  public pagination : boolean = false;
  public paginationSize : Number = 0;
  public externalRowData: any;
  public externalColumnDefs: any;
  public processingLayerIdsUser: any;
  public withoutTanRowData: any;
  public withTanApi: any;
  public withTanColumnApi: any;
  public withoutTanApi: any;
  public withoputTanColumnApi: any;
  public withoutTanColumnDefs: any;
  public closeResult: any;
  public tanNumber: any;
  public tanAddButton: boolean = false;
  public selectedNacId: any;
  public searchvalueWithTan: any;
  public searchvalueWithoutTan: any;
  public groupDisplayType: any;

  constructor(public http:HttpClient, public obj_auth_service: AuthService, public modalService: NgbModal, public ngxService: NgxUiLoaderService) { }

  ngOnInit(): void {
    this.userModelList = JSON.parse(sessionStorage.getItem("user_model_list"));
    this.userId = JSON.parse(sessionStorage.getItem("user_details"))["user_id"];
    this.tenantId = this.userModelList["tenant_id"];
    this.groupId = this.userModelList["group_id"];
    this.entityId = this.userModelList["entity_id"];
    this.mProcessingLayerId = this.userModelList["m_processing_layer_id"];
    this.mProcessingSubLayerId = this.userModelList["m_processing_sub_layer_id"];
    this.processingLayerIdsUser = this.userModelList["processing_layer_ids"];
    this.pagination = true;
    this.paginationSize = 20;
    this.displayNAD();
  }


  displayNAD(){
    this.ngxService.start();
    let data = {
      "tenantId" : this.tenantId,
      "groupId" : this.groupId,
      "entityId" : this.entityId,
      "mProcessingLayerId" : this.mProcessingLayerId,
      "mProcessingSubLayerId" : this.mProcessingSubLayerId
    }

    this.obj_auth_service.getCustomerNADListFromServer(data)
    .subscribe(
      received_data => {
        let response_data = received_data["data"];
        console.log("NAD List Response: ", response_data);
        let externalRecordsAllColumnDefs = response_data["nad"]["headers"];
        let externalRecordsAllrowData = response_data["nad"]["data"];
        let withoutTANRecordsAllrowData = response_data["nadwt"]["data"];
        let withoutTanRecordsAllColumnDefs = response_data["nadwt"]["headers"];

        // External
        externalRecordsAllColumnDefs.forEach((item, index) => {
          if(item.sortable=="true"){
            if(index === 0){
              item["checkboxSelection"] = false;
              item["minWidth"] = 100;
              // item["pinned"] = 'left';
              item.sortable=false;
              item.filter=true;
              item.resizable=true;
              item.suppressAutoSize=true;
              item.suppressSizeToFit=true;
              item.lockPosition=true;
            }
            else if (index !== 0){
              item.sortable=true;
              item.filter=true;
              item.resizable=true;
              item.suppressAutoSize=true;
              item.suppressSizeToFit=true;
              item["minWidth"] = 100;
            }

            // Hiding
            if (item.field === "id")
            {
              item["hide"] = true;
            }

          }
        });

        // Withoout TAN Headers
        withoutTanRecordsAllColumnDefs.forEach((item, index) => {
          if(item.sortable=="true"){
            if(index === 0){
              item["checkboxSelection"] = true;
              item["maxWidth"] = 40;
              item["pinned"] = 'left';
              item.sortable=true;
              item.filter=false;
              item.resizable=false;
              item.suppressAutoSize=true;
              item.suppressSizeToFit=true;
              item.lockPosition=false;
            }
            else if (index !== 0){
              item.sortable=true;
              item.filter=true;
              item.resizable=true;
              item.suppressAutoSize=true;
              item.suppressSizeToFit=true;
              item["minWidth"] = 50;
            }

            // Hiding
            if (item.field === "id" || item.field === "external_contra_id" || item.field === "external_group_id" || item.field === "ext_processing_status_1" || item.field === "external_debit" || item.field === "external_credit")
            {
              item["hide"] = true;
            }

          }
        });

        console.log(externalRecordsAllColumnDefs);

        this.externalColumnDefs = externalRecordsAllColumnDefs;
        this.externalRowData = externalRecordsAllrowData;
        this.withoutTanColumnDefs = withoutTanRecordsAllColumnDefs;
        this.withoutTanRowData = withoutTANRecordsAllrowData;
        
        this.ngxService.stop();
      }
    )
  }

  onWithTanGridReady(params)
  {
    this.withTanApi = params.api;
    this.withTanColumnApi = params.columnApi;
  }

  onWithTanExportButtonClick()
  {
    const params = {
      columnGroups: true,
      allColumns: false,
      fileName: 'Customer_National_Account_Details_With_TAN.csv'
    };
    this.withTanApi.exportDataAsCsv(params);
  }

  onWithoutTanGridReady(params)
  {
    this.withoutTanApi = params.api;
    this.withoputTanColumnApi = params.columnApi;
  }

  onWithoutTanExportButtonClick()
  {
    const params = {
      columnGroups: true,
      allColumns: false,
      fileName: 'Customer_National_Account_Details_Without_TAN.csv',
      skipPinned: true,
      columnKeys:["customer_number", "customer_name", "national_account"]
    };
    this.withoutTanApi.exportDataAsCsv(params);
  }

  quickSearchWithTan(){
    this.withTanApi.setQuickFilter(this.searchvalueWithTan);
  }

  quickSearchWithoutTan(){
    this.withoutTanApi.setQuickFilter(this.searchvalueWithoutTan);
  }

  open(content) {
    this.modalService.open(content, {ariaLabelledBy: 'modal-basic-title'}).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }

  onWithoutTanSelectionChanged(params)
  {
    let withoutTanSelectedRow = params.api.getSelectedRows();
    if (withoutTanSelectedRow.length > 0)
    {
      this.tanAddButton = true;
      this.selectedNacId = withoutTanSelectedRow[0]['id'];
    }
    else
    {
      this.tanAddButton = false;
    }
  }


  onSaveButtonClick(){
    this.ngxService.start();

    if (this.tanNumber.length != 10)
    {
      alert("The Length of the TAN should be 10!!!");
      this.ngxService.stop();
    }
    else
    {
      let data = {
        "tenantId" : this.tenantId,
        "groupId" : this.groupId,
        "entityId" : this.entityId,
        "mProcessingLayerId" : this.mProcessingLayerId,
        "mProcessingSubLayerId" : this.mProcessingSubLayerId,
        "nacId": this.selectedNacId,
        "tan": this.tanNumber
      }

      this.obj_auth_service.sendTanToServer(data)
      .subscribe(
        received_data => {
          let responseData = received_data["Status"];
          if (responseData === "Success")
          {
            this.ngxService.stop();
          }
          else if(responseData === "Error")
          {
            alert("Error in Updating TAN. Kindly Contact Advents Support!!!");
            this.ngxService.stop();
          }
        }
      )
    }

  }

  HandleErrorResponse(err: any)
  {
    //  this.objerrhandler.handleError(String(err));
   console.log("Error",err);
  }


}
