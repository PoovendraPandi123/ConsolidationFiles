export class User{
    constructor(
        public username: string = "",
        public password: string = "",
        public ip_address: string = "",
        public login_time: string = "",
        public logout_time: string = ""
    ){}
}