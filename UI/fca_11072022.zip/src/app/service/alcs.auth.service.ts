import { Injectable } from '@angular/core';
// import { Http, Response } from '@angular/http';
import { HttpClient,HttpHeaders  } from '@angular/common/http';
import { CommonService } from './common.service';
// import { Util } from './Util';
import { RouteConfigLoadStart, Router } from '@angular/router';
@Injectable({
  providedIn: 'root'
})
export class AlcsAuthService{
  lstReturn: any;
  public alcsPort = "50010";

  constructor(private httpClient: HttpClient, private router: Router, 
    // private Util: Util, 
    private CS: CommonService) {
  }

  public getClientDetailsFromServer(prminputs){
    var resData = CommonService.authReq(this.alcsPort+'/api/v1/alcs/client_details/');
    return this.CS.SendToAPI("get", resData, prminputs);
  };

  public editClientDetailsToServer(prminputs){
    let id = prminputs["id"].toString();
    var resData = CommonService.authReq(this.alcsPort+'/api/v1/alcs/client_details/'+id+'/');
    return this.CS.SendToAPI("put", resData, prminputs);
  };

  public postClientDetailsToServer(prminputs){
    var resData = CommonService.authReq(this.alcsPort+'/api/v1/alcs/client_details/');
    return this.CS.SendToAPI("post", resData, prminputs);
  };

  public deleteClientDetailsToServer(prminputs){
    let id = prminputs["id"].toString();
    var resData = CommonService.authReq(this.alcsPort+'/api/v1/alcs/client_details/'+id+'/');
    return this.CS.SendToAPI("delete", resData, prminputs);
  };

  public sendMailToClient(prminputs){
    let clientId = prminputs["alcsClientId"];
    let paymentFromDate = prminputs["paymentFromDate"];
    let paymentToDate = prminputs["paymentToDate"];
    let tenantsId = String(prminputs["tenantsId"]);
    let groupsId = String(prminputs["groupsId"]);
    let entitiesId = String(prminputs["entitiesId"]);
    let mProcessingLayerId = String(prminputs["mProcessingLayerId"]);
    let mProcessingSubLayerId = String(prminputs["mProcessingSubLayerId"]);
    var resData = CommonService.authReq(this.alcsPort+'/api/v1/alcs/generic/send_mail_client/?paymentFromDate='+paymentFromDate+'&clientId='+clientId+'&paymentToDate='+paymentToDate+'&tenantsId='+tenantsId+'&groupsId='+groupsId+'&entitiesId='+entitiesId+'&mProcessingLayerId='+mProcessingLayerId+'&mProcessingSubLayerId='+mProcessingSubLayerId);
    return this.CS.SendToAPI("get", resData, prminputs);
  }

}
