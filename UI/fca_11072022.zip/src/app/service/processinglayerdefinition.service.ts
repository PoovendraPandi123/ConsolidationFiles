import { Injectable } from '@angular/core';
// import { Http, Response } from '@angular/http';
import { HttpClient,HttpHeaders  } from '@angular/common/http';
import { CommonService } from './common.service';
// import { Util } from './Util';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class ProcessinglayerdefinitionService {
  lstReturn: any;
  public  port="50003";
  // public  port1="10002";

  constructor(private httpClient: HttpClient, private router: Router, 
    // private Util: Util, 
    private CS: CommonService) {
  }

  
  postprocessinglayersFromServer(prminputs) {
    var resData = CommonService.authReq(this.port+'/source/update_processing_layer/');
    return this.CS.SendToAPI("post", resData, prminputs);
   
  }

  getprocessinglayerdefinitionFromServer(prminputs) {
    var resData = CommonService.authReq(this.port+'/source/processing_layers/');
    return this.CS.SendToAPI("post", resData, prminputs);
   
  }
  getprocessingsubtypeFromServer(prminputs) {
    var resData = CommonService.authReq(this.port+'/source/processing_sub_layers/');
    return this.CS.SendToAPI("post", resData, prminputs);
   
  }

  getaggregatorFromServer(prminputs) {
    var resData = CommonService.authReq(this.port+'/source/aggregator_list/');
    return this.CS.SendToAPI("post", resData, prminputs);
   
  }
}
