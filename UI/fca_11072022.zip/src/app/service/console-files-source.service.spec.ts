import { TestBed } from '@angular/core/testing';

import { ConsoleFilesSourceService } from './console-files-source.service';

describe('ConsoleFilesSourceService', () => {
  let service: ConsoleFilesSourceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ConsoleFilesSourceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
