import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders  } from '@angular/common/http';
import { CommonService } from './common.service';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class MIFileUploadService {
 
  lstReturn: any;
  public port="50008";

  constructor(private httpClient: HttpClient, private router: Router, 
    private CS: CommonService) {
  }

  
  getfilterreconFromServer(prminputs) {
    var resData = CommonService.authReq(this.port+'/med_ins_recon/get_processing_layer_list/');
    return this.CS.SendToAPI("post", resData, prminputs);
   
  }

  postFileToServer(prminputs) {
    var resData = CommonService.authReq(this.port+'/med_ins_recon/get_file_upload_transactions/');
    return this.CS.SendFileToAPI("post", resData, prminputs);
  }

  getFileListFromServer(prminputs){
    var resData = CommonService.authReq(this.port+'/med_ins_recon/get_file_list/');
    return this.CS.SendToAPI("post", resData, prminputs);
  }
  
/*  getConsolidationFilelistFromServer(prminputs) {
    var resData = CommonService.authReq(this.port+'/recon/upload_data/');
    return this.CS.SendToAPI("post", resData, prminputs);
   
  } */



/*  getConsolidationFilePreviewFromServer(prminputs) {
    var resData = CommonService.authReq(this.port+'/recon/file_data/');
    return this.CS.SendToAPI("post", resData, prminputs);   
  } */
}
