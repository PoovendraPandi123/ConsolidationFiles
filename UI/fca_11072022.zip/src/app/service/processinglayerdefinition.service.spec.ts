import { TestBed } from '@angular/core/testing';

import { ProcessinglayerdefinitionService } from './processinglayerdefinition.service';

describe('ProcessinglayerdefinitionService', () => {
  let service: ProcessinglayerdefinitionService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ProcessinglayerdefinitionService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
