import { TestBed } from '@angular/core/testing';

import { AlcsreportService } from './alcsreport.service';

describe('AlcsreportService', () => {
  let service: AlcsreportService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AlcsreportService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
