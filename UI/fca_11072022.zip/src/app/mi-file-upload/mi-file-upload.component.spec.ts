import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MiFileUploadComponent } from './mi-file-upload.component';

describe('MiFileUploadComponent', () => {
  let component: MiFileUploadComponent;
  let fixture: ComponentFixture<MiFileUploadComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MiFileUploadComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MiFileUploadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
