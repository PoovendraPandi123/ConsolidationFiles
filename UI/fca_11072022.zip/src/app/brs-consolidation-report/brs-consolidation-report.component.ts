import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { AuthService } from '../service/auth.service';
import { NgxUiLoaderService } from "ngx-ui-loader"; // Import NgxUiLoaderService

@Component({
  selector: 'app-brs-consolidation-report',
  templateUrl: './brs-consolidation-report.component.html',
  styleUrls: ['./brs-consolidation-report.component.css']
})
export class BrsConsolidationReportComponent implements OnInit {

  public dateChoosen : String = 'date';
  public reportDownload: boolean = false;
  public reportFileGenerated : any;
  public userModelList: any;
  public tenantId : any;
  public groupId : any;
  public entityId : any;
  public mProcessingLayerId : any;
  public mProcessingSubLayerId : any;
  public userId : any;

  constructor(public http:HttpClient, public obj_auth_service: AuthService, public ngxService: NgxUiLoaderService) { }

  ngOnInit(): void {
    this.userModelList = JSON.parse(sessionStorage.getItem("user_model_list"));
    this.userId = JSON.parse(sessionStorage.getItem("user_details"))["user_id"];
    this.tenantId = this.userModelList["tenant_id"];
    this.groupId = this.userModelList["group_id"];
    this.entityId = this.userModelList["entity_id"];
    this.mProcessingLayerId = this.userModelList["m_processing_layer_id"];
    this.mProcessingSubLayerId = this.userModelList["m_processing_sub_layer_id"];
  }

  reportDownloadClick(){
    this.reportDownload = false;
    let dateChoosen = this.dateChoosen;

    if(dateChoosen === "date")
    {
      alert("Kindly Choose Date!!!");
    }

    if(dateChoosen !== "date")
    {
      this.ngxService.start();
      let data = {
        "tenantId": this.tenantId,
        "groupId": this.groupId,
        "entityId": this.entityId,
        "mProcessingLayerId": this.mProcessingLayerId,
        "mProcessingSubLayerId": this.mProcessingSubLayerId,
        "userId": this.userId,
        "reportDate": dateChoosen,
        "typeId": JSON.parse(sessionStorage.getItem("user_model_list"))["type_id"]
      }

      this.obj_auth_service.getBrsConsolidationReportFromServer(data)
      .subscribe(
        received_data => {
          let responseData = received_data;
          console.log("Consol Report Button Click Response", responseData);
          if(responseData["Status"] === "Success")
          {
            console.log("Success");
            this.reportFileGenerated = responseData["file_generated"];
            this.reportDownload = true;
            this.ngxService.stop();
          }
          else if(responseData["Status"] === "Error")
          {
            console.log("Error");
            this.ngxService.stop();
            alert("Error in Getting Report. Please Contact Advent Support!!!");
          }
          else if(responseData["Status"] === "Report Generating")
          {
            console.log("Another user is currently generating report");
            this.ngxService.stop();
            alert("Another User is Currently Generating Report. Kindly try after some time!!!");
          }
        }
      )
    }
  }

}
