import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tds-recon-landing-page',
  templateUrl: './tds-recon-landing-page.component.html',
  styleUrls: ['./tds-recon-landing-page.component.css']
})
export class TdsReconLandingPageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
