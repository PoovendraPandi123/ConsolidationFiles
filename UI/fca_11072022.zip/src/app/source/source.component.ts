import { Component, OnInit, OnDestroy } from '@angular/core';
import { Source } from './source.model'
import { SourceService } from '../service/source.service';
import { HttpClient  } from '@angular/common/http';
import { Router} from '@angular/router';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { MessageComponent } from '../message/message.component';
import { Subject } from 'rxjs';
import * as $ from 'jquery';

@Component({
  selector: 'app-source',
  templateUrl: './source.component.html',
  styleUrls: ['./source.component.css']
})
export class SourceComponent implements OnInit,OnDestroy {

  objsource:Source;

  public sourceextn;
  public sourcetype;
  public password;
  public userdtl;
  public user;
  public sourcedata;
  public sourcelist;
  public sourceview
  public cardTitle;

  dtOptions: DataTables.Settings = {};
  dtTrigger: Subject<any> = new Subject<any>();

  constructor(private router: Router,private objservice:SourceService,public http:HttpClient,private  dialog:  MatDialog) { }

  ngOnInit(): void {
    this.objsource=new Source();
    this.userdtl=JSON.parse(sessionStorage.getItem('user_details'));
    this.user=JSON.parse(localStorage.getItem('Userdtl'));
    console.log("userdtl",this.user);
    this.sourceview=false;
    this.password=false;  
    this.getsourcelist();
  }

  ngOnDestroy(): void {
    this.dtTrigger.unsubscribe();
  }

  sourceExtension(val){

    if(val==".txt"){
      this.sourceextn=true;
      }
      else{
      this.sourceextn=false;
      this.objsource.delimiter="";
      }
  }

  sourceType(val){
    if(val=="DB"){
      this.sourcetype=true;
      }
      else{
      this.sourcetype=false;
      this.objsource.delimiter="";
      }
  }

  passreq(val){
    console.log("passreq",val);
    
    if(val=="Yes"){
    this.password=true;
    }
    else{
    this.password=false;
    this.objsource.password="";
    }
  }

  list(){
    this.sourceview=true;
    this.getsourcelist();  
  }
  backlist(){
    this.sourceview=false;
    this.objsource= new Source();  
  }
  getsourcelist(){
    let Indata={
      "tenant_id": 1,
      "group_id": 1,
      "entity_id": 1,
      "module_id": 1,
      "operation_flag":"SELECT"      
    }
    console.log("inputsource",Indata);
    this.objservice.getsourceFromServer(Indata)
    .subscribe(
    recieveddata  => {
      let tempresponsedata = recieveddata;
      console.log("Sourcelistresponse---",tempresponsedata)
      this.sourcedata=tempresponsedata;
      this.sourcelist=this.sourcedata.sources_list;
      this.dtTrigger.next();
     
    });

  }

  Editsourcedetail(param){
    this.objsource.source_id=param.source_id;
    this.objsource.source_name=param.source_name;
    this.objsource.source_type=param.source_type;
    this.objsource.delimiter=param.delimiter;
    this.objsource.source_extension=param.source_extension;
    this.objsource.sheet_name=param.sheet_name;
    this.objsource.password_protected=param.password_protected;
    this.objsource.column_start_row=param.column_start_row;
    this.objsource.database=param.database;   
    this.objsource.user_name=param.user_name;   
    this.objsource.password=param.password;   
    this.objsource.schema_name=param.schema_name;   
    this.objsource.table_name=param.table_name;   
    this.objsource.import_sequence=param.import_sequence;   
    this.sourceview=true;

  }

  savesourcedetails(){
    let Indata={

      "tenant_id": 1,
      "group_id":1,
      "entity_id": 1,
      "user_id": 1,
      "source_id": this.objsource.source_id,
      "source_name": this.objsource.source_name,
      "source_type": this.objsource.source_type,
      "separator": this.objsource.delimiter,
      "source_extension": this.objsource.source_extension,
      "sheet_name": this.objsource.sheet_name,
      "password_protected": this.objsource.password_protected,
      "column_start_row": this.objsource.column_start_row ,
      "database": this.objsource.database,
      "user_name": this.objsource.user_name,
      "password": this.objsource.password,
      "schema_name": this.objsource.schema_name,
      "table_name": this.objsource.table_name,
      "import_sequence": this.objsource.import_sequence,
        }

    console.log("inputsavesource",Indata);
    this.objservice.postsourceFromServer(Indata)
    .subscribe(
    (recieveddata:any)  => {
      let tempresponsedata = recieveddata;
      console.log("Sourceresponse---",tempresponsedata)
    this.objsource= new Source();
    
    this.dialog.open(MessageComponent,{ data: "Sucsessfully Upated!!!" });
    this.list();

    });
  }

  private loadData() {

  
  }
  cancelEdit(){
    
  }

}
