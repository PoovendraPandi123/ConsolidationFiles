import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MiReportDeletionComponent } from './mi-report-deletion.component';

describe('MiReportDeletionComponent', () => {
  let component: MiReportDeletionComponent;
  let fixture: ComponentFixture<MiReportDeletionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MiReportDeletionComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MiReportDeletionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
