import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VendorPaymentsLandingPageComponent } from './vendor-payments-landing-page.component';

describe('VendorPaymentsLandingPageComponent', () => {
  let component: VendorPaymentsLandingPageComponent;
  let fixture: ComponentFixture<VendorPaymentsLandingPageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ VendorPaymentsLandingPageComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(VendorPaymentsLandingPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
