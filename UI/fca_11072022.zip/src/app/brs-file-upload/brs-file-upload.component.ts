import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import {Router} from '@angular/router';
import {BrsFileUploadService} from '../service/brs-file-upload.service';
import { HttpClient  } from '@angular/common/http';
import { BrsFileUpload } from './brs-file-upload.model';
import {Observable} from 'rxjs';
import { AuthService } from '../service/auth.service';
import { NgxUiLoaderService } from "ngx-ui-loader"; // Import NgxUiLoaderService
import { AgGridAngular } from 'ag-grid-angular';

interface Food {
  value: string;
  viewValue: string;
}

@Component({
  selector: 'app-brs-file-upload',
  templateUrl: './brs-file-upload.component.html',
  styleUrls: ['./brs-file-upload.component.css']
})
export class BrsFileUploadComponent implements OnInit {

  @ViewChild('externalFileInput', {static: false})
  externalFileInput: ElementRef;

  @ViewChild('internalFileInput', {static: false})
  internalFileInput : ElementRef;

  @ViewChild('agGrid')
  agGrid!: AgGridAngular;

  public userdtl;
  public sourcedata;
  public processinglayerlist;
  public objprocessid;
  public fileupload;
  public fileuploadlist;

  public paginationSize;
  public file_records;
  public pagination;
  rowData: Observable<any[]>;
  public fileData;

  public userModelList :  any;
  public processingLayerIdsUser :  any;
  public selectProcessingLayer : any;
  public fileUploaded : any;
  public fileRowData : any;
  public fileColumnDefs :  any;

  brsFileUpload:BrsFileUpload;

  columnDefs = [
    { field: 'File Name',headerText: 'File Name', sortable: true, filter: true},
    { field: 'Size(mb)', sortable: true, filter: true },
    { field: 'UploadDate', sortable: true, filter: true },
    { field: 'UploadBy', sortable: true, filter: true },
    { field: 'UploadStatus', sortable: true, filter: true },
    { field: 'Validation', sortable: true, filter: true },
    { field: 'Status', sortable: true, filter: true },
    { field: 'ProcessTime', sortable: true, filter: true },
  ];

  constructor(private router: Router,private fileUploadService:BrsFileUploadService, public http:HttpClient, public obj_auth_service: AuthService, public ngxService: NgxUiLoaderService) { }

  shortLink: string = "";
  loading: boolean = false; 
  file: File = null; 
    
  ngOnInit(): void {

    this.brsFileUpload=new BrsFileUpload();

    this.userModelList = JSON.parse(sessionStorage.getItem("user_model_list"));
    this.brsFileUpload.userId = JSON.parse(sessionStorage.getItem("user_details"))["user_id"];
    this.brsFileUpload.tenantId = this.userModelList["tenant_id"];
    this.brsFileUpload.groupId = this.userModelList["group_id"];
    this.brsFileUpload.entityId = this.userModelList["entity_id"];
    this.brsFileUpload.mProcessingLayerId = this.userModelList["m_processing_layer_id"];
    this.brsFileUpload.mProcessingSubLayerId = this.userModelList["m_processing_sub_layer_id"];
    this.processingLayerIdsUser = this.userModelList["processing_layer_ids"];

    this.userdtl=JSON.parse(sessionStorage.getItem('user_details'));
    this.getProcessingLayerList();
    this.selectProcessingLayer = {
      "processing_layer_id" : 0
    };
    this.getFileUploadList();

    this.pagination=true;
    this.paginationSize = 15;
    this.file_records=[];

    this.getFileUploadedList();
  }

  getProcessingLayerList(){
    this.ngxService.start();
    console.log("userdetails ",this.userdtl);
    let Indata = {
      "tenantId" : this.brsFileUpload.tenantId,
      "groupId" : this.brsFileUpload.groupId,
      "entityId" : this.brsFileUpload.entityId,
      "mProcessingLayerId" : this.brsFileUpload.mProcessingLayerId,
      "mProcessingSubLayerId" : this.brsFileUpload.mProcessingSubLayerId,
      "typeId": JSON.parse(sessionStorage.getItem("user_model_list"))["type_id"]
    }
    console.log("inputfilterrecon",Indata);
    this.obj_auth_service.getProcessingLayerListFromServer(Indata)
    .subscribe(
    recieveddata  => {
      let tempresponsedata = recieveddata;
      console.log("filterlistresponse---",tempresponsedata)
      this.sourcedata=tempresponsedata;
      this.processinglayerlist=this.sourcedata.processing_layer_list;
      this.ngxService.stop();
  });
  }

  getFileUploadList()
  {
    let Indata={
      "tenant_id": this.brsFileUpload.tenantId,
      "group_id": this.brsFileUpload.groupId,
      "entity_id": this.brsFileUpload.entityId,
      "user_id": this.brsFileUpload.userId
    }
    console.log("fileuploadlistdata",Indata);
    this.fileUploadService.getFileListFromServer(Indata)
    .subscribe(
    recieveddata  => {
      let tempresponsedata = recieveddata;
      console.log("filelistresponse---",tempresponsedata)
      this.sourcedata=tempresponsedata;
      this.fileuploadlist=this.sourcedata.recon_file_upload_list;
      console.log("FIle Upload List ",this.fileuploadlist);
      this.rowData = this.fileuploadlist;
      this.file_records = this.fileuploadlist;
  });


}

onChange(event) {
    this.file = event.target.files[0];
}

public extFileOnChanged(event:any) {
  let files = event.target.files;
  this.brsFileUpload.externalFileName = files[0];
  console.log(files);
  console.log(this.brsFileUpload.externalFileName);
}

public intFileOnChanged(event:any) {
  let files = event.target.files;
  this.brsFileUpload.internalFileName = files[0];
  console.log(files);
  console.log(this.brsFileUpload.internalFileName);
}

public uploadAll(){

  console.log(this.brsFileUpload.processingLayerId);

  if (this.brsFileUpload.processingLayerId == "0" || this.brsFileUpload.processingLayerId === undefined)
  {
    alert("Kindly choose the Reconciliation Type!!!");
  }
  else
  {
    this.ngxService.start();

    if(this.brsFileUpload.externalFileName !== undefined && this.brsFileUpload.internalFileName !== undefined)
    {
      this.fileUploaded = "BOTH";
    }
    else if(this.brsFileUpload.externalFileName !== undefined && this.brsFileUpload.internalFileName === undefined)
    {
      this.fileUploaded = "EXTERNAL";
    }
    else if(this.brsFileUpload.externalFileName === undefined && this.brsFileUpload.internalFileName !== undefined)
    {
      this.fileUploaded = "INTERNAL";
    }

    const formData = new FormData();

    formData.append("internalFileName", this.brsFileUpload.internalFileName);
    formData.append("externalFileName ", this.brsFileUpload.externalFileName);
    formData.append("processingLayerId", this.brsFileUpload.processingLayerId);
    formData.append("tenantId", this.brsFileUpload.tenantId);
    formData.append("groupId", this.brsFileUpload.groupId);
    formData.append("entityId", this.brsFileUpload.entityId);
    formData.append("mProcessingLayerId", this.brsFileUpload.mProcessingLayerId);
    formData.append("mProcessingSubLayerId", this.brsFileUpload.mProcessingSubLayerId);
    formData.append("userId", this.brsFileUpload.userId);
    formData.append("fileUploaded", this.fileUploaded);

    this.fileupload = formData;

    console.log("Data  ",this.fileupload);
    this.fileUploadService.postFileToServer(this.fileupload)
      .subscribe(
      recieveddata  => {   
        let tempresponsedata = recieveddata;
        console.log("Fileuploadresponse---", tempresponsedata)
        this.fileupload="";
        this.fileupload = tempresponsedata;
        if(this.fileupload.Status === "Success")
        {
          alert("File Uploaded Successfully!!!");
          this.externalFileInput.nativeElement.value = '';
          this.internalFileInput.nativeElement.value = '';
          this.brsFileUpload.externalFileName = undefined;
          this.brsFileUpload.internalFileName = undefined;
          this.getFileUploadedList();
          this.ngxService.stop();
        }
        else if(this.fileupload.Status === "Error")
        {
          alert("Error in Upload File. Kindly Contact Advents Support!!!");
          this.externalFileInput.nativeElement.value = '';
          this.internalFileInput.nativeElement.value = '';
          this.brsFileUpload.externalFileName = undefined;
          this.brsFileUpload.internalFileName = undefined;
          this.getFileUploadedList();
          this.ngxService.stop();
        }
        else if(this.fileupload.Status === "File Exists")
        {
          alert("File already exists in Batch for the choosen Relationship Type. Kindly Upload after some time!!!");
          this.externalFileInput.nativeElement.value = '';
          this.internalFileInput.nativeElement.value = '';
          this.brsFileUpload.externalFileName = undefined;
          this.brsFileUpload.internalFileName = undefined;
          this.getFileUploadedList();
          this.ngxService.stop();
        }
      },
      (error: any) => { 
        this.HandleErrorResponse(error);
        this.externalFileInput.nativeElement.value = '';
        this.internalFileInput.nativeElement.value = '';
        this.brsFileUpload.externalFileName = undefined;
        this.brsFileUpload.internalFileName = undefined;
        this.getFileUploadedList();
        this.ngxService.stop();
    });
  }
}


getSelectedProcessingLayer(processingLayerId)
{
  this.brsFileUpload.processingLayerId = processingLayerId;
}

getFileUploadedList(){

  let data = {
    "tenantId": this.brsFileUpload.tenantId,
    "groupId": this.brsFileUpload.groupId,
    "entityId": this.brsFileUpload.entityId,
    "mProcessingLayerId": this.brsFileUpload.mProcessingLayerId,
    "mProcessingSubLayerId": this.brsFileUpload.mProcessingSubLayerId,
    "userId": this.brsFileUpload.userId
  };

  this.fileUploadService.getFileListFromServer(data)
  .subscribe(
    receivedData => {
      let responseData = receivedData;
      console.log("File Data Response, ", responseData);
      if (responseData["Status"] === "Success")
      {
        let fileUploadListData = responseData["file_upload_data_list"];
        console.log(fileUploadListData);
        let fileColumnDefs = fileUploadListData["headers"];

        fileColumnDefs.forEach((item, index) =>
        {
          if(item.sortable=="true")
          {
            item.sortable=true;
            item.filter=true;
            item.resizable=true;
            item.suppressAutoSize=true;
            item.suppressSizeToFit=true;
          }
        });
        this.fileColumnDefs = fileColumnDefs;
        this.fileRowData = fileUploadListData["data"];
      }
      else if(responseData["Status"] === "Error")
      {
        console.log("Error in Getting File Uploaded Data List!!!")
      }
    }
  )
}

refreshFileUploadList()
{
  this.getFileUploadedList();
}


HandleErrorResponse(err: any)
{
  console.log("Error",err);
}

previewconsoldoc(doc)
{

}

onRowSelected(event)
{

}

}

