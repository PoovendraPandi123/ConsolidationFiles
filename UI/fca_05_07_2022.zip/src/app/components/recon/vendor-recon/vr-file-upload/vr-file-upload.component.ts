import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { AgGridAngular } from 'ag-grid-angular';
import { VrFileUploadService } from 'src/app/services/recon/vendor-recon/vr-file-upload.service';
import { NgxUiLoaderService } from "ngx-ui-loader"; // Import NgxUiLoaderService
import { VrFileUpload } from './vr-file-upload.model';

@Component({
  selector: 'app-vr-file-upload',
  templateUrl: './vr-file-upload.component.html',
  styleUrls: ['./vr-file-upload.component.css']
})
export class VrFileUploadComponent implements OnInit {

  @ViewChild('externalFileInput', {static: false})
  externalFileInput: ElementRef;

  @ViewChild('internalFileInput', {static: false})
  internalFileInput : ElementRef;

  @ViewChild('agGrid')
  agGrid!: AgGridAngular;

  public userdtl;
  public sourcedata;
  public processinglayerlist;
  public objprocessid;
  public fileupload;
  public fileuploadlist;

  public paginationSize;
  public file_records;
  public pagination;
  public fileData;

  public userModelList :  any;
  public processingLayerIdsUser :  any;
  public selectProcessingLayer : any;
  public fileUploaded : any;
  public fileRowData : any;
  public fileColumnDefs :  any;

  public vrFileUpload : VrFileUpload;

  public columnDefs = [
    { field: 'File Name', headerText: 'File Name', sortable: true, filter: true},
    { field: 'Size(mb)', sortable: true, filter: true },
    { field: 'UploadDate', sortable: true, filter: true },
    { field: 'UploadBy', sortable: true, filter: true },
    { field: 'UploadStatus', sortable: true, filter: true },
    { field: 'Validation', sortable: true, filter: true },
    { field: 'Status', sortable: true, filter: true },
    { field: 'ProcessTime', sortable: true, filter: true },
  ];

  public rowData : any;

  constructor(private fileUploadService: VrFileUploadService, private ngxService: NgxUiLoaderService) { }

  shortLink: string = "";
  loading: boolean = false; 
  file: File = null; 

  public ngOnInit(): void {

    this.vrFileUpload = new VrFileUpload();
    this.userModelList = JSON.parse(sessionStorage.getItem("user_model_list"));
    this.vrFileUpload.userId = JSON.parse(sessionStorage.getItem("user_details"))["user_id"];
    this.vrFileUpload.tenantId = this.userModelList["tenant_id"];
    this.vrFileUpload.groupId = this.userModelList["group_id"];
    this.vrFileUpload.entityId = this.userModelList["entity_id"];
    this.vrFileUpload.mProcessingLayerId = this.userModelList["m_processing_layer_id"];
    this.vrFileUpload.mProcessingSubLayerId = this.userModelList["m_processing_sub_layer_id"];
    this.processingLayerIdsUser = this.userModelList["processing_layer_ids"];

    this.userdtl=JSON.parse(sessionStorage.getItem('user_details'));
    this.getProcessingLayerList();
    this.selectProcessingLayer = {
      "processing_layer_id" : 0
    };
    this.getFileUploadList();

    this.pagination=true;
    this.paginationSize = 15;
    this.file_records=[];

    this.fileColumnDefs =  [
      {headerName: 'Relationship Name', field: 'processing_layer_name', resizable: true},
      {headerName: 'Extraction Type', field: 'extraction_type', resizable: true},
      {headerName: 'File Name', field: 'file_name', resizable: true},
      {headerName: 'File Size (Bytes)', field: 'file_size_bytes', resizable: true},
      {headerName: 'Status', field: 'status', resizable: true},
      {headerName: 'Comments', field: 'comments', resizable: true, width: 300},
      {headerName: 'Uploaded Date', field: 'created_date', resizable: true}
    ];

    this.getFileUploadedList();

  }

  public getProcessingLayerList() : void {
    this.ngxService.start();
    // console.log("userdetails ",this.userdtl);
    let Indata = {
      "tenantId" : this.vrFileUpload.tenantId,
      "groupId" : this.vrFileUpload.groupId,
      "entityId" : this.vrFileUpload.entityId,
      "mProcessingLayerId" : this.vrFileUpload.mProcessingLayerId,
      "mProcessingSubLayerId" : this.vrFileUpload.mProcessingSubLayerId,
      "typeId": JSON.parse(sessionStorage.getItem("user_model_list"))["type_id"]
    }
    // console.log("inputfilterrecon",Indata);
    this.fileUploadService.getProcessingLayerListFromServer(Indata)
    .subscribe(
    recieveddata  => {
      let tempresponsedata = recieveddata;
      console.log("filterlistresponse---",tempresponsedata)
      this.sourcedata=tempresponsedata;
      this.processinglayerlist=this.sourcedata.processing_layer_list;
      this.ngxService.stop();
    });
  }

  public getFileUploadList() : void {
    let Indata={
      "tenant_id": this.vrFileUpload.tenantId,
      "group_id": this.vrFileUpload.groupId,
      "entity_id": this.vrFileUpload.entityId,
      "user_id": this.vrFileUpload.userId
    }
    console.log("fileuploadlistdata",Indata);
    this.fileUploadService.getFileListFromServer(Indata).subscribe(
      recieveddata  => {
        let tempresponsedata = recieveddata;
        console.log("filelistresponse---",tempresponsedata)
        this.sourcedata=tempresponsedata;
        this.fileuploadlist=this.sourcedata.recon_file_upload_list;
        console.log("FIle Upload List ",this.fileuploadlist);
        this.rowData = this.fileuploadlist;
        this.file_records = this.fileuploadlist;
    });
  }

  public onChange(event : any) {
    this.file = event.target.files[0];
  }

  public extFileOnChanged(event:any) {
    let files = event.target.files;
    this.vrFileUpload.externalFileName = files[0];
    console.log(files);
    console.log(this.vrFileUpload.externalFileName);
  }

  public intFileOnChanged(event:any) {
    let files = event.target.files;
    this.vrFileUpload.internalFileName = files[0];
    console.log(files);
    console.log(this.vrFileUpload.internalFileName);
  }

  public uploadAll() : void {

    console.log(this.vrFileUpload.processingLayerId);
  
    if (this.vrFileUpload.processingLayerId == "0" || this.vrFileUpload.processingLayerId === undefined)
    {
      alert("Kindly choose the Reconciliation Type!!!");
    }
    else if (this.vrFileUpload.externalFileName === undefined && this.vrFileUpload.internalFileName === undefined)
    {
      alert("Kindly Choose File and Upload!!!");
    }
    else
    {
      this.ngxService.start();
  
      if(this.vrFileUpload.externalFileName !== undefined && this.vrFileUpload.internalFileName !== undefined)
      {
        this.fileUploaded = "BOTH";
      }
      else if(this.vrFileUpload.externalFileName !== undefined && this.vrFileUpload.internalFileName === undefined)
      {
        this.fileUploaded = "EXTERNAL";
      }
      else if(this.vrFileUpload.externalFileName === undefined && this.vrFileUpload.internalFileName !== undefined)
      {
        this.fileUploaded = "INTERNAL";
      }
  
      const formData = new FormData();
  
      formData.append("internalFileName", this.vrFileUpload.internalFileName);
      formData.append("externalFileName ", this.vrFileUpload.externalFileName);
      formData.append("processingLayerId", this.vrFileUpload.processingLayerId);
      formData.append("tenantId", this.vrFileUpload.tenantId);
      formData.append("groupId", this.vrFileUpload.groupId);
      formData.append("entityId", this.vrFileUpload.entityId);
      formData.append("mProcessingLayerId", this.vrFileUpload.mProcessingLayerId);
      formData.append("mProcessingSubLayerId", this.vrFileUpload.mProcessingSubLayerId);
      formData.append("userId", this.vrFileUpload.userId);
      formData.append("fileUploaded", this.fileUploaded);
  
      this.fileupload = formData;
  
      console.log("Data  ",this.fileupload);
      this.fileUploadService.postFileToServer(this.fileupload)
        .subscribe(
        recieveddata  => {   
          let tempresponsedata = recieveddata;
          console.log("Fileuploadresponse---", tempresponsedata)
          this.fileupload="";
          this.fileupload = tempresponsedata;
          if(this.fileupload.Status === "Success")
          {
            alert("File Uploaded Successfully!!!");
            this.externalFileInput.nativeElement.value = '';
            this.internalFileInput.nativeElement.value = '';
            this.vrFileUpload.externalFileName = undefined;
            this.vrFileUpload.internalFileName = undefined;
            this.getFileUploadedList();
            this.ngxService.stop();
          }
          else if(this.fileupload.Status === "Error")
          {
            alert("Error in Upload File. Kindly Contact Advents Support!!!");
            this.externalFileInput.nativeElement.value = '';
            this.internalFileInput.nativeElement.value = '';
            this.vrFileUpload.externalFileName = undefined;
            this.vrFileUpload.internalFileName = undefined;
            this.getFileUploadedList();
            this.ngxService.stop();
          }
          else if(this.fileupload.Status === "File Exists")
          {
            alert("File already exists in Batch for the choosen Relationship Type. Kindly Upload after some time!!!");
            this.externalFileInput.nativeElement.value = '';
            this.internalFileInput.nativeElement.value = '';
            this.vrFileUpload.externalFileName = undefined;
            this.vrFileUpload.internalFileName = undefined;
            this.getFileUploadedList();
            this.ngxService.stop();
          }
        },
        (error: any) => { 
          this.HandleErrorResponse(error);
          this.externalFileInput.nativeElement.value = '';
          this.internalFileInput.nativeElement.value = '';
          this.vrFileUpload.externalFileName = undefined;
          this.vrFileUpload.internalFileName = undefined;
          this.getFileUploadedList();
          this.ngxService.stop();
      });
    }
  }

  public getSelectedProcessingLayer(processingLayerId) : void {
    this.vrFileUpload.processingLayerId = processingLayerId;
  }

  public getFileUploadedList() : void {
    this.ngxService.start();
    let data = {
      "tenantId": this.vrFileUpload.tenantId,
      "groupId": this.vrFileUpload.groupId,
      "entityId": this.vrFileUpload.entityId,
      "mProcessingLayerId": this.vrFileUpload.mProcessingLayerId,
      "mProcessingSubLayerId": this.vrFileUpload.mProcessingSubLayerId,
      "userId": this.vrFileUpload.userId
    };

    this.fileUploadService.getFileListFromServer(data).subscribe(
      receivedData => {
        let responseData = receivedData;
        console.log("File Data Response, ", responseData);
        this.fileRowData = responseData;
        this.ngxService.stop();
      },
      (error : any) => {
        this.HandleErrorResponse(error);
        this.ngxService.stop();
      }
    );

  }

  public refreshFileUploadList() : void {
    this.getFileUploadedList();
  }

  public HandleErrorResponse(err : any) : void {
    console.log(err);
  }

}
