export class VrFileUpload
{
        public internalFileName: any;
        public externalFileName: any;
        public tenantId: any;
        public groupId: any;
        public entityId: any;
        public mProcessingLayerId: any;
        public mProcessingSubLayerId: any;
        public processingLayerId: any;
        public userId: any;
    constructor(        
        
    ){}

}