import { Component, OnInit, ViewChild } from '@angular/core';
import { AgGridAngular } from 'ag-grid-angular';
import { ChartType} from 'chart.js';
import { VrLandingPageService } from 'src/app/services/recon/vendor-recon/vr-landing-page.service';
import { NgxUiLoaderService } from "ngx-ui-loader"; // Import NgxUiLoaderService

@Component({
  selector: 'app-vr-landing-page',
  templateUrl: './vr-landing-page.component.html',
  styleUrls: ['./vr-landing-page.component.css']
})
export class VrLandingPageComponent implements OnInit {

  public reconTimelineOptions = {
    scaleShowVerticalLines: false,
    responsive: true,
    scales: {
      yAxes: [{
        scaleLabel: {
          display: true,
          labelString: 'Vendor Count',
          fontColor : '#004e98',
        },
        gridLines : {
          "display": false
        }
      }],
      xAxes: [{
        scaleLabel: {
          display: true,
          labelString: 'Month'
        },
        gridLines : {
          "display": false
        }
      }]
    },
    title : {
      display : true,
      text : "Reconciliation Timeline",
      fontSize : 14,
      fontColor : '#004e98',
    },
    legend : {
      position : "right",
      display : false
    }
  };

  public reconTimelineLabels = ["Apr", "May", "Jun", "July", "Aug", "Sep", "Oct", "Nov", "Dec", "Jan", "Feb", "Mar"];
  public reconTimelineBarChartType: ChartType = 'bar';
  public reconTimelineLegend = true;
  public reconTimelineData = [{ data : [500, 200, 1000, 100, 150, 1500, 400, 183, 1200, 150, 180, 2500], label : "Count"}];
  public reconTimelineColorOptions = [{backgroundColor: ['#30637F', '#30637F', '#30637F', '#30637F', '#30637F', '#30637F', '#30637F', '#30637F', '#30637F', '#30637F', '#30637F', '#30637F']}];

  public vendorBalanceOptions = {
    scaleShowVerticalLines: false,
    responsive: true,
    scales: {
      yAxes: [{
        scaleLabel: {
          display: true,
          labelString: 'Vendor Balance',
          fontColor : '#004e98',
        },
        gridLines : {
          "display": false
        }
      }],
      xAxes: [{
        scaleLabel: {
          display: true,
          labelString: 'Vendor Names'
        },
        gridLines : {
          "display": false
        }
      }]
    },
    title : {
      display : true,
      text : "Top 10 Vendor Balances",
      fontSize : 14,
      fontColor : '#004e98',
    },
    legend : {
      position : "right",
      display : false
    }
  };

  public vendorBalanceLabels = ["Airtel" , "Sona Enterprise" , "Shreejee" , "Friends Engineering works" , "Reliance" , "Fireeye" , "Zensar" , "Verse" , "Apisero" , "Cipla" , "MediAssist"];
  public vendorBalanceBarChartType: ChartType = 'bar';
  public vendorBalanceLegend = true;
  public vendorBalanceData = [{ data : ['148566.00' , '138866.25' , '134565.02' , '125894.25' , '114885.58' , '105898.25' , '100589.00' , '95658.29' , '95142.00' , '90052.11'], label : "Count"}];
  public vendorBalanceColorOptions = [{backgroundColor: ['#30637F', '#30637F', '#30637F', '#30637F', '#30637F', '#30637F', '#30637F', '#30637F', '#30637F', '#30637F']}];


  public barChartOptions = {
    scaleShowVerticalLines: false,
    responsive: true,
    scales: {
      yAxes: [{
        scaleLabel: {
          display: true,
          labelString: 'Transaction Count',
          fontColor : '#004e98',
        },
        gridLines : {
          "display": true
        }
      }],
      xAxes: [{
        scaleLabel: {
          display: true,
          // labelString: 'Vendors'
        },
        gridLines : {
          "display": true
        }
      }]
    },
    title : {
      display : true,
      text : "Customer1",
      fontSize : 14,
      fontColor : '#004e98',
    },
    legend : {
      position : "right",
      display : false
    }
  };
  public barChartLabels = ["Matched", "GroupMatched", "UnMatched"];
  public barChartType: ChartType = 'bar';
  public barChartLegend = true;
  public barChartData = [{ data : [2500,500,250], label : "Transaction"}];
  public colorOptions = [{backgroundColor: ['#30637F', '#D6B154', '#DDF56A']}]

  public barChartOptions1 = {
    scaleShowVerticalLines: false,
    responsive: true,
    scales: {
      yAxes: [{
        scaleLabel: {
          display: true,
          labelString: 'Transaction Count',
          fontColor : '#3262a8',
        }
      }],
      xAxes: [{
        scaleLabel: {
          display: true,
          fontColor : '#3262a8',
          // labelString: 'Vendors'
        }
      }]
    },
    title : {
      display : true,
      text : "SBI 98342",
      fontSize : 14,
      fontColor : '#004e98',
    },
    legend : {
      position : "right",
      display : false
    }
  };
  public barChartLabels1 = ["Matched", "GroupMatched", "Contra"];
  public barChartType1: ChartType = 'line';
  public barChartLegend1 = true;
  public barChartData1 = [{ data : [2500,500,250], backgroundColor: '#3262a8', label : "Transaction"}];

  public barChartOptions2 = {
    scaleShowVerticalLines: false,
    responsive: true,
    title : {
      display : true,
      text : "HDFC 062",
      fontSize : 14,
      fontColor : '#004e98',
    },
    legend : {
      position : "right",
      display : true
    }
  };
  public barChartLabels2 = ["Matched", "GroupMatched", "UnMatched"];
  public barChartType2: ChartType = 'pie';
  public barChartLegend2 = true;
  public barChartData2 = [{ data : [2500,500,250], backgroundColor: ['#856969', '#CEC6C6', '#93C2D3']}];

  public barChartOptions3 = {
    scaleShowVerticalLines: false,
    responsive: true,
    title : {
      display : true,
      text : "Recon Summary",
      fontSize : 14,
      fontColor : '#48CAE4',
    },
    legend : {
      position : "right",
      display : true
    }
  };
  public barChartLabels3 = ["Loading", "Matched", "Completed"];
  public barChartType3: ChartType = 'doughnut';
  public barChartLegend3 = true;
  public barChartData3 = [{ data : [25,50,500], backgroundColor: ['#b8b2b7', '#ed87a9', '#6989b3']}];

  public barChartOptions4 = {
    scaleShowVerticalLines: false,
    responsive: true,
    scales: {
      yAxes: [{
        scaleLabel: {
          display: true,
          labelString: 'No.of Transaction'
        }
      }],
      xAxes: [{
        scaleLabel: {
          display: true,
          // labelString: 'Vendors'
        }
      }]
    },
    title : {
      display : true,
      text : "Fineshed Task",
      fontSize : 14,
      fontColor : '#48CAE4',
    },
    legend : {
      position : "right",
      display : false
    }
  };
  public barChartLabels4 = ["label1", "label2", "label3", "label4"];
  public barChartType4: ChartType = 'horizontalBar';
  public barChartLegend4 = true;
  public barChartData4 = [{ data : [2,5,6,9], label : "Transaction"}];

  public barChartOptions5 = {
    scaleShowVerticalLines: false,
    responsive: true,
    indexAxis: 'y',
    scales: {
      yAxes: [{
        scaleLabel: {
          display: true,
          labelString: 'No.of Transaction',
          fontColor : '#3262a8',
        }
      }],
      xAxes: [{
        scaleLabel: {
          display: true,
          fontColor : '#3262a8',
          // labelString: 'Vendors'
        }
      }],
      legend: {
        position: 'right',
      },
    },
    title : {
      display : true,
      text : "Today's Task",
      fontSize : 14,
      fontColor : '#48CAE4',
    },
    legend : {
      position : "right",
      display : false
    }
  };
  public barChartLabels5 = ["Matched", "GroupMatched", "open", "Loading"];
  public barChartType5: ChartType = 'line';
  public barChartLegend5 = true;
  public barChartData5 = [{ data : [10000,3000,250, 5000], backgroundColor: '#3262a8', label : "Transaction"}];

  public barChartOptions6 = {
    scaleShowVerticalLines: false,
    responsive: true,
    title : {
      display : true,
      text : "Weekly Task",
      fontSize : 14,
      fontColor : '#48CAE4',
    },
    legend : {
      position : "right",
      display : true
    }
  };
  public barChartLabels6 = ["Matched", "GroupMatched", "open"];
  public barChartType6: ChartType = 'pie';
  public barChartLegend6 = true;
  public barChartData6 = [{ data : [500,400,350], backgroundColor: ['#48CAE4','#e88bc6','#a89532']}];

  public barChartOptions7 = {
    scaleShowVerticalLines: false,
    responsive: true,
    title : {
      display : true,
      text : "Monthly Task",
      fontSize : 14,
      fontColor : '#48CAE4',
    },
    legend : {
      position : "right",
      display : true
    }
  };
  public barChartLabels7 = ["Loading", "Matched", "Completed"];
  public barChartType7: ChartType = 'doughnut';
  public barChartLegend7 = true;
  public barChartData7 = [{ data : [25,50,80], backgroundColor: ['#b8b2b7', '#ed87a9', '#6989b3']}];

  public groupList : any;

  constructor(private landingService: VrLandingPageService, private ngxService: NgxUiLoaderService) { }

  public ngOnInit(): void {
  }

}
