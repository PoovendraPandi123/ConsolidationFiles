import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VrMatchingCommentsComponent } from './vr-matching-comments.component';

describe('VrMatchingCommentsComponent', () => {
  let component: VrMatchingCommentsComponent;
  let fixture: ComponentFixture<VrMatchingCommentsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ VrMatchingCommentsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(VrMatchingCommentsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
