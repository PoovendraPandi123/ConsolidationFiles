import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-brs-report',
  templateUrl: './brs-report.component.html',
  styleUrls: ['./brs-report.component.css']
})
export class BrsReportComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
