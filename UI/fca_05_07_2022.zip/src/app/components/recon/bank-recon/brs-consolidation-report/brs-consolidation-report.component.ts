import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-brs-consolidation-report',
  templateUrl: './brs-consolidation-report.component.html',
  styleUrls: ['./brs-consolidation-report.component.css']
})
export class BrsConsolidationReportComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
