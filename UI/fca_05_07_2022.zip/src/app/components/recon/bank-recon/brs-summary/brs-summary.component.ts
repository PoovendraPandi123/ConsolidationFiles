import { Component, OnInit, ViewChild } from '@angular/core';
import { AgGridAngular } from 'ag-grid-angular';
import { ChartType} from 'chart.js';
import { ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { BrsSummaryService } from 'src/app/services/recon/bank-recon/brs-summary.service';
import { JsonToExcelService } from 'src/app/services/common/json-to-excel.service';
import { NgxUiLoaderService } from "ngx-ui-loader"; // Import NgxUiLoaderService

@Component({
  selector: 'app-brs-summary',
  templateUrl: './brs-summary.component.html',
  styleUrls: ['./brs-summary.component.css']
})
export class BrsSummaryComponent implements OnInit {

  @ViewChild('agGrid')
  agGrid!: AgGridAngular;

  public barChartOptions = {
    scaleShowVerticalLines: false,
    responsive: true,
    title : {
      display : true,
      text : "RECONCILIATION SUMMARY",
      fontSize : 14,
      fontColor : '#004e98',
    },
    legend : {
      position : "right",
      display : true
    }
  };
  public barChartOptionsTransaction = {
    scaleShowVerticalLines: false,
    responsive: true,
    title : {
      display : true,
      text : "TRANSACTION TYPE",
      fontSize : 14,
      fontColor : '#004e98',
    },
    legend : {
      position : "right",
      display : false
    }
  };
  public barChartOptionsBrs = {
    scaleShowVerticalLines: false,
    responsive: true,
    title : {
      display : true,
      text : "BANK",
      fontSize : 14,
      fontColor : '#004e98',
    },
    legend : {
      position : "right",
      display : false
    }
  };
  public barChartLabels = [] as any;
  public barChartLabelsTransaction = ["Sweep", "Letters", "UTR", "Transfers"]
  public barChartLabelsBrs = ["Thermax DR", "Thermax CR", "Bank DR", "Bank CR"]
  public barChartType: ChartType = 'doughnut';
  public barChartTypeTransaction: ChartType = 'bar';
  public barChartTypeBrs: ChartType = 'bar';
  public barChartLegend = true;
  public barChartLegendTransaction = true;
  public barChartLegendBrs = true;
  public barChartData = [{ data : []}] as any;
  public barChartDataTransaction = [{data: [100, 247, 326, 451]}];
  public barChartDataBrs = [{data: [15248756, 1548745, 2354789, 567845]}];
  public colorOptions : any;
  public colorOptionsTransaction = [{backgroundColor: ['#acc3a6', '#547caf', '#e8cabf', '#ffa400']}]
  public colorOptionsBrs = [{backgroundColor: ['#acc3a6', '#547caf', '#e8cabf', '#ffa400']}];
  public editButtonEnable: boolean = false;
  public bankDate: string;

  public userModelList: any;
  public tenantId : any;
  public groupId : any;
  public entityId : any;
  public mProcessingLayerId : any;
  public mProcessingSubLayerId : any;
  public userId : any;
  public processingLayerIdsUser : any;
  public processingLayerList : any;
  public selectProcessingLayer : any;
  public processing_layer_id : Number;
  public pagination : boolean = false;
  public paginationSize : Number = 0;

  public matchedSearchGrid: boolean = false;
  public unMatchedSearchGrid: boolean = false;
  public groupMatchedSearchGrid: boolean = false;
  public contraSearchGrid: boolean = false;
  public groupUnMatchedSearchGrid: boolean = false;
  public allSearchGrid: boolean = false;

  public matchedDisplayGrid:boolean = false;
  public groupMatchedDisplayGrid: boolean = false;
  public unMatchedDisplayGrid:boolean = false;
  public contraDisplayGrid: boolean = false;
  public groupUnMatchedDisplayGrid: boolean = false;
  public allDisplayGrid: boolean = false;

  public displaySelectedMatchedGrid:boolean = false;
  public displaySelectedUnMatchedGrid:boolean = false;
  public displaySelectedGroupMatchedGrid: boolean = false;
  public displaySelectedContraGrid: boolean = false;
  public displaySelectedGroupUnMatchedGrid: boolean = false;

  public displaySelectedExternalGridContra: boolean = false;
  public displaySelectedInternalGridContra: boolean = false;

  public externalColumnDefs : any;
  public internalColumnDefs : any;
  public unMatchedExternalColumnDefs : any;
  public unMatchedInternalColumnDefs : any;
  public groupMatchedExternalColumnDefs : any;
  public groupMatchedInternalColumnDefs : any;
  public contraExternalColumnDefs : any;
  public contraInternalColumnDefs : any;
  public groupUnMatchedExternalColumnDefs : any;
  public groupUnMatchedInternalColumnDefs : any;
  public allExternalColumnDefs: any;
  public allInternalColumnDefs: any;

  public selectedUnMatchedExternalColumnDefs : any;
  public selectedUnMatchedInternalColumnDefs : any;
  public selectedGroupMatchedExternalColumnDefs: any;
  public selectedGroupMatchedInternalColumnDefs: any;
  public selectedContraExternalColumnDefs: any;
  public selectedContraInternalColumnDefs: any;
  public selectedGroupUnMatchedExternalColumnDefs: any;
  public selectedGroupUnMatchedInternalColumnDefs: any;

  public externalRowData : any;
  public internalRowData : any;
  public unMatchedExternalRowData : any;
  public unMatchedInternalRowData : any;
  public groupMatchedExternalRowData : any;
  public groupMatchedInternalRowData : any;
  public contraExternalRowData : any;
  public contraInternalRowData : any;
  public groupUnMatchedExternalRowData : any;
  public groupUnMatchedInternalRowData : any;
  public allExternalRowData : any;
  public allInternalRowData : any;

  public selectedUnMatchedExternalRowData : any;
  public selectedUnMatchedInternalRowData : any;
  public selectedGroupMatchedExternalRowData: any;
  public selectedGroupMatchedInternalRowData: any;
  public selectedContraExternalRowData: any;
  public selectedContraInternalRowData: any;
  public selectedGroupUnMatchedExternalRowData: any;
  public selectedGroupUnMatchedInternalRowData: any;

  public selectedExternalRowData : any;
  public SelectedinternalRowData : any;

  public externalGridApi : any;
  public internalGridApi : any;
  public externalUnMatchedGridApi : any;
  public internalUnMatchedGridApi : any;
  public externalGroupMatchedGridApi : any;
  public internalGroupMatchedGridApi : any;
  public externalContraGridApi: any;
  public internalContraGridApi: any;
  public externalGroupUnMatchedGridApi: any;
  public internalGroupUnMatchedGridApi: any;
  public externalAllGridApi: any;
  public internalAllGridApi: any;

  public externalGridColumnApi : any;
  public internalGridColumnApi : any;
  public externalUnMatchedGridColumnApi : any;
  public internalUnMatchedgridColumnApi : any;
  public externalGroupMatchedGridColumnApi : any;
  public internalGroupMatchedGridColummApi : any;
  public externalContraGridColumnApi : any;
  public internalContraGridColumnApi : any;
  public externalGroupUnMatchedColumnApi : any;
  public internalGroupUnMatchedColumnApi : any;
  public externalAllColumnApi : any;
  public internalAllColumnApi : any;

  public searchValue : any;
  public searchValueUnMatched : any;
  public searchValueGroupMatched : any;
  public searchValueContra: any;
  public searchValueGroupUnMatched : any;
  public searchValueAll : any;
  
  public matchButtonEnable : boolean = false;
  public contraButtonEnable: boolean = false;
  public contraUnmatchButtonEnable: boolean = false;

  public groupMatchButtonDisabled : boolean = true;
  public groupUnMatchedMatchButton : boolean;
  public groupUnMatchedUnMatchButton : boolean;

  public amountTolerance : any;
  
  public selectedUnMatchedExternalAmount : Number = 0.00;
  public selectedUnMatchedInternalAmount : Number = 0.00;
  public selectedGroupedUnMatchedExternalAmount : Number = 0.00;
  public selectedGroupedUnMatchedInternalAmount : Number = 0.00;

  public bankBalance : string = '0.00';
  public glBalance : string = '0.00';

  public totalSelectedUnMatchedAmount : Number = 0.00;
  public closeResult: any;
  public externalRecordsId: any;
  public matchingCommentsList: any;
  public matchingCommentIdchosen: string;
  public matchingCommentDescription: string;
  public buttonTypeClicked: string;

  constructor(private ngxService: NgxUiLoaderService, private summaryService: BrsSummaryService, public modalService: NgbModal, private excelService: JsonToExcelService) { 
    this.matchingCommentIdchosen = '0';
    this.matchingCommentDescription = '';
    this.buttonTypeClicked = '';
  }

  public ngOnInit(): void {
    this.userModelList = JSON.parse(sessionStorage.getItem("user_model_list"));
    this.userId = JSON.parse(sessionStorage.getItem("user_details"))["user_id"];
    this.tenantId = this.userModelList["tenant_id"];
    this.groupId = this.userModelList["group_id"];
    this.entityId = this.userModelList["entity_id"];
    this.mProcessingLayerId = this.userModelList["m_processing_layer_id"];
    this.mProcessingSubLayerId = this.userModelList["m_processing_sub_layer_id"];
    this.processingLayerIdsUser = this.userModelList["processing_layer_ids"];
    this.getTransactionCount();
    this.getProcessingLayerList();
    this.getMatchingComments();
    this.selectProcessingLayer = {
      "processing_layer_id":0
    };
    this.pagination = true;
    this.paginationSize = 10;
    this.groupUnMatchedMatchButton = false;
    this.groupUnMatchedUnMatchButton = false;
  }

  public open(content) {
    this.modalService.open(content, {ariaLabelledBy: 'modal-basic-title'}).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }

  public getUpdateButtonTypeClicked(buttonType: string) : void {
    this.buttonTypeClicked = buttonType;
  }

  public getProcessingLayerList() : void {
    this.ngxService.start();
    // console.log(this.userModelList);
    let data = {
      "tenantId" : this.tenantId,
      "groupId" : this.groupId,
      "entityId" : this.entityId,
      "mProcessingLayerId" : this.mProcessingLayerId,
      "mProcessingSubLayerId" : this.mProcessingSubLayerId,
      "typeId": JSON.parse(sessionStorage.getItem("user_model_list"))["type_id"]
    }

    this.summaryService.getProcessingLayerListFromServer(data)
    .subscribe(
      received_data => {
        let response_data = received_data;
        console.log("Processing Layer List Response: ", response_data);
        this.processingLayerList = response_data["processing_layer_list"];
        this.ngxService.stop();
      }
    )

  }

  public getMatchingComments() : void {
    let data = {};

    this.summaryService.getMatchingCommentsFromServer(data)
    .subscribe(
      receivedData => {
        let responseData = receivedData;
        console.log("Matching Comments Response ", responseData);
        this.matchingCommentsList = responseData;
      }
    ),
    (error : any) => {
      this.HandleErrorResponse(error);
    }
  }

  public getComments(matchingId : Number) : string {
    for (var i=0; i<this.matchingCommentsList.length; i++)
    {
      if(this.matchingCommentsList[i]["id"] == matchingId)
      {
        return this.matchingCommentsList[i]["description"];
      }
    }
  }

  public matchingCommentsChange() : void {
    this.matchingCommentDescription = this.getComments(Number(this.matchingCommentIdchosen));
  }

  public getSelectedProcessingLayer(processingLayerId : any) : void {
    this.ngxService.start();
    let processing_layer_id = Number(processingLayerId);
    this.processing_layer_id = Number(processingLayerId);

    let data = {
      "tenant_id" : this.tenantId,
      "group_id" : this.groupId,
      "entity_id" : this.entityId,
      "m_processing_layer_id" : this.mProcessingLayerId,
      "m_processing_sub_layer_id" : this.mProcessingSubLayerId,
      "processing_layer_id" : processing_layer_id
    }

    this.matchedDisplayGrid = false; // Hide the Matched grid
    this.unMatchedDisplayGrid = false; // Hide the Unmatched grid
    this.groupMatchedDisplayGrid = false; // Hide the Group Matched grid
    this.contraDisplayGrid = false; // Hide the Contra Grid
    this.groupUnMatchedDisplayGrid = false; // Hide the Group UnMatched Grid
    this.allDisplayGrid = false; // Hide the All Data Grid

    this.displaySelectedMatchedGrid = false; // Hide the Selected Matched Grid
    this.displaySelectedGroupMatchedGrid = false; // Hide the Selected Group Matched Grid
    this.displaySelectedUnMatchedGrid = false; // Hide the Selected UnMatched Grid
    this.displaySelectedContraGrid = false; // Hide the Selected Contra Grid
    this.displaySelectedGroupUnMatchedGrid = false; // Hide the Selected Group UnMatched Grid

    this.matchedSearchGrid = false; // Hide the Matched Search Option
    this.unMatchedSearchGrid = false; // Hide the UnMatched Search Option
    this.groupMatchedSearchGrid = false; // Hide the Group Matched Search Option
    this.contraSearchGrid = false; // Hide the Contra Search Option
    this.groupUnMatchedSearchGrid = false; // Hide the Group UnMatched Search Option
    this.allSearchGrid = false; // Hide the All Grid Search Option

    // Setting the column and Row definitions of grids to undefined
    this.externalColumnDefs = undefined;
    this.externalRowData = undefined;
    this.internalColumnDefs = undefined;
    this.internalRowData = undefined;

    this.unMatchedExternalColumnDefs = undefined;
    this.unMatchedExternalRowData = undefined;
    this.unMatchedInternalColumnDefs = undefined;
    this.unMatchedInternalRowData = undefined;

    this.contraExternalColumnDefs = undefined;
    this.contraExternalRowData = undefined;
    this.contraInternalColumnDefs = undefined;
    this.contraInternalRowData = undefined;

    this.groupMatchedExternalColumnDefs = undefined;
    this.groupMatchedExternalRowData = undefined;
    this.groupMatchedInternalColumnDefs = undefined;
    this.groupMatchedInternalRowData = undefined;

    this.groupUnMatchedExternalColumnDefs = undefined;
    this.groupUnMatchedExternalRowData = undefined;
    this.groupUnMatchedInternalColumnDefs = undefined;
    this.groupUnMatchedInternalRowData = undefined;

    this.allExternalColumnDefs = undefined;
    this.allExternalRowData = undefined;
    this.allInternalColumnDefs = undefined;
    this.allInternalRowData = undefined;

    this.selectedUnMatchedExternalColumnDefs = undefined;
    this.selectedUnMatchedExternalRowData = undefined;
    this.selectedUnMatchedInternalColumnDefs = undefined;
    this.selectedUnMatchedInternalRowData = undefined;

    this.selectedContraExternalRowData = undefined;
    this.selectedContraExternalColumnDefs = undefined;
    this.selectedContraInternalColumnDefs = undefined;
    this.selectedContraInternalRowData = undefined;

    this.selectedGroupMatchedInternalRowData = undefined;
    this.selectedGroupMatchedInternalColumnDefs = undefined;
    this.selectedGroupMatchedExternalRowData = undefined;
    this.selectedGroupMatchedExternalColumnDefs = undefined;

    this.selectedGroupUnMatchedExternalColumnDefs = undefined;
    this.selectedGroupUnMatchedInternalColumnDefs = undefined;
    this.selectedGroupUnMatchedExternalRowData = undefined;
    this.selectedGroupUnMatchedInternalRowData = undefined;

    if (processing_layer_id != 0)
    {
      this.summaryService.getTransactionCountFromServer(data)
      .subscribe(
        received_data => {
          let response_data = received_data;
          console.log("All Data Response: ", response_data);
          this.barChartLabels = response_data["label"];
          this.barChartData = [
            {
              data : response_data["data"]
            }
          ];
          this.colorOptions = [
            {
              backgroundColor: ['#acc3a6', '#547caf', '#e8cabf', '#ffa400', '#948bf8', '#CC9966']
            }
          ];
          // this.getBalances();
          this.ngxService.stop();
      },
      (error:any) => {
        this.HandleErrorResponse(error);
        this.ngxService.stop();
      })
    }
    else if(processing_layer_id == 0)
    {
      this.getTransactionCount();
      this.ngxService.stop();
    }
  }

  public getTransactionCount() : void {
    this.ngxService.start();
    let processing_layer_id = 0;

    let data = {
      "tenant_id" : this.tenantId,
      "group_id" : this.groupId,
      "entity_id" : this.entityId,
      "m_processing_layer_id" : this.mProcessingLayerId,
      "m_processing_sub_layer_id" : this.mProcessingSubLayerId,
      "processing_layer_id" : processing_layer_id
    }

    this.summaryService.getTransactionCountFromServer(data)
    .subscribe(
      received_data => {
        let response_data = received_data;
        console.log("All Data Response: ", response_data);
        this.barChartLabels = response_data["label"];
        this.barChartData = [
          {
            data : response_data["data"]
          }
        ];
        this.colorOptions = [
          {
            backgroundColor: ['#acc3a6', '#547caf', '#e8cabf', '#ffa400', '#948bf8']
          }
        ];
        this.ngxService.stop();
      },
      (error:any) => {
        this.HandleErrorResponse(error);
        this.ngxService.stop();
      }
    )

  }

  public onChartClick(event: any) : void {
    if (this.processing_layer_id === undefined || this.processing_layer_id == 0)
    {
      alert("Kindly Choose Reconciliation Type!!!");
    }
    else
    {
      // this.ngxService.start();
      if (event.active.length > 0) {
        const chart = event.active[0]._chart;
        const activePoints = chart.getElementAtEvent(event.event);
        if ( activePoints.length > 0) 
        {
          // get the internal index of slice in pie chart
          const clickedElementIndex = activePoints[0]._index;
          const label = chart.data.labels[clickedElementIndex];
          // get value by index
          const value = chart.data.datasets[0].data[clickedElementIndex];
          // console.log(clickedElementIndex, label, value);
          console.log(label);

          let processing_layer_id = this.processing_layer_id;
          let record_status = label;

          let data = {
            "tenant_id" : this.tenantId,
            "group_id" : this.groupId,
            "entity_id" : this.entityId,
            "m_processing_layer_id" : this.mProcessingLayerId,
            "m_processing_sub_layer_id" : this.mProcessingSubLayerId,
            "processing_layer_id" : processing_layer_id,
            "record_status" : record_status
          }

          if(record_status === "Matched")
          {
            this.unMatchedSearchGrid = false; // Hide the UnMatched Search Option
            this.matchedSearchGrid = true; // Display the Matched Search Option
            this.matchedDisplayGrid = true; // Display the Matched grid
            this.unMatchedDisplayGrid = false; // Hide the Unmatched grid
            this.displaySelectedMatchedGrid = false; // Display the Selected Matched grid
            this.displaySelectedUnMatchedGrid = false; // Hide the Selected UnMatched grid
            this.groupMatchedDisplayGrid = false; // Hide the Group Matched Grid
            this.groupMatchedSearchGrid = false; // Hide the Group Matched Search Option
            this.displaySelectedGroupMatchedGrid = false; // Hide the Selected Group Matched Grid
            this.contraSearchGrid = false; // Hide the Contra Search Option
            this.contraDisplayGrid = false; // Hide the Contra Gid
            this.displaySelectedContraGrid = false; // Hide the Selected Contra Grid
            this.groupUnMatchedDisplayGrid = false; // Hide the Group UnMatched Grid
            this.groupUnMatchedSearchGrid = false; // Hide the Group UnMatched Search Option
            this.displaySelectedGroupUnMatchedGrid = false; // Hide the Selected Group UnMatched Grid
            this.allDisplayGrid = false; // Hide the All Data display Grid
            this.allSearchGrid = false; // Hide the All Data Search Option
            this.selectedUnMatchedExternalRowData = '';
            this.selectedUnMatchedInternalRowData = '';
            this.matchedGridShow(data);
          }
          else if(record_status === "UnMatched")
          {
            this.unMatchedSearchGrid = true; // Hide the UnMatched Search Option
            this.matchedSearchGrid = false; // Hide the Matched Search Option
            this.matchedDisplayGrid = false; // Hide the Matched grid
            this.unMatchedDisplayGrid = true; // Display the Unmatched grid
            this.displaySelectedMatchedGrid = false; // Hide the Selected Matched grid
            this.displaySelectedUnMatchedGrid = false; // Hide the Selected UnMatched grid
            this.groupMatchedDisplayGrid = false; // Hide the Group Matched Grid
            this.groupMatchedSearchGrid = false; // Hide the Group Matched Search Option
            this.displaySelectedGroupMatchedGrid = false; // Hide the Selected Group Matched Grid
            this.contraSearchGrid = false; // Hide the Contra Search Option
            this.contraDisplayGrid = false; // Hide the Contra Gid
            this.displaySelectedContraGrid = false; // Hide the Selected Contra Grid
            this.groupUnMatchedDisplayGrid = false; // Hide the Group UnMatched Grid
            this.groupUnMatchedSearchGrid = false; // Hide the Group UnMatched Search Option
            this.displaySelectedGroupUnMatchedGrid = false; // Hide the Selected Group UnMatched Grid
            this.allDisplayGrid = false; // Hide the All Data display Grid
            this.allSearchGrid = false; // Hide the All Data Search Option
            this.selectedUnMatchedExternalRowData = '';
            this.selectedUnMatchedInternalRowData = '';
            this.unMatchedGridShow(data);
          }
          else if(record_status === "GroupMatched")
          {
            this.unMatchedSearchGrid = false; // Hide the UnMatched Search Option
            this.matchedSearchGrid = false; // Hide the Matched Search Option
            this.matchedDisplayGrid = false; // Hide the Matched Grid
            this.unMatchedDisplayGrid = false;  // Hide the UnMatched Grid
            this.displaySelectedMatchedGrid = false; // Hide the Selectd Matched Grid
            this.displaySelectedUnMatchedGrid = false;  // Hide the Selected UnMatched Grid
            this.groupMatchedDisplayGrid = true; // Display the Group Matched Grid
            this.groupMatchedSearchGrid = true; // Disaply the Group Matched Search Option
            this.displaySelectedGroupMatchedGrid = false; // Hide the selected Group Matched Grid
            this.contraSearchGrid = false; // Hide the Contra Search Option
            this.contraDisplayGrid = false; // Hide the Contra Gid
            this.displaySelectedContraGrid = false; // Hide the Selected Contra Grid
            this.groupUnMatchedDisplayGrid = false; // Hide the Group UnMatched Grid
            this.groupUnMatchedSearchGrid = false; // Hide the Group UnMatched Search Option
            this.displaySelectedGroupUnMatchedGrid = false; // Hide the Selected Group UnMatched Grid
            this.allDisplayGrid = false; // Hide the All Data display Grid
            this.allSearchGrid = false; // Hide the All Data Search Option
            this.selectedUnMatchedExternalRowData = '';
            this.selectedUnMatchedInternalRowData = '';
            this.groupMatchedShow(data);
          }
          else if(record_status === "Contra")
          {
            this.unMatchedSearchGrid = false; // Hide the UnMatched Search Option
            this.matchedSearchGrid = false; // Hide the Matched Search Option
            this.matchedDisplayGrid = false; // Hide the Matched Grid
            this.unMatchedDisplayGrid = false;  // Hide the UnMatched Grid
            this.displaySelectedMatchedGrid = false; // Hide the Selectd Matched Grid
            this.displaySelectedUnMatchedGrid = false;  // Hide the Selected UnMatched Grid
            this.groupMatchedDisplayGrid = false; // Display the Group Matched Grid
            this.groupMatchedSearchGrid = false; // Disaply the Group Matched Search Option
            this.displaySelectedGroupMatchedGrid = false; // Hide the selected Group Matched Grid
            this.selectedUnMatchedExternalRowData = '';
            this.selectedUnMatchedInternalRowData = '';
            this.displaySelectedContraGrid = false; // Hide the Selected Contra Grid
            this.contraSearchGrid = true; // Display the Contra Search Option
            this.contraDisplayGrid = true; // Display the Contra Gid
            this.groupUnMatchedDisplayGrid = false; // Hide the Group UnMatched Grid
            this.groupUnMatchedSearchGrid = false; // Hide the Group UnMatched Search Option
            this.displaySelectedGroupUnMatchedGrid = false; // Hide the Selected Group UnMatched Grid
            this.allDisplayGrid = false; // Hide the All Data display Grid
            this.allSearchGrid = false; // Hide the All Data Search Option
            this.contraShow(data);
          }
          else if(record_status === "GroupUnMatched")
          {
            this.unMatchedSearchGrid = false; // Hide the UnMatched Search Option
            this.matchedSearchGrid = false; // Hide the Matched Search Option
            this.matchedDisplayGrid = false; // Hide the Matched Grid
            this.unMatchedDisplayGrid = false;  // Hide the UnMatched Grid
            this.displaySelectedMatchedGrid = false; // Hide the Selectd Matched Grid
            this.displaySelectedUnMatchedGrid = false;  // Hide the Selected UnMatched Grid
            this.groupMatchedDisplayGrid = false; // Display the Group Matched Grid
            this.groupMatchedSearchGrid = false; // Disaply the Group Matched Search Option
            this.displaySelectedGroupMatchedGrid = false; // Hide the selected Group Matched Grid
            this.selectedUnMatchedExternalRowData = '';
            this.selectedUnMatchedInternalRowData = '';
            this.displaySelectedContraGrid = false; // Hide the Selected Contra Grid
            this.contraSearchGrid = false; // Display the Contra Search Option
            this.contraDisplayGrid = false; // Display the Contra Gid
            this.groupUnMatchedDisplayGrid = true; // Hide the Group UnMatched Grid
            this.groupUnMatchedSearchGrid = true; // Hide the Group UnMatched Search Option
            this.displaySelectedGroupUnMatchedGrid = false; // Hide the Selected Group UnMatched Grid
            this.allDisplayGrid = false; // Hide the All Data display Grid
            this.allSearchGrid = false; // Hide the All Data Search Option
            this.groupUnMatchedShow(data);
          }
          else if (record_status === "All")
          {
            this.unMatchedSearchGrid = false; // Hide the UnMatched Search Option
            this.matchedSearchGrid = false; // Hide the Matched Search Option
            this.matchedDisplayGrid = false; // Hide the Matched Grid
            this.unMatchedDisplayGrid = false;  // Hide the UnMatched Grid
            this.displaySelectedMatchedGrid = false; // Hide the Selectd Matched Grid
            this.displaySelectedUnMatchedGrid = false;  // Hide the Selected UnMatched Grid
            this.groupMatchedDisplayGrid = false; // Display the Group Matched Grid
            this.groupMatchedSearchGrid = false; // Disaply the Group Matched Search Option
            this.displaySelectedGroupMatchedGrid = false; // Hide the selected Group Matched Grid
            this.selectedUnMatchedExternalRowData = '';
            this.selectedUnMatchedInternalRowData = '';
            this.displaySelectedContraGrid = false; // Hide the Selected Contra Grid
            this.contraSearchGrid = false; // Display the Contra Search Option
            this.contraDisplayGrid = false; // Display the Contra Gid
            this.groupUnMatchedDisplayGrid = false; // Hide the Group UnMatched Grid
            this.groupUnMatchedSearchGrid = false; // Hide the Group UnMatched Search Option
            this.displaySelectedGroupUnMatchedGrid = false; // Hide the Selected Group UnMatched Grid
            this.allDisplayGrid = true; // Hide the All Data display Grid
            this.allSearchGrid = true; // Hide the All Data Search Option
            this.allRecordsShow(data);
          }
        }
      }
    }
    // this.ngxService.stop();
  }

  public matchedGridShow(data : any)
  {
    this.ngxService.start();
    this.summaryService.getTransactionRecordsFromServer(data)
    .subscribe(
      received_data => {
        let response_data = received_data;
        console.log("Matched Chart Click Response: ", response_data);

        let externalRecordsAllColumnDefs = response_data["external_records"]["headers"];
        let externalRecordsAllrowData = response_data["external_records"]["data"];
        let internalRecordsAllColumnDefs = response_data["internal_records"]["headers"];
        let internalRecordsAllrowData = response_data["internal_records"]["data"];
        this.amountTolerance = parseFloat(response_data["amount_tolerance"]);

        // External
        externalRecordsAllColumnDefs.forEach((item, index) => {
          if(item.sortable=="true"){
            if(index === 0){
              item["checkboxSelection"] = true;
              item["maxWidth"] = 40;
              item["pinned"] = 'left';
              item.sortable=true;
              item.filter=false;
              item.resizable=false;
              item.suppressAutoSize=true;
              item.suppressSizeToFit=true;
              item.lockPosition=true;
            }
            else if (index !== 0){
              item.sortable=true;
              item.filter=true;
              item.resizable=true;
              item.suppressAutoSize=true;
              item.suppressSizeToFit=true;
              item["minWidth"] = 50;
            }

            // Hiding
            if (item.field === "external_records_id" || item.field === "external_contra_id" || item.field === "external_group_id" || item.field === "ext_processing_status_1" || item.field === "external_debit" || item.field === "external_credit")
            {
              item["hide"] = true;
            }

          }
        });

        // console.log(externalRecordsAllColumnDefs);

        this.externalColumnDefs = externalRecordsAllColumnDefs;
        this.externalRowData = externalRecordsAllrowData;

        // Internal
        internalRecordsAllColumnDefs.forEach((item, index) => {
          if(item.sortable=="true"){
            if(index === 0){
              item["checkboxSelection"] = true;
              item["maxWidth"] = 40;
              item["pinned"] = 'left';
              item.sortable=true;
              item.filter=false;
              item.resizable=false;
              item.suppressAutoSize=true;
              item.suppressSizeToFit=true;
              item.lockPosition=true;
            }
            else if (index !== 0){
              item.sortable=true;
              item.filter=true;
              item.resizable=true;
              item.suppressAutoSize=true;
              item.suppressSizeToFit=true;
              item["minWidth"] = 50;
            }

            // Hiding
            if (item.field === "internal_records_id" || item.field === "internal_contra_id" || item.field === "internal_group_id" || item.field === "int_processing_status_1" || item.field === "internal_debit" || item.field === "internal_credit")
            {
              item["hide"] = true;
            }

          }
        });

        this.internalColumnDefs = internalRecordsAllColumnDefs;
        this.internalRowData = internalRecordsAllrowData;
        this.ngxService.stop();

      },(error:any) => {
        this.HandleErrorResponse(error);
        this.ngxService.stop();
      })
  }

  public onExternalGridReady(params : any) : void {
    this.externalGridApi = params.api;
    this.externalGridColumnApi = params.columnApi;
  }

  public onInternalGridReady(params : any) : void {
    this.internalGridApi = params.api;
    this.internalGridColumnApi = params.columnApi;
  }

  public quickSearch() : void {
    this.internalGridApi.setQuickFilter(this.searchValue);
    this.externalGridApi.setQuickFilter(this.searchValue);
  }

  public onExportMatchedExternalExcelClick() : void {
    // const params = {
    //   columnGroups: true,
    //   allColumns: false,
    //   fileName: 'file.csv'
    // };
    // this.externalGridApi.exportDataAsCsv(params);
    this.ngxService.start();
    let excelExportData = [];

    let columnsNotRequired = ["ext_processing_status_1", "external_records_id", "external_contra_id", "external_group_id", "external_debit", "external_credit", ""];
    for (var i=0; i<this.externalRowData.length; i++)
    {
      let data = {};
      for (let key in this.externalRowData[i])
      {
        if(!columnsNotRequired.includes(key))
        {
          data[key] = this.externalRowData[i][key];
        }
      };
      excelExportData.push(data);
    };

    for (var i=0; i<excelExportData.length; i++)
    {
      excelExportData[i]["bank_credit"] = Number(excelExportData[i]["bank_credit"]);
      excelExportData[i]["bank_debit"] = Number(excelExportData[i]["bank_debit"].replace("-", ""));
    }

    // console.log("Excel Export", excelExportData);
    // console.log("External Row Data", this.externalRowData);



    // console.log("External Row Data", this.externalRowData)
    // for (var i=0; i<this.externalRowData.length; i++)
    // {
    //   excelExportData.push(this.externalRowData[i])
    // };

    // console.log("excelExportData ", excelExportData);

    // for (var i=0; i<excelExportData.length; i++)
    // {
    //   delete excelExportData[i]["ext_processing_status_1"];
    //   delete excelExportData[i]["external_records_id"];
    //   delete excelExportData[i][""];
    //   delete excelExportData[i]["external_contra_id"];
    //   delete excelExportData[i]["external_group_id"];
    //   delete excelExportData[i]["external_debit"];
    //   delete excelExportData[i]["external_credit"];
    //   excelExportData[i]["bank_credit"] = Number(excelExportData[i]["bank_credit"]);
    //   excelExportData[i]["bank_debit"] = Number(excelExportData[i]["bank_debit"].replace("-", ""));
    // };

    this.excelService.exportAsExcelFile(excelExportData, "Matched_Bank");
    this.ngxService.stop();
  }

  public onExportMatchedInternalExcelClick() : void {
    this.ngxService.start();
    let excelExportData = [];

    let columnsNotRequired = ["int_processing_status_1", "internal_contra_id", "internal_credit", "internal_debit", "internal_group_id", "internal_records_id", ""];
    for (var i=0; i<this.internalRowData.length; i++)
    {
      let data = {};
      for (let key in this.internalRowData[i])
      {
        if(!columnsNotRequired.includes(key))
        {
          data[key] = this.internalRowData[i][key];
        }
      };
      excelExportData.push(data);
    };

    for (var i=0; i<excelExportData.length; i++)
    {
      excelExportData[i]["gl_debit"] = Number(excelExportData[i]["gl_debit"]);
      excelExportData[i]["gl_credit"] = Number(excelExportData[i]["gl_credit"].replace("-", ""));
    }
    this.excelService.exportAsExcelFile(excelExportData, "Matched_GL");
    this.ngxService.stop();
  }

  public onExternalSelectionChanged(params : any) : void {
    try 
    {
      this.ngxService.start();
      this.displaySelectedMatchedGrid = true;
      this.selectedExternalRowData = params.api.getSelectedRows();

      let selectedExternalRecordsId = this.selectedExternalRowData[0]["external_records_id"];

      console.log(selectedExternalRecordsId);

      let data = {
        "tenant_id" : this.tenantId,
        "group_id" : this.groupId,
        "entity_id" : this.entityId,
        "m_processing_layer_id" : this.mProcessingLayerId,
        "m_processing_sub_layer_id" : this.mProcessingSubLayerId,
        "processing_layer_id" : this.processing_layer_id,
        "external_records_id" : selectedExternalRecordsId
      }

      this.summaryService.getIntExtRecordsFromServer(data)
      .subscribe(
        received_data => {
          let response_data = received_data;
          let internalRecords = response_data["internal_records"]["data"];
          console.log("Selected Internal Row Response: ", response_data);
          this.SelectedinternalRowData = internalRecords;
          this.ngxService.stop();
        },(error:any) => {this.HandleErrorResponse(error)})
    } 
    catch(error) 
    {
      this.SelectedinternalRowData = '';
      this.displaySelectedMatchedGrid = false;
      this.ngxService.stop();
    }
  }

  public onInternalSelectionChanged(params : any) : void {
    try
    {
      this.ngxService.start();
      this.displaySelectedMatchedGrid = true;
      this.SelectedinternalRowData = params.api.getSelectedRows();
      var selectedInternalRecordsId = this.SelectedinternalRowData[0]["internal_records_id"];
  
      let data = {
        "tenant_id" : this.tenantId,
        "group_id" : this.groupId,
        "entity_id" : this.entityId,
        "m_processing_layer_id" : this.mProcessingLayerId,
        "m_processing_sub_layer_id" : this.mProcessingSubLayerId,
        "processing_layer_id" : this.processing_layer_id,
        "internal_records_id" : selectedInternalRecordsId
      }
  
      this.summaryService.getIntExtRecordsFromServer(data)
      .subscribe(
        received_data => {
          let response_data = received_data;
          let externalRecords = response_data["external_records"]["data"];
          console.log("Selected External Row Response: ", response_data);
          this.selectedExternalRowData = externalRecords;
          this.ngxService.stop();
        },(error:any) => {this.HandleErrorResponse(error)})
    }
    catch(error)
    {
      this.selectedExternalRowData = '';
      this.displaySelectedMatchedGrid = false;
      this.ngxService.stop();
    }

  }

  public unMatchedGridShow(data : any) : void {
    this.ngxService.start();
    this.summaryService.getTransactionRecordsFromServer(data)
    .subscribe(
      received_data => {
        let response_data = received_data;
        console.log("UnMatched Chart Click Response: ", response_data);

        let externalRecordsAllColumnDefs = response_data["external_records"]["headers"];
        let externalRecordsAllrowData = response_data["external_records"]["data"];
        let internalRecordsAllColumnDefs = response_data["internal_records"]["headers"];
        let internalRecordsAllrowData = response_data["internal_records"]["data"];
        this.amountTolerance = parseFloat(response_data["amount_tolerance"]);

        // External
        externalRecordsAllColumnDefs.forEach((item, index) => {
          if(item.sortable=="true"){
            if(index === 0){
              item["checkboxSelection"] = true;
              item["maxWidth"] = 40;
              item["pinned"] = 'left';
              item.sortable=true;
              item.filter=false;
              item.resizable=false;
              item.suppressAutoSize=true;
              item.suppressSizeToFit=true;
              item["headerCheckboxSelection"] = true;
              item["headerCheckboxSelectionFilteredOnly"] = true;
              item.lockPosition=true;
            }
            else if (index !== 0){
              item.sortable=true;
              item.filter=true;
              item.resizable=true;
              item.suppressAutoSize=true;
              item.suppressSizeToFit=true;
              item["minWidth"] = 50;
            }

            // Hiding
            if (item.field === "external_records_id" || item.field === "external_contra_id" || item.field === "external_group_id" || item.field === "ext_processing_status_1" || item.field === "external_debit" || item.field === "external_credit")
            {
              item["hide"] = true;
            }

          }
        });

        this.unMatchedExternalColumnDefs = externalRecordsAllColumnDefs;
        this.unMatchedExternalRowData = externalRecordsAllrowData;

        // Internal
        internalRecordsAllColumnDefs.forEach((item, index) => {
          if(item.sortable=="true"){
            if(index === 0){
              item["checkboxSelection"] = true;
              item["maxWidth"] = 40;
              item["pinned"] = 'left';
              item.sortable=true;
              item.filter=false;
              item.resizable=false;
              item.suppressAutoSize=true;
              item.suppressSizeToFit=true;
              item["headerCheckboxSelection"] = true;
              item["headerCheckboxSelectionFilteredOnly"] = true;
              item.lockPosition=true;
            }
            else if (index !== 0){
              item.sortable=true;
              item.filter=true;
              item.resizable=true;
              item.suppressAutoSize=true;
              item.suppressSizeToFit=true;
              item["minWidth"] = 50;
            }

            // Hiding
            if (item.field === "internal_records_id" || item.field === "internal_contra_id" || item.field === "internal_group_id" || item.field === "int_processing_status_1" || item.field === "internal_debit" || item.field === "internal_credit")
            {
              item["hide"] = true;
            }

          }
        });

        this.unMatchedInternalColumnDefs = internalRecordsAllColumnDefs;
        this.unMatchedInternalRowData = internalRecordsAllrowData;
        this.ngxService.stop();
        
      },(error:any) => {
        this.HandleErrorResponse(error);
        this.ngxService.stop();
      })
  }

  public onUnMatchedExternalGridReady(params : any) : void {
    this.externalUnMatchedGridApi = params.api;
    this.externalUnMatchedGridColumnApi = params.columnApi;
  }

  public onUnMatchedInternalGridReady(params : any) : void {
    this.internalUnMatchedGridApi = params.api;
    this.internalUnMatchedgridColumnApi = params.columnApi;
  }

  public quickSearchUnMatched() : void {
    this.externalUnMatchedGridApi.setQuickFilter(this.searchValueUnMatched);
    this.internalUnMatchedGridApi.setQuickFilter(this.searchValueUnMatched);
  }

  public onExportUnMatchedExternalExcelClick() : void {
    this.ngxService.start();
    let excelExportData = [];

    let columnsNotRequired = ["ext_processing_status_1", "external_records_id", "external_contra_id", "external_group_id", "external_debit", "external_credit", ""];
    for (var i=0; i<this.unMatchedExternalRowData.length; i++)
    {
      let data = {};
      for (let key in this.unMatchedExternalRowData[i])
      {
        if(!columnsNotRequired.includes(key))
        {
          data[key] = this.unMatchedExternalRowData[i][key];
        }
      };
      excelExportData.push(data);
    };

    for (var i=0; i<excelExportData.length; i++)
    {
      excelExportData[i]["bank_credit"] = Number(excelExportData[i]["bank_credit"]);
      excelExportData[i]["bank_debit"] = Number(excelExportData[i]["bank_debit"].replace("-", ""));
    };

    this.excelService.exportAsExcelFile(excelExportData, "UnMatched_Bank");
    this.ngxService.stop();
  }

  public onExportUnMatchedInternalExcelClick() : void {
    this.ngxService.start();
    let excelExportData = [];

    let columnsNotRequired = ["int_processing_status_1", "internal_contra_id", "internal_credit", "internal_debit", "internal_group_id", "internal_records_id", ""];
    for (var i=0; i<this.unMatchedInternalRowData.length; i++)
    {
      let data = {};
      for (let key in this.unMatchedInternalRowData[i])
      {
        if(!columnsNotRequired.includes(key))
        {
          data[key] = this.unMatchedInternalRowData[i][key];
        }
      };
      excelExportData.push(data);
    };

    for (var i=0; i<excelExportData.length; i++)
    {
      excelExportData[i]["gl_debit"] = Number(excelExportData[i]["gl_debit"]);
      excelExportData[i]["gl_credit"] = Number(excelExportData[i]["gl_credit"].replace("-", ""));
    }
    this.excelService.exportAsExcelFile(excelExportData, "UnMatched_GL");
    this.ngxService.stop();
  }

  public onUnMatchedExternalSelectionChanged(params : any) : void {  
    let processingLayerId = this.processing_layer_id;
    let headerSide = "External";
    
    let data = {
      "tenantId": this.tenantId,
      "groupId": this.groupId,
      "entityId": this.entityId,
      "mProcessingLayerId": this.mProcessingLayerId,
      "mProcessingSubLayerId": this.mProcessingSubLayerId,
      "processingLayerId": processingLayerId,
      "headerSide": headerSide
    }

    this.summaryService.getInternalExternalHeadersFromServer(data)
    .subscribe(
      receivedData => {
        let responseData = receivedData;
        console.log(responseData);
        if (responseData["Status"] === "Success")
        {
          let externalHeaders = responseData["external_records"]["headers"];
          externalHeaders.forEach((item, index) => {
            if(item.sortable=="true"){
              if(index === 0){
                item["checkboxSelection"] = true;
                item["maxWidth"] = 40;
                item["pinned"] = 'left';
                item.sortable=true;
                item.filter=false;
                item.resizable=false;
                item.suppressAutoSize=true;
                item.suppressSizeToFit=true;
                item["headerCheckboxSelection"] = true;
                item["headerCheckboxSelectionFilteredOnly"] = true;
                item.lockPosition=true;
              }
              else if (index !== 0){
                item.sortable=true;
                item.filter=true;
                item.resizable=true;
                item.suppressAutoSize=true;
                item.suppressSizeToFit=true;
                item["minWidth"] = 50;
              }
  
              // Hiding
              if (item.field === "external_records_id" || item.field === "external_contra_id" || item.field === "external_group_id" || item.field === "ext_processing_status_1" || item.field === "external_debit" || item.field === "external_credit")
              {
                item["hide"] = true;
              }
  
            }
          });

          this.selectedUnMatchedExternalColumnDefs = externalHeaders;
        }
    }, (error : any) => {this.HandleErrorResponse(error)});


    this.selectedUnMatchedExternalRowData = params.api.getSelectedRows();
    
    if(this.selectedUnMatchedExternalRowData.length == 0 && this.selectedUnMatchedInternalRowData.length == 0)
    {
      console.log(this.selectedUnMatchedExternalRowData.length);
      this.displaySelectedUnMatchedGrid = false;
    }
    else if(this.selectedUnMatchedExternalRowData.length > 0 || this.selectedUnMatchedInternalRowData.length > 0)
    {
      this.displaySelectedUnMatchedGrid = true;
      let selectedExternalDebitAmount = 0.00;
      let selectedExternalCreditAmount = 0.00;
      for(let i:number = 0; i<this.selectedUnMatchedExternalRowData.length; i++)
      {
        selectedExternalDebitAmount = selectedExternalDebitAmount + parseFloat(this.selectedUnMatchedExternalRowData[i].external_debit);
        selectedExternalCreditAmount = selectedExternalCreditAmount + parseFloat(this.selectedUnMatchedExternalRowData[i].external_credit);
        this.selectedUnMatchedExternalAmount = selectedExternalDebitAmount + selectedExternalCreditAmount;
      }

      if(Number(String(this.selectedUnMatchedExternalAmount).replace("-", "")) === 0 && Number(String(this.selectedUnMatchedInternalAmount).replace("-", "")) === 0)
      {
        if(this.selectedUnMatchedExternalRowData.length > 0 && this.selectedUnMatchedInternalRowData.length > 0)
        {
          this.contraButtonEnable = false;
        }
        else
        {
          this.contraButtonEnable = true;
        }
        
      }
      else if(Number(String(this.selectedUnMatchedExternalAmount).replace("-", "")) > 0 || Number(String(this.selectedUnMatchedInternalAmount).replace("-", "")) > 0)
      {
        this.contraButtonEnable = false;
      }
      else if(Number(String(this.selectedUnMatchedExternalAmount).replace("-", "")) === 0 || Number(String(this.selectedUnMatchedInternalAmount).replace("-", "")) === 0)
      {
        this.contraButtonEnable = true;
      }
    }

    if (this.selectedUnMatchedInternalRowData.length === 0)
    {
      this.selectedUnMatchedInternalAmount = 0.00;
    }

    if (this.selectedUnMatchedExternalRowData.length === 0)
    {
      this.selectedUnMatchedExternalAmount = 0.00;
    }

    if(this.selectedUnMatchedExternalRowData.length > 0 && this.selectedUnMatchedInternalRowData.length > 0)
    {
      let amountTolerance = Number(this.amountTolerance);
      let selectedUnMatchedInternalAmount = Number(this.selectedUnMatchedInternalAmount);
      let selectedUnMatchedExternalAmount = Number(this.selectedUnMatchedExternalAmount);
      // let totalSelectedUnMatchedAmountString = Number(String(selectedUnMatchedInternalAmount - selectedUnMatchedExternalAmount).replace("-", ""));
      this.totalSelectedUnMatchedAmount = Number(String(selectedUnMatchedInternalAmount - selectedUnMatchedExternalAmount).replace("-", ""));
  
      if(this.totalSelectedUnMatchedAmount <= amountTolerance)
      {
        this.matchButtonEnable = true;
      }
      else
      {
        this.matchButtonEnable = false;
      }
    }
    
    if((this.selectedUnMatchedExternalRowData.length > 0 && this.selectedUnMatchedInternalRowData.length === 0) || (this.selectedUnMatchedInternalRowData.length > 0 && this.selectedUnMatchedExternalRowData.length === 0))
    {
      this.matchButtonEnable = false;
    }
    else
    {
      this.matchButtonEnable = true;
    }

  }

  public onUnMatchedInternalSelectionChanged(params : any) : void {
    let processingLayerId = this.processing_layer_id;
    let headerSide = "Internal";
    
    let data = {
      "tenantId": this.tenantId,
      "groupId": this.groupId,
      "entityId": this.entityId,
      "mProcessingLayerId": this.mProcessingLayerId,
      "mProcessingSubLayerId": this.mProcessingSubLayerId,
      "processingLayerId": processingLayerId,
      "headerSide": headerSide
    }

    this.summaryService.getInternalExternalHeadersFromServer(data)
    .subscribe(
      receivedData => {
        let responseData = receivedData;
        console.log(responseData);
        if (responseData["Status"] === "Success")
        {
          let internalHeaders = responseData["internal_records"]["headers"];
          internalHeaders.forEach((item, index) => {
            if(item.sortable=="true"){
              if(index === 0){
                item["checkboxSelection"] = true;
                item["maxWidth"] = 40;
                item["pinned"] = 'left';
                item.sortable=true;
                item.filter=false;
                item.resizable=false;
                item.suppressAutoSize=true;
                item.suppressSizeToFit=true;
                item["headerCheckboxSelection"] = true;
                item["headerCheckboxSelectionFilteredOnly"] = true;
                item.lockPosition=true;
              }
              else if (index !== 0){
                item.sortable=true;
                item.filter=true;
                item.resizable=true;
                item.suppressAutoSize=true;
                item.suppressSizeToFit=true;
                item["minWidth"] = 50;
              }
  
              // Hiding
              if (item.field === "internal_records_id" || item.field === "internal_contra_id" || item.field === "internal_group_id" || item.field === "int_processing_status_1" || item.field === "internal_debit" || item.field === "internal_credit")
              {
                item["hide"] = true;
              }
  
            }
          });

          this.selectedUnMatchedInternalColumnDefs = internalHeaders;
        }
    }, (error : any) => {this.HandleErrorResponse(error)});

    this.selectedUnMatchedInternalRowData = params.api.getSelectedRows();
    if(this.selectedUnMatchedExternalRowData.length == 0 && this.selectedUnMatchedInternalRowData.length == 0)
    {
      this.displaySelectedUnMatchedGrid = false;
    }
    else if(this.selectedUnMatchedExternalRowData.length > 0 || this.selectedUnMatchedInternalRowData.length > 0)
    {
      this.displaySelectedUnMatchedGrid = true;
      let selectedInternalDebitAmount = 0.00;
      let selectedInternalCreditAmount = 0.00;
      for(let i:number = 0; i<this.selectedUnMatchedInternalRowData.length; i++)
      {
        selectedInternalDebitAmount = selectedInternalDebitAmount + parseFloat(this.selectedUnMatchedInternalRowData[i].internal_debit);
        selectedInternalCreditAmount = selectedInternalCreditAmount + parseFloat(this.selectedUnMatchedInternalRowData[i].internal_credit);
        this.selectedUnMatchedInternalAmount = selectedInternalDebitAmount + selectedInternalCreditAmount;
      }

      if(Number(String(this.selectedUnMatchedInternalAmount).replace("-", "")) === 0 && Number(String(this.selectedUnMatchedExternalAmount).replace("-", "")) === 0)
      {
        if(this.selectedUnMatchedExternalRowData.length > 0 && this.selectedUnMatchedInternalRowData.length > 0)
        {
          this.contraButtonEnable = false;
        }
        else
        {
          this.contraButtonEnable = true;
        }
        
      }
      else if(Number(String(this.selectedUnMatchedInternalAmount).replace("-", "")) > 0 || Number(String(this.selectedUnMatchedExternalAmount).replace("-", "")) > 0)
      {
        this.contraButtonEnable = false;
      }
      else if(Number(String(this.selectedUnMatchedInternalAmount).replace("-", "")) === 0 || Number(String(this.selectedUnMatchedExternalAmount).replace("-", "")) === 0)
      {
        this.contraButtonEnable = true;
      }
    }

    if (this.selectedUnMatchedInternalRowData.length === 0)
    {
      this.selectedUnMatchedInternalAmount = 0.00;
    }

    if (this.selectedUnMatchedExternalRowData.length === 0)
    {
      this.selectedUnMatchedExternalAmount = 0.00;
    }

    if(this.selectedUnMatchedExternalRowData.length > 0 || this.selectedUnMatchedInternalRowData.length > 0)
    {
      let amountTolerance = Number(this.amountTolerance);
      let selectedUnMatchedInternalAmount = Number(this.selectedUnMatchedInternalAmount);
      let selectedUnMatchedExternalAmount = Number(this.selectedUnMatchedExternalAmount);
      this.totalSelectedUnMatchedAmount = Number(String(selectedUnMatchedInternalAmount - selectedUnMatchedExternalAmount).replace("-", ""));

      if(this.totalSelectedUnMatchedAmount <= amountTolerance)
      {
        this.matchButtonEnable = true;
      }
      else
      {
        this.matchButtonEnable = false;
      }
    }
    
    if((this.selectedUnMatchedExternalRowData.length > 0 && this.selectedUnMatchedInternalRowData.length === 0) || (this.selectedUnMatchedInternalRowData.length > 0 && this.selectedUnMatchedExternalRowData.length === 0))
    {
      this.matchButtonEnable = false;
    }
    else
    {
      this.matchButtonEnable = true;
    }
  }

  public onMatchButtonClick() : void {
    
    let amountTolerance = Number(this.amountTolerance);
    let selectedUnMatchedInternalAmount = Number(this.selectedUnMatchedInternalAmount);
    let selectedUnMatchedExternalAmount = Number(this.selectedUnMatchedExternalAmount);
    this.totalSelectedUnMatchedAmount = selectedUnMatchedInternalAmount - selectedUnMatchedExternalAmount;

    this.resetFilter();
    console.log("Total Selected UnMatched Amount ", this.totalSelectedUnMatchedAmount);
    
    if(Math.abs(Number(this.totalSelectedUnMatchedAmount)) > amountTolerance)
    {
      // this.ngxService.stop();
      alert("Amounts are not Matching!!!");
    }
    else if(Math.abs(Number(this.totalSelectedUnMatchedAmount)) <= amountTolerance)
    {
      this.ngxService.start();
      let selectedUnMatchedExternalRowData = this.selectedUnMatchedExternalRowData;
      let selectedUnMatchedInternalRowData = this.selectedUnMatchedInternalRowData;
      let selectedExternalRecordsIdList = [];
      let selectedInternalRecordsIdList = [];

      for(let i=0; i<selectedUnMatchedExternalRowData.length; i++)
      {
        selectedExternalRecordsIdList.push(selectedUnMatchedExternalRowData[i]["external_records_id"]);
      }

      for(let j=0; j<selectedUnMatchedInternalRowData.length; j++)
      {
        selectedInternalRecordsIdList.push(selectedUnMatchedInternalRowData[j]["internal_records_id"]);
      }

      let data = {
        "tenant_id": this.tenantId,
        "group_id": this.groupId,
        "entity_id": this.entityId,
        "m_processing_layer_id": this.mProcessingLayerId,
        "m_processing_sub_layer_id": this.mProcessingSubLayerId,
        "processing_layer_id": this.processing_layer_id,
        "user_id": this.userId,
        "external_record_id_list": selectedExternalRecordsIdList,
        "internal_record_id_list": selectedInternalRecordsIdList,
        "matching_comment_id": this.matchingCommentIdchosen,
        "matching_comment_description": this.matchingCommentDescription
      }

      this.summaryService.sendUnMatchedToMatchToServer(data)
      .subscribe(
        received_data => {
          let response_data = received_data;
          console.log("Match Buton Click Response: ", response_data);
          if(response_data["Status"] === "Success")
          {
            this.displaySelectedUnMatchedGrid = false;
            this.getSelectedProcessingLayer(this.processing_layer_id);

            let data = {
              "tenant_id" : this.tenantId,
              "group_id" : this.groupId,
              "entity_id" : this.entityId,
              "m_processing_layer_id" : this.mProcessingLayerId,
              "m_processing_sub_layer_id" : this.mProcessingSubLayerId,
              "processing_layer_id" : this.processing_layer_id,
              "record_status" : "UnMatched"
            }

            this.unMatchedGridShow(data);
            this.unMatchedDisplayGrid = true;
            this.unMatchedSearchGrid = true;
            this.selectedUnMatchedExternalRowData = '';
            this.selectedUnMatchedInternalRowData = '';
            this.ngxService.stop();

          }
          else if(response_data["Status"] === "Error")
          {
            alert("Error in Matching Records. Kindly Contact Advents Support!!!");
            this.ngxService.stop();
          }
          else if(response_data["Status"] === "File")
          {
            alert("File is Processing in Backend. Kindly try after sometime!!!");
            this.ngxService.stop();
          }

        }, (error:any) => {
          this.HandleErrorResponse(error);
          this.ngxService.stop();
        })
    }
  }

  public onContraButtonClick() : void {
    this.ngxService.start();
    let selectedExternalRowData = this.selectedUnMatchedExternalRowData;
    let selectedInternalRowData = this.selectedUnMatchedInternalRowData;
    let selectedExternalContraIdList = [];
    let selectedInternalContraIdList = [];

    this.resetFilter();

    for(let i:number = 0; i<selectedExternalRowData.length; i++)
    {
      selectedExternalContraIdList.push(selectedExternalRowData[i]["external_records_id"]);
    }

    for(let j:number = 0; j<selectedInternalRowData.length; j++)
    {
      selectedInternalContraIdList.push(selectedInternalRowData[j]["internal_records_id"]);
    }

    let data = {
      "tenantId": this.tenantId,
      "groupId": this.groupId,
      "entityId": this.entityId,
      "mProcessingLayerId": this.mProcessingLayerId,
      "mProcessingSubLayerId": this.mProcessingSubLayerId,
      "processingLayerId": this.processing_layer_id,
      "externalContraList": selectedExternalContraIdList,
      "internalContraList": selectedInternalContraIdList,
      "userId": this.userId,
      "matchingCommentId": this.matchingCommentIdchosen,
      "matchingCommentDescription": this.matchingCommentDescription
    }

    this.summaryService.sendUnmatchedToContraToServer(data)
    .subscribe(
      received_data => {
        let responseData = received_data;
        console.log("Contra Button Click Respose: ", responseData);
        if(responseData["Status"] === "Success")
        {
          this.displaySelectedUnMatchedGrid = false;
          this.getSelectedProcessingLayer(this.processing_layer_id);
          
          let data = {
            "tenant_id" : this.tenantId,
            "group_id" : this.groupId,
            "entity_id" : this.entityId,
            "m_processing_layer_id" : this.mProcessingLayerId,
            "m_processing_sub_layer_id" : this.mProcessingSubLayerId,
            "processing_layer_id" : this.processing_layer_id,
            "record_status" : "UnMatched"
          }

          this.unMatchedGridShow(data);
          this.unMatchedDisplayGrid = true;
          this.unMatchedSearchGrid = true;
          this.selectedUnMatchedExternalRowData = '';
          this.selectedUnMatchedInternalRowData = '';
          this.ngxService.stop();

        }
        else if(responseData["Status"] === "Error")
        {
          alert("Error in Updating Contra. Kindly Contact Advents Support!!!");
          this.ngxService.stop();
        }
        else if(responseData["Status"] === "File")
        {
          alert("File is Processing in Backend. Kindly try after sometime!!!");
          this.ngxService.stop();
        }
      }
    )

  }

  public onUnMatchButtonClick() : void {
    this.ngxService.start();
    let userId = JSON.parse(sessionStorage.getItem("user_details"))["user_id"];
    let externalRecordId = this.selectedExternalRowData[0]["external_records_id"];
    let internalRecordId = this.SelectedinternalRowData[0]["internal_records_id"];

    this.resetFilter();

    let data = {
      "tenantId": this.tenantId,
      "groupId": this.groupId,
      "entityId": this.entityId,
      "mProcessingLayerId": this.mProcessingLayerId,
      "mProcessingSubLayerId": this.mProcessingSubLayerId,
      "processingLayerId": this.processing_layer_id,
      "userId": userId,
      "externalRecordId": externalRecordId,
      "internalRecordId": internalRecordId
    }

    this.summaryService.sendMatchedToUnMatchToServer(data)
    .subscribe(received_data => {
      let response_data = received_data;
      console.log("UnMatch Buton Click Response: ", response_data);
      if (response_data["Status"] === "Success")
      {
        this.displaySelectedMatchedGrid = false;
        this.getSelectedProcessingLayer(this.processing_layer_id);

        let data = {
          "tenant_id" : this.tenantId,
          "group_id" : this.groupId,
          "entity_id" : this.entityId,
          "m_processing_layer_id" : this.mProcessingLayerId,
          "m_processing_sub_layer_id" : this.mProcessingSubLayerId,
          "processing_layer_id" : this.processing_layer_id,
          "record_status" : "Matched"
        }

        this.matchedGridShow(data);
        this.matchedDisplayGrid = true;
        this.matchedSearchGrid = true;
        this.selectedExternalRowData = '';
        this.SelectedinternalRowData = '';
        this.ngxService.stop();
      }

      else if (response_data["Status"] === "Error")
      {
        alert("Error in UnMatching Records. Kindly Contact Advents Support!!!");
        this.ngxService.stop();
      }

    }, (error:any) => {
      this.HandleErrorResponse(error);
      this.ngxService.stop();
    })
  }

  public groupMatchedShow(data : any) : void {
    this.ngxService.start();
    this.summaryService.getTransactionRecordsFromServer(data)
    .subscribe(
      received_data => {
        let response_data = received_data;
        console.log("GroupMatched Chart Click Response: ", response_data);

        let externalRecordsAllColumnDefs = response_data["external_records"]["headers"];
        let externalRecordsAllrowData = response_data["external_records"]["data"];
        let internalRecordsAllColumnDefs = response_data["internal_records"]["headers"];
        let internalRecordsAllrowData = response_data["internal_records"]["data"];
        this.amountTolerance = parseFloat(response_data["amount_tolerance"]);

        // External
        externalRecordsAllColumnDefs.forEach((item, index) => {
          if(item.sortable=="true"){
            if(index === 0){
              item["checkboxSelection"] = true;
              item["maxWidth"] = 40;
              item["pinned"] = 'left';
              item.sortable=true;
              item.filter=false;
              item.resizable=false;
              item.suppressAutoSize=true;
              item.suppressSizeToFit=true;
              item.lockPosition=true;
            }
            else if (index !== 0){
              item.sortable=true;
              item.filter=true;
              item.resizable=true;
              item.suppressAutoSize=true;
              item.suppressSizeToFit=true;
              item["minWidth"] = 50;
            }

            // Hiding
            if (item.field === "external_records_id" || item.field === "external_contra_id" || item.field === "external_group_id" || item.field === "ext_processing_status_1" || item.field === "external_debit" || item.field === "external_credit")
            {
              item["hide"] = true;
            }

          }
        });

        this.groupMatchedExternalColumnDefs = externalRecordsAllColumnDefs;
        this.groupMatchedExternalRowData = externalRecordsAllrowData;

        // Internal
        internalRecordsAllColumnDefs.forEach((item, index) => {
          if(item.sortable=="true"){
            if(index === 0){
              item["checkboxSelection"] = true;
              item["maxWidth"] = 40;
              item["pinned"] = 'left';
              item.sortable=true;
              item.filter=false;
              item.resizable=false;
              item.suppressAutoSize=true;
              item.suppressSizeToFit=true;
              item.lockPosition=true;
            }
            else if (index !== 0){
              item.sortable=true;
              item.filter=true;
              item.resizable=true;
              item.suppressAutoSize=true;
              item.suppressSizeToFit=true;
              item["minWidth"] = 50;
            }

            // Hiding
            if (item.field === "internal_records_id" || item.field === "internal_contra_id" || item.field === "internal_group_id" || item.field === "int_processing_status_1" || item.field === "internal_debit" || item.field === "internal_credit")
            {
              item["hide"] = true;
            }

          }
        });

        this.groupMatchedInternalColumnDefs = internalRecordsAllColumnDefs;
        this.groupMatchedInternalRowData = internalRecordsAllrowData;
        this.ngxService.stop();

      },(error:any) => {
        this.HandleErrorResponse(error);
        this.ngxService.stop();
      })
  }

  public onGroupMatchedExternalGridReady(params : any) : void{
    this.externalGroupMatchedGridApi = params.api;
    this.externalGroupMatchedGridColumnApi = params.columnApi;
  }

  public onGroupMatchedInternalGridReady(params : any) : void {
    this.internalGroupMatchedGridApi = params.api;
    this.internalGroupMatchedGridColummApi = params.columnApi;
  }

  public quickSearchGroupMatched() : void {
    this.externalGroupMatchedGridApi.setQuickFilter(this.searchValueGroupMatched);
    this.internalGroupMatchedGridApi.setQuickFilter(this.searchValueGroupMatched)
  }

  public onExportGroupMatchedExternalExcelClick() : void {
    this.ngxService.start();
    let excelExportData = [];

    let columnsNotRequired = ["ext_processing_status_1", "external_records_id", "external_contra_id", "external_group_id", "external_debit", "external_credit", ""];
    for (var i=0; i<this.groupMatchedExternalRowData.length; i++)
    {
      let data = {};
      for (let key in this.groupMatchedExternalRowData[i])
      {
        if(!columnsNotRequired.includes(key))
        {
          data[key] = this.groupMatchedExternalRowData[i][key];
        }
      };
      excelExportData.push(data);
    };

    for (var i=0; i<excelExportData.length; i++)
    {
      excelExportData[i]["bank_credit"] = Number(excelExportData[i]["bank_credit"]);
      excelExportData[i]["bank_debit"] = Number(excelExportData[i]["bank_debit"].replace("-", ""));
    };

    this.excelService.exportAsExcelFile(excelExportData, "GroupMatched_Bank");
    this.ngxService.stop();
  }

  public onExportGroupMatchedInternalExcelClick() : void {
    this.ngxService.start();
    let excelExportData = [];

    let columnsNotRequired = ["int_processing_status_1", "internal_contra_id", "internal_credit", "internal_debit", "internal_group_id", "internal_records_id", ""];
    for (var i=0; i<this.groupMatchedInternalRowData.length; i++)
    {
      let data = {};
      for (let key in this.groupMatchedInternalRowData[i])
      {
        if(!columnsNotRequired.includes(key))
        {
          data[key] = this.groupMatchedInternalRowData[i][key];
        }
      };
      excelExportData.push(data);
    };

    for (var i=0; i<excelExportData.length; i++)
    {
      excelExportData[i]["gl_debit"] = Number(excelExportData[i]["gl_debit"]);
      excelExportData[i]["gl_credit"] = Number(excelExportData[i]["gl_credit"].replace("-", ""));
    }
    this.excelService.exportAsExcelFile(excelExportData, "GroupMatched_GL");
    this.ngxService.stop();
  }

  public onGroupMatchedExternalSelectionChanged(params : any) : void {
    try
    {
      this.ngxService.start();
      this.displaySelectedGroupMatchedGrid = true;
      this.groupMatchButtonDisabled = false;
      let selectedGroupMatchedExternalRowData = params.api.getSelectedRows();

      console.log(selectedGroupMatchedExternalRowData);

      let selectedGroupMatchedExternalRecordId = selectedGroupMatchedExternalRowData[0]["external_group_id"];

      let data = {
        "tenant_id": this.tenantId,
        "group_id": this.groupId,
        "entity_id": this.entityId,
        "m_processing_layer_id": this.mProcessingLayerId,
        "m_processing_sub_layer_id": this.mProcessingSubLayerId,
        "processing_layer_id": this.processing_layer_id,
        "selected_group_id": selectedGroupMatchedExternalRecordId
      }

      this.summaryService.getGroupIdTransactionsFromServer(data)
      .subscribe(
        received_data => {
          let responseData = received_data;
          console.log(responseData);
          if (responseData["Status"] === "Success")
          {
            let groupExternalRecordsData = responseData["external_records"]["data"];
            let groupExternalRecordsHeader = responseData["external_records"]["headers"];
            let groupInternalRecordsData = responseData["internal_records"]["data"];
            let groupInternalRecordsHeader = responseData["internal_records"]["headers"];
            this.updateSelectedGroupMatchedgrid(
              groupExternalRecordsData, groupExternalRecordsHeader, groupInternalRecordsData, groupInternalRecordsHeader
            );
            this.ngxService.stop();
          }
          else if(responseData["Status"] === "Error")
          {
            this.displaySelectedGroupMatchedGrid = false;
            this.ngxService.stop();
          }

        },(error:any) => {
          this.HandleErrorResponse(error);
          this.ngxService.stop();
        })
    }
    catch(error)
    {
      this.displaySelectedGroupMatchedGrid = false;
      this.groupMatchButtonDisabled = true;
      this.ngxService.stop();
    }
  }

  public onGroupMatchedInternalSelectionChanged(params : any) : void {
    try
    {
      this.ngxService.start();
      this.displaySelectedGroupMatchedGrid = true;
      this.groupMatchButtonDisabled = false;
      let selectedGroupMatchedInternalRowData = params.api.getSelectedRows();

      console.log(selectedGroupMatchedInternalRowData);

      let selectedGroupMatchedInternalRecordId = selectedGroupMatchedInternalRowData[0]["internal_group_id"];

      let data = {
        "tenant_id": this.tenantId,
        "group_id": this.groupId,
        "entity_id": this.entityId,
        "m_processing_layer_id": this.mProcessingLayerId,
        "m_processing_sub_layer_id": this.mProcessingSubLayerId,
        "processing_layer_id": this.processing_layer_id,
        "selected_group_id": selectedGroupMatchedInternalRecordId
      }

      this.summaryService.getGroupIdTransactionsFromServer(data)
      .subscribe(
        received_data => {
          let responseData = received_data;
          console.log(responseData);
          if (responseData["Status"] === "Success")
          {
            let groupExternalRecordsData = responseData["external_records"]["data"];
            let groupExternalRecordsHeader = responseData["external_records"]["headers"];
            let groupInternalRecordsData = responseData["internal_records"]["data"];
            let groupInternalRecordsHeader = responseData["internal_records"]["headers"];
            this.updateSelectedGroupMatchedgrid(
              groupExternalRecordsData, groupExternalRecordsHeader, groupInternalRecordsData, groupInternalRecordsHeader
            );
            this.ngxService.stop();
          }
          else if(responseData["Status"] === "Error")
          {
            this.displaySelectedGroupMatchedGrid = false;
            this.ngxService.stop();
          }

        },(error:any) => {
          this.HandleErrorResponse(error);
          this.ngxService.stop();
        });

    }
    catch(error)
    {
      this.displaySelectedGroupMatchedGrid = false;
      this.groupMatchButtonDisabled = true;
      this.ngxService.stop();
    }
  }

  public updateSelectedGroupMatchedgrid(groupExternalRecordsData : any, groupExternalRecordsHeader : any, groupInternalRecordsData : any, groupInternalRecordsHeader : any) : void {
    // Internal
    groupInternalRecordsHeader.forEach((item, index) => {
      if(item.sortable=="true"){
        if(index === 0){
          item["checkboxSelection"] = true;
          item["maxWidth"] = 40;
          item["pinned"] = 'left';
          item.sortable=true;
          item.filter=false;
          item.resizable=false;
          item.suppressAutoSize=true;
          item.suppressSizeToFit=true;
          item.lockPosition=true;
        }
        else if (index !== 0){
          item.sortable=true;
          item.filter=true;
          item.resizable=true;
          item.suppressAutoSize=true;
          item.suppressSizeToFit=true;
          item["minWidth"] = 50;
        }

        // Hiding
        if (item.field === "internal_records_id" || item.field === "internal_contra_id" || item.field === "internal_group_id" || item.field === "int_processing_status_1" || item.field === "internal_debit" || item.field === "internal_credit")
        {
          item["hide"] = true;
        }

      }
    });

    this.selectedGroupMatchedInternalRowData = groupInternalRecordsData;
    this.selectedGroupMatchedInternalColumnDefs = groupInternalRecordsHeader;

    // External
    groupExternalRecordsHeader.forEach((item, index) => {
      if(item.sortable=="true"){
        if(index === 0){
          item["checkboxSelection"] = true;
          item["maxWidth"] = 40;
          item["pinned"] = 'left';
          item.sortable=true;
          item.filter=false;
          item.resizable=false;
          item.suppressAutoSize=true;
          item.suppressSizeToFit=true;
          item.lockPosition=true;
        }
        else if (index !== 0){
          item.sortable=true;
          item.filter=true;
          item.resizable=true;
          item.suppressAutoSize=true;
          item.suppressSizeToFit=true;
          item["minWidth"] = 50;
        }

        // Hiding
        if (item.field === "external_records_id" || item.field === "external_contra_id" || item.field === "external_group_id" || item.field === "ext_processing_status_1" || item.field === "external_debit" || item.field === "external_credit")
        {
          item["hide"] = true;
        }

      }
    });

    this.selectedGroupMatchedExternalRowData = groupExternalRecordsData;
    this.selectedGroupMatchedExternalColumnDefs = groupExternalRecordsHeader;
  }

  public onGroupUnMatchButtonClick() : void {
    this.ngxService.start();
    let selectedGroupMatchedExternalRowData = this.selectedGroupMatchedExternalRowData;
    let selectedGroupId = selectedGroupMatchedExternalRowData[0]["external_group_id"];

    this.resetFilter();

    let data = {
      "tenantId": this.tenantId,
      "groupId": this.groupId,
      "entityId": this.entityId,
      "mProcessingLayerId": this.mProcessingLayerId,
      "mProcessingSubLayerId": this.mProcessingSubLayerId,
      "processingLayerId": this.processing_layer_id,
      "selectedGroupId": selectedGroupId,
      "userId": this.userId
    }

    this.summaryService.setGroupMatchedToUnMatchToServer(data)
    .subscribe(
      received_data => {
        let responseData = received_data;
        console.log(responseData);
        if (responseData["Status"] === "Success")
        {
          this.displaySelectedGroupMatchedGrid = false;
          this.getSelectedProcessingLayer(this.processing_layer_id);

          let data = {
            "tenant_id" : this.tenantId,
            "group_id" : this.groupId,
            "entity_id" : this.entityId,
            "m_processing_layer_id" : this.mProcessingLayerId,
            "m_processing_sub_layer_id" : this.mProcessingSubLayerId,
            "processing_layer_id" : this.processing_layer_id,
            "record_status" : "GroupMatched"
          }

          this.groupMatchedShow(data);
          this.groupMatchedDisplayGrid = true;
          this.groupMatchedSearchGrid = true;
          this.selectedGroupMatchedExternalRowData = '';
          this.selectedGroupMatchedInternalRowData = '';
          this.ngxService.stop();
        }
        else if(responseData["Status"] === "Error")
        {
          alert("Error in UnMatching Records. Kindly Contact Advents Support!!!");
          this.ngxService.stop();
        }
        else if(responseData["Status"] === "File")
        {
          alert("File is Processing in Backend. Kindly try after sometime!!!");
          this.ngxService.stop();
        }
      }
    )
  }

  public onContraExternalGridReady(params : any) : void {
    this.externalContraGridApi = params.api;
    this.externalContraGridColumnApi = params.columnApi;
  }

  public onContraInternalGridReady(params : any) : void {
    this.internalContraGridApi = params.api;
    this.internalContraGridColumnApi = params.columnApi;
  }

  public quickSearchContra() : void {
    this.externalContraGridApi.setQuickFilter(this.searchValueContra);
    this.internalContraGridApi.setQuickFilter(this.searchValueContra);
  }

  public contraShow(data : any) : void {
    this.ngxService.start();
    this.summaryService.getTransactionRecordsFromServer(data)
    .subscribe(
      received_data => {
        let response_data = received_data;
        console.log("Contra Chart Click Response: ", response_data);

        let externalRecordsAllColumnDefs = response_data["external_records"]["headers"];
        let externalRecordsAllrowData = response_data["external_records"]["data"];
        let internalRecordsAllColumnDefs = response_data["internal_records"]["headers"];
        let internalRecordsAllrowData = response_data["internal_records"]["data"];
        this.amountTolerance = parseFloat(response_data["amount_tolerance"]);

        // External
        externalRecordsAllColumnDefs.forEach((item, index) => {
          if(item.sortable=="true"){
            if(index === 0){
              item["checkboxSelection"] = true;
              item["maxWidth"] = 40;
              item["pinned"] = 'left';
              item.sortable=true;
              item.filter=false;
              item.resizable=false;
              item.suppressAutoSize=true;
              item.suppressSizeToFit=true;
              item.lockPosition=true;
            }
            else if (index !== 0){
              item.sortable=true;
              item.filter=true;
              item.resizable=true;
              item.suppressAutoSize=true;
              item.suppressSizeToFit=true;
              item["minWidth"] = 50;
            }

            // Hiding
            if (item.field === "external_records_id" || item.field === "external_contra_id" || item.field === "external_group_id" || item.field === "ext_processing_status_1" || item.field === "external_debit" || item.field === "external_credit")
            {
              item["hide"] = true;
            }

          }
        });

        this.contraExternalColumnDefs = externalRecordsAllColumnDefs;
        this.contraExternalRowData = externalRecordsAllrowData;

        // Internal
        internalRecordsAllColumnDefs.forEach((item, index) => {
          if(item.sortable=="true"){
            if(index === 0){
              item["checkboxSelection"] = true;
              item["maxWidth"] = 40;
              item["pinned"] = 'left';
              item.sortable=true;
              item.filter=false;
              item.resizable=false;
              item.suppressAutoSize=true;
              item.suppressSizeToFit=true;
              item.lockPosition=true;
            }
            else if (index !== 0){
              item.sortable=true;
              item.filter=true;
              item.resizable=true;
              item.suppressAutoSize=true;
              item.suppressSizeToFit=true;
              item["minWidth"] = 50;
            }

            // Hiding
            if (item.field === "internal_records_id" || item.field === "internal_contra_id" || item.field === "internal_group_id" || item.field === "int_processing_status_1" || item.field === "internal_debit" || item.field === "internal_credit")
            {
              item["hide"] = true;
            }

          }
        });

        this.contraInternalColumnDefs = internalRecordsAllColumnDefs;
        this.contraInternalRowData = internalRecordsAllrowData;
        this.ngxService.stop();

      },(error:any) => {
        this.HandleErrorResponse(error);
        this.ngxService.stop();
      })
  }

  public onExportContraExternalExcelClick() : void {
    this.ngxService.start();
    let excelExportData = [];

    let columnsNotRequired = ["ext_processing_status_1", "external_records_id", "external_contra_id", "external_group_id", "external_debit", "external_credit", ""];
    for (var i=0; i<this.contraExternalRowData.length; i++)
    {
      let data = {};
      for (let key in this.contraExternalRowData[i])
      {
        if(!columnsNotRequired.includes(key))
        {
          data[key] = this.contraExternalRowData[i][key];
        }
      };
      excelExportData.push(data);
    };

    for (var i=0; i<excelExportData.length; i++)
    {
      excelExportData[i]["bank_credit"] = Number(excelExportData[i]["bank_credit"]);
      excelExportData[i]["bank_debit"] = Number(excelExportData[i]["bank_debit"].replace("-", ""));
    };

    this.excelService.exportAsExcelFile(excelExportData, "Contra_Bank");
    this.ngxService.stop();
  }

  public onExportContraInternalExcelClick() : void {
    this.ngxService.start();
    let excelExportData = [];

    let columnsNotRequired = ["int_processing_status_1", "internal_contra_id", "internal_credit", "internal_debit", "internal_group_id", "internal_records_id", ""];
    for (var i=0; i<this.contraInternalRowData.length; i++)
    {
      let data = {};
      for (let key in this.contraInternalRowData[i])
      {
        if(!columnsNotRequired.includes(key))
        {
          data[key] = this.contraInternalRowData[i][key];
        }
      };
      excelExportData.push(data);
    };

    for (var i=0; i<excelExportData.length; i++)
    {
      excelExportData[i]["gl_debit"] = Number(excelExportData[i]["gl_debit"]);
      excelExportData[i]["gl_credit"] = Number(excelExportData[i]["gl_credit"].replace("-", ""));
    }
    this.excelService.exportAsExcelFile(excelExportData, "Contra_GL");
    this.ngxService.stop();
  }

  public onContraExternalSelectionChanged(params : any) : void {
    try
    {
      this.ngxService.start();
      this.displaySelectedInternalGridContra = false;
      this.selectedContraInternalRowData = '';
      this.displaySelectedContraGrid = true;
      this.contraUnmatchButtonEnable = true;
      this.displaySelectedExternalGridContra = true;
      let selectedExternalContraRowData = params.api.getSelectedRows();

      console.log(selectedExternalContraRowData);

      let selectedContraExternalRecordId = selectedExternalContraRowData[0]["external_contra_id"];

      let data = {
        "tenantId": this.tenantId,
        "groupId": this.groupId,
        "entityId": this.entityId,
        "mProcessingLayerId": this.mProcessingLayerId,
        "mProcessingSubLayerId": this.mProcessingSubLayerId,
        "processingLayerId": this.processing_layer_id,
        "userId": this.userId,
        "externalContraId": selectedContraExternalRecordId
      }

      this.summaryService.getSelectedContraRecordsFromServer(data)
      .subscribe(
        receivedData => {
          let responseData = receivedData;
          console.log(responseData);
          if(responseData["Status"] === "Success")
          {
            let contraExternalRowData = responseData["external_records"]["data"];
            let contraExternalHeaders = responseData["external_records"]["headers"];

            contraExternalHeaders.forEach((item, index) => {
              if(item.sortable=="true"){
                if(index === 0){
                  item["checkboxSelection"] = true;
                  item["maxWidth"] = 40;
                  item["pinned"] = 'left';
                  item.sortable=true;
                  item.filter=false;
                  item.resizable=false;
                  item.suppressAutoSize=true;
                  item.suppressSizeToFit=true;
                  item.lockPosition=true;
                }
                else if (index !== 0){
                  item.sortable=true;
                  item.filter=true;
                  item.resizable=true;
                  item.suppressAutoSize=true;
                  item.suppressSizeToFit=true;
                  item["minWidth"] = 50;
                }
    
                // Hiding
                if (item.field === "external_records_id" || item.field === "external_contra_id" || item.field === "external_group_id" || item.field === "ext_processing_status_1" || item.field === "external_debit" || item.field === "external_credit")
                {
                  item["hide"] = true;
                }
              }
            });

            this.selectedContraExternalRowData = contraExternalRowData;
            this.selectedContraExternalColumnDefs = contraExternalHeaders;
            this.ngxService.stop();
          }

        },(error : any) => {
          this.HandleErrorResponse(error);
          this.ngxService.stop();
        })
    }
    catch(error)
    {
      this.selectedContraExternalRowData = '';
      this.displaySelectedContraGrid = false;
      this.ngxService.stop();
    }
    
  }

  public onContraInternalSelectionChanged(params : any) : void {
    try
    {
      this.ngxService.start();
      this.displaySelectedExternalGridContra = false;
      this.selectedContraExternalRowData = '';
      this.displaySelectedInternalGridContra = true;
      this.displaySelectedContraGrid = true;
      this.contraUnmatchButtonEnable = true;
      let selectedInternalContraRowData = params.api.getSelectedRows();

      console.log(selectedInternalContraRowData);

      let selectedContraInternalRecordId = selectedInternalContraRowData[0]["internal_contra_id"];

      let data = {
        "tenantId": this.tenantId,
        "groupId": this.groupId,
        "entityId": this.entityId,
        "mProcessingLayerId": this.mProcessingLayerId,
        "mProcessingSubLayerId": this.mProcessingSubLayerId,
        "processingLayerId": this.processing_layer_id,
        "userId": this.userId,
        "internalContraId": selectedContraInternalRecordId
      }

      this.summaryService.getSelectedContraRecordsFromServer(data)
      .subscribe(
        receivedData => {
          let responseData = receivedData;
          console.log(responseData);
          if(responseData["Status"] === "Success")
          {
            let contraInternalRowData = responseData["internal_records"]["data"];
            let contraInternalHeaders = responseData["internal_records"]["headers"];

            contraInternalHeaders.forEach((item, index) => {
              if(item.sortable=="true"){
                if(index === 0){
                  item["checkboxSelection"] = true;
                  item["maxWidth"] = 40;
                  item["pinned"] = 'left';
                  item.sortable=true;
                  item.filter=false;
                  item.resizable=false;
                  item.suppressAutoSize=true;
                  item.suppressSizeToFit=true;
                  item.lockPosition=true;
                }
                else if (index !== 0){
                  item.sortable=true;
                  item.filter=true;
                  item.resizable=true;
                  item.suppressAutoSize=true;
                  item.suppressSizeToFit=true;
                  item["minWidth"] = 50;
                }
    
                // Hiding
                if (item.field === "internal_records_id" || item.field === "internal_contra_id" || item.field === "internal_group_id" || item.field === "int_processing_status_1" || item.field === "internal_debit" || item.field === "internal_credit")
                {
                  item["hide"] = true;
                }
              }
            });

            this.selectedContraInternalColumnDefs = contraInternalHeaders;
            this.selectedContraInternalRowData = contraInternalRowData;
            this.ngxService.stop();
          }
        }, (error : any) => {
          this.HandleErrorResponse(error);
          this.ngxService.stop();
        })

    }
    catch(error)
    {
      this.selectedContraInternalRowData = '';
      this.displaySelectedContraGrid = false;
      this.ngxService.stop();
    }
  }

  public onContraUnMatchButtonClick() : void {
    this.ngxService.start();

    this.resetFilter();

    if(this.selectedContraInternalRowData !== "")
    {
      var contraSide = "Internal";
      var contraId = this.selectedContraInternalRowData[0]["internal_contra_id"];
    }

    if(this.selectedContraExternalRowData !== "")
    {
      var contraSide = "External";
      var contraId = this.selectedContraExternalRowData[0]["external_contra_id"];
    }

    let data = {
      "tenantId": this.tenantId,
      "groupId": this.groupId,
      "entityId": this.entityId,
      "mProcessingLayerId": this.mProcessingLayerId,
      "mProcessingSubLayerId": this.mProcessingSubLayerId,
      "processingLayerId": this.processing_layer_id,
      "userId": this.userId,
      "contraSide": contraSide,
      "contraId": contraId
    }

    this.summaryService.setContraMatchedToUnMatchedToServer(data)
    .subscribe(
      receivedData => {
        let responseData = receivedData;
        if (responseData["Status"] === "Success")
        {
          // this.displaySelectedExternalGridContra = false;
          // this.displaySelectedInternalGridContra = false;
          this.displaySelectedContraGrid = false;
          this.getSelectedProcessingLayer(this.processing_layer_id);
  
          let data = {
            "tenant_id" : this.tenantId,
            "group_id" : this.groupId,
            "entity_id" : this.entityId,
            "m_processing_layer_id" : this.mProcessingLayerId,
            "m_processing_sub_layer_id" : this.mProcessingSubLayerId,
            "processing_layer_id" : this.processing_layer_id,
            "record_status" : "Contra"
          }
  
          this.contraShow(data);
          this.contraDisplayGrid = true;
          this.contraSearchGrid = true;
          this.selectedContraExternalRowData = '';
          this.selectedContraInternalRowData = '';
          this.ngxService.stop();
        }
        else if (responseData["Status"] === "Error")
        {
          alert("Error in UnMatching Records. Kindly Contact Advents Support!!!");
          this.ngxService.stop();
        }
        else if(responseData["Status"] === "File")
        {
          alert("File is Processing in Backend. Kindly try after sometime!!!");
          this.ngxService.stop();
        }
      }, (error:any) => {
        this.HandleErrorResponse(error);
        this.ngxService.stop();
      });

  }

  public onGroupUnMatchedExternalGridReady(params : any) : void {
    this.externalGroupUnMatchedGridApi = params.api;
    this.externalGroupUnMatchedColumnApi = params.columnApi;
  }

  public onGroupUnMatchedInternalGridReady(params : any) : void {
    this.internalGroupUnMatchedGridApi = params.api;
    this.internalGroupUnMatchedColumnApi = params.columnApi;
  }

  public quickSearchGroupUnMatched() : void {
    this.externalGroupUnMatchedGridApi.setQuickFilter(this.searchValueGroupUnMatched);
    this.internalGroupUnMatchedGridApi.setQuickFilter(this.searchValueGroupUnMatched);
  }

  public onExportGroupUnMatchedExternalExcelClick() : void {
    this.ngxService.start();
    let excelExportData = [];

    let columnsNotRequired = ["ext_processing_status_1", "external_records_id", "external_contra_id", "external_group_id", "external_debit", "external_credit", ""];
    for (var i=0; i<this.groupUnMatchedExternalRowData.length; i++)
    {
      let data = {};
      for (let key in this.groupUnMatchedExternalRowData[i])
      {
        if(!columnsNotRequired.includes(key))
        {
          data[key] = this.groupUnMatchedExternalRowData[i][key];
        }
      };
      excelExportData.push(data);
    };

    for (var i=0; i<excelExportData.length; i++)
    {
      excelExportData[i]["bank_credit"] = Number(excelExportData[i]["bank_credit"]);
      excelExportData[i]["bank_debit"] = Number(excelExportData[i]["bank_debit"].replace("-", ""));
    };

    this.excelService.exportAsExcelFile(excelExportData, "GroupUnMatched_Bank");
    this.ngxService.stop();
  }

  public onExportGroupUnMatchedInternalExcelClick() : void {
    this.ngxService.start();
    let excelExportData = [];

    let columnsNotRequired = ["int_processing_status_1", "internal_contra_id", "internal_credit", "internal_debit", "internal_group_id", "internal_records_id", ""];
    for (var i=0; i<this.groupUnMatchedInternalRowData.length; i++)
    {
      let data = {};
      for (let key in this.groupUnMatchedInternalRowData[i])
      {
        if(!columnsNotRequired.includes(key))
        {
          data[key] = this.groupUnMatchedInternalRowData[i][key];
        }
      };
      excelExportData.push(data);
    };

    for (var i=0; i<excelExportData.length; i++)
    {
      excelExportData[i]["gl_debit"] = Number(excelExportData[i]["gl_debit"]);
      excelExportData[i]["gl_credit"] = Number(excelExportData[i]["gl_credit"].replace("-", ""));
    }
    this.excelService.exportAsExcelFile(excelExportData, "GroupUnMatched_GL");
    this.ngxService.stop();
  }

  public groupUnMatchedShow(data : any) : void {
    this.ngxService.start();
    this.summaryService.getTransactionRecordsFromServer(data)
    .subscribe(
      received_data => {
        let response_data = received_data;
        console.log("Matched Chart Click Response: ", response_data);

        let externalRecordsAllColumnDefs = response_data["external_records"]["headers"];
        let externalRecordsAllrowData = response_data["external_records"]["data"];
        let internalRecordsAllColumnDefs = response_data["internal_records"]["headers"];
        let internalRecordsAllrowData = response_data["internal_records"]["data"];
        this.amountTolerance = parseFloat(response_data["amount_tolerance"]);

        // External
        externalRecordsAllColumnDefs.forEach((item, index) => {
          if(item.sortable=="true"){
            if(index === 0){
              item["checkboxSelection"] = true;
              item["maxWidth"] = 40;
              item["pinned"] = 'left';
              item.sortable=true;
              item.filter=false;
              item.resizable=false;
              item.suppressAutoSize=true;
              item.suppressSizeToFit=true;
              item.lockPosition=true;
            }
            else if (index !== 0){
              item.sortable=true;
              item.filter=true;
              item.resizable=true;
              item.suppressAutoSize=true;
              item.suppressSizeToFit=true;
              item["minWidth"] = 50;
            }

            // Hiding
            if (item.field === "external_records_id" || item.field === "external_contra_id" || item.field === "external_group_id" || item.field === "ext_processing_status_1" || item.field === "external_debit" || item.field === "external_credit")
            {
              item["hide"] = true;
            }

          }
        });

        // console.log(externalRecordsAllColumnDefs);

        this.groupUnMatchedExternalColumnDefs = externalRecordsAllColumnDefs;
        this.groupUnMatchedExternalRowData = externalRecordsAllrowData;

        // Internal
        internalRecordsAllColumnDefs.forEach((item, index) => {
          if(item.sortable=="true"){
            if(index === 0){
              item["checkboxSelection"] = true;
              item["maxWidth"] = 40;
              item["pinned"] = 'left';
              item.sortable=true;
              item.filter=false;
              item.resizable=false;
              item.suppressAutoSize=true;
              item.suppressSizeToFit=true;
              item.lockPosition=true;
            }
            else if (index !== 0){
              item.sortable=true;
              item.filter=true;
              item.resizable=true;
              item.suppressAutoSize=true;
              item.suppressSizeToFit=true;
              item["minWidth"] = 50;
            }

            // Hiding
            if (item.field === "internal_records_id" || item.field === "internal_contra_id" || item.field === "internal_group_id" || item.field === "int_processing_status_1" || item.field === "internal_debit" || item.field === "internal_credit")
            {
              item["hide"] = true;
            }

          }
        });

        this.groupUnMatchedInternalColumnDefs = internalRecordsAllColumnDefs;
        this.groupUnMatchedInternalRowData = internalRecordsAllrowData;
        this.ngxService.stop();

      },(error:any) => {
        this.HandleErrorResponse(error);
        this.ngxService.stop();
      })
  }

  public onGroupUnMatchedExternalSelectionChanged(params : any) : void {
    try 
    {
      this.ngxService.start();
      this.displaySelectedGroupUnMatchedGrid = true;
      let groupUnMatchedExternalSelectedRow = params.api.getSelectedRows();

      let selectedGroupUnMatchedExternalRecordGroupId = groupUnMatchedExternalSelectedRow[0]["external_group_id"];

      let data = {
        "tenant_id": this.tenantId,
        "group_id": this.groupId,
        "entity_id": this.entityId,
        "m_processing_layer_id": this.mProcessingLayerId,
        "m_processing_sub_layer_id": this.mProcessingSubLayerId,
        "processing_layer_id": this.processing_layer_id,
        "selected_group_id": selectedGroupUnMatchedExternalRecordGroupId
      }

      this.summaryService.getGroupUnMatchedTransactionsFromServer(data)
      .subscribe(
        received_data => {
          let response_data = received_data;
          // console.log("Selected External Group UnMatched Row Response: ", response_data);

          let externalRecordsAllColumnDefs = response_data["external_records"]["headers"];
          let externalRecordsAllrowData = response_data["external_records"]["data"];
          let internalRecordsAllColumnDefs = response_data["internal_records"]["headers"];
          let internalRecordsAllrowData = response_data["internal_records"]["data"];
          
          externalRecordsAllColumnDefs.forEach((item, index) => {
            if(item.sortable=="true"){
              if(index === 0){
                item["checkboxSelection"] = true;
                item["maxWidth"] = 40;
                item["pinned"] = 'left';
                item.sortable=true;
                item.filter=false;
                item.resizable=false;
                item.suppressAutoSize=true;
                item.suppressSizeToFit=true;
                item.lockPosition=true;
              }
              else if (index !== 0){
                item.sortable=true;
                item.filter=true;
                item.resizable=true;
                item.suppressAutoSize=true;
                item.suppressSizeToFit=true;
                item["minWidth"] = 50;
              }
  
              // Hiding
              if (item.field === "external_records_id" || item.field === "external_contra_id" || item.field === "external_group_id" || item.field === "ext_processing_status_1" || item.field === "external_debit" || item.field === "external_credit")
              {
                item["hide"] = true;
              }
  
            }
          });

          this.selectedGroupUnMatchedExternalColumnDefs = externalRecordsAllColumnDefs;
          this.selectedGroupUnMatchedExternalRowData = externalRecordsAllrowData;

          internalRecordsAllColumnDefs.forEach((item, index) => {
            if(item.sortable=="true"){
              if(index === 0){
                item["checkboxSelection"] = true;
                item["maxWidth"] = 40;
                item["pinned"] = 'left';
                item.sortable=true;
                item.filter=false;
                item.resizable=false;
                item.suppressAutoSize=true;
                item.suppressSizeToFit=true;
                item.lockPosition=true;
              }
              else if (index !== 0){
                item.sortable=true;
                item.filter=true;
                item.resizable=true;
                item.suppressAutoSize=true;
                item.suppressSizeToFit=true;
                item["minWidth"] = 50;
              }
  
              // Hiding
              if (item.field === "internal_records_id" || item.field === "internal_contra_id" || item.field === "internal_group_id" || item.field === "int_processing_status_1" || item.field === "internal_debit" || item.field === "internal_credit")
              {
                item["hide"] = true;
              }
  
            }
          });

          this.selectedGroupUnMatchedInternalColumnDefs = internalRecordsAllColumnDefs;
          this.selectedGroupUnMatchedInternalRowData = internalRecordsAllrowData;

          this.updateGroupUnMatchedConsolidatedAmount();

          this.ngxService.stop();
        },
        (error:any) => 
          {
            this.HandleErrorResponse(error);
            this.ngxService.stop();
          }
        )
    } 
    catch(error) 
    {
      // console.log(error);
      this.selectedGroupUnMatchedExternalRowData = '';
      this.displaySelectedGroupUnMatchedGrid = false;
      this.ngxService.stop();
    }
  }

  public onSelectedGroupUnMatchedInternalSelectionChanged(params : any) : void {
    let selectedData = params.api.getSelectedRows();
    if (selectedData.length)
    {
      let newSelectedGroupUnMatchedInternalRecordsList = [];
      for (var i=0; i<this.selectedGroupUnMatchedInternalRowData.length; i++)
      {
        if (this.selectedGroupUnMatchedInternalRowData[i]["internal_records_id"] !== selectedData[0]["internal_records_id"])
        {
          newSelectedGroupUnMatchedInternalRecordsList.push(this.selectedGroupUnMatchedInternalRowData[i]);
        }
      };
      this.selectedGroupUnMatchedInternalRowData = '';
      this.selectedGroupUnMatchedInternalRowData = newSelectedGroupUnMatchedInternalRecordsList;
    }
    this.updateGroupUnMatchedConsolidatedAmount();
  }

  public onSelectedGroupUnMatchedExternalSelectionChanged(params : any) : void {
    let selectedData = params.api.getSelectedRows();
    if (selectedData.length)
    {
      let newSelectedGroupMatchedExternalRecordsList = [];
      for (var i=0; i<this.selectedGroupUnMatchedExternalRowData.length; i++)
      {
        if (this.selectedGroupUnMatchedExternalRowData[i]["external_records_id"] !== selectedData[0]["external_records_id"])
        {
          newSelectedGroupMatchedExternalRecordsList.push(this.selectedGroupUnMatchedExternalRowData[i]);
        }
      };
      this.selectedGroupUnMatchedExternalRowData = '';
      this.selectedGroupUnMatchedExternalRowData = newSelectedGroupMatchedExternalRecordsList;
    }
    this.updateGroupUnMatchedConsolidatedAmount();
  }

  public updateGroupUnMatchedConsolidatedAmount() : void {

    this.groupUnMatchedUnMatchButton = false;
    this.groupUnMatchedMatchButton = false;

    let selectedExternalDebitAmount = 0.00;
    let selectedExternalCreditAmount = 0.00;
    for(let i:number = 0; i<this.selectedGroupUnMatchedExternalRowData.length; i++)
    {
      selectedExternalDebitAmount = selectedExternalDebitAmount + parseFloat(this.selectedGroupUnMatchedExternalRowData[i].external_debit);
      selectedExternalCreditAmount = selectedExternalCreditAmount + parseFloat(this.selectedGroupUnMatchedExternalRowData[i].external_credit);
      this.selectedGroupedUnMatchedExternalAmount = selectedExternalDebitAmount + selectedExternalCreditAmount;
    };

    let selectedInternalDebitAmount = 0.00;
    let selectedInternalCreditAmount = 0.00;
    for(let i:number = 0; i<this.selectedGroupUnMatchedInternalRowData.length; i++)
    {
      selectedInternalDebitAmount = selectedInternalDebitAmount + parseFloat(this.selectedGroupUnMatchedInternalRowData[i].internal_debit);
      selectedInternalCreditAmount = selectedInternalCreditAmount + parseFloat(this.selectedGroupUnMatchedInternalRowData[i].internal_credit);
      this.selectedGroupedUnMatchedInternalAmount = selectedInternalDebitAmount + selectedInternalCreditAmount;
    }

    if (!this.selectedGroupUnMatchedExternalRowData.length)
    {
      this.selectedGroupedUnMatchedExternalAmount = 0.00;
    }

    if (!this.selectedGroupUnMatchedInternalRowData.length)
    {
      this.selectedGroupedUnMatchedInternalAmount = 0.00;
    }

    if (this.selectedGroupUnMatchedExternalRowData.length && this.selectedGroupUnMatchedInternalRowData.length)
    {
      this.groupUnMatchedUnMatchButton = true;
    }
    else if (!this.selectedGroupUnMatchedExternalRowData.length || !this.selectedGroupUnMatchedInternalRowData.length)
    {
      this.groupUnMatchedUnMatchButton = false;
      this.groupUnMatchedMatchButton = false;
    }

    if ( ( this.selectedGroupUnMatchedExternalRowData.length && this.selectedGroupUnMatchedInternalRowData.length ) && (this.selectedGroupedUnMatchedExternalAmount === this.selectedGroupedUnMatchedInternalAmount) )
    {
      this.groupUnMatchedUnMatchButton = true;
      this.groupUnMatchedMatchButton = true;
    }
  }

  public onGroupUnMatchedUnMatchButtonClick() : void {
    this.ngxService.start();
    let params = {
      "tenantId": this.tenantId,
      "groupId": this.groupId,
      "entityId": this.entityId,
      "mProcessingLayerId": this.mProcessingLayerId,
      "mProcessingSubLayerId": this.mProcessingSubLayerId,
      "processingLayerId": this.processing_layer_id,
      "userId": this.userId,
      "externalRecordsList": this.selectedGroupUnMatchedExternalRowData,
      "internalRecordsList": this.selectedGroupUnMatchedInternalRowData
    };
    // console.log("Get Update Group UnMatched Match Input Params", params);
    this.summaryService.getUpdateGroupUnMatchedUnMatchToServer(params)
    .subscribe(
      receivedData => {
        let responseData = receivedData;
        if (responseData["Status"] === "Success")
        {
          this.displaySelectedContraGrid = false;
          this.getSelectedProcessingLayer(this.processing_layer_id);
  
          let data = {
            "tenant_id" : this.tenantId,
            "group_id" : this.groupId,
            "entity_id" : this.entityId,
            "m_processing_layer_id" : this.mProcessingLayerId,
            "m_processing_sub_layer_id" : this.mProcessingSubLayerId,
            "processing_layer_id" : this.processing_layer_id,
            "record_status" : "GroupUnMatched"
          }
  
          this.groupUnMatchedShow(data);
          this.groupUnMatchedDisplayGrid = true;
          this.groupUnMatchedSearchGrid = true;
          this.selectedGroupUnMatchedExternalRowData = '';
          this.selectedGroupUnMatchedInternalRowData = '';
          this.ngxService.stop();
        }
        else if (responseData["Status"] === "Error")
        {
          alert("Error in UnMatching Records. Kindly Contact Advents Support!!!");
          this.ngxService.stop();
        }
        else if(responseData["Status"] === "File")
        {
          alert("File is Processing in Backend. Kindly try after sometime!!!");
          this.ngxService.stop();
        }
      }
    ),
    (error : any) => {
      this.HandleErrorResponse(error);
    };
  }

  public onGroupUnMatchedMatchButtonClick() : void {
    this.ngxService.start();
    let params = {
      "tenantId": this.tenantId,
      "groupId": this.groupId,
      "entityId": this.entityId,
      "mProcessingLayerId": this.mProcessingLayerId,
      "mProcessingSubLayerId": this.mProcessingSubLayerId,
      "processingLayerId": this.processing_layer_id,
      "userId": this.userId,
      "externalRecordsList": this.selectedGroupUnMatchedExternalRowData,
      "internalRecordsList": this.selectedGroupUnMatchedInternalRowData,
      "matchingCommentId": this.matchingCommentIdchosen,
      "matchingCommentDescription": this.matchingCommentDescription
    };

    this.summaryService.getUpdateGroupUnMatchedMatchToServer(params)
    .subscribe(
      receivedData => {
        let responseData = receivedData;
        console.log("Update Group UnMatched Match Response", responseData);
        if (responseData["Status"] === "Success")
        {
          this.displaySelectedContraGrid = false;
          this.getSelectedProcessingLayer(this.processing_layer_id);
  
          let data = {
            "tenant_id" : this.tenantId,
            "group_id" : this.groupId,
            "entity_id" : this.entityId,
            "m_processing_layer_id" : this.mProcessingLayerId,
            "m_processing_sub_layer_id" : this.mProcessingSubLayerId,
            "processing_layer_id" : this.processing_layer_id,
            "record_status" : "GroupUnMatched"
          }
  
          this.groupUnMatchedShow(data);
          this.groupUnMatchedDisplayGrid = true;
          this.groupUnMatchedSearchGrid = true;
          this.selectedGroupUnMatchedExternalRowData = '';
          this.selectedGroupUnMatchedInternalRowData = '';
          this.ngxService.stop();
        }
        else if (responseData["Status"] === "Error")
        {
          alert("Error in UnMatching Records. Kindly Contact Advents Support!!!");
          this.ngxService.stop();
        }
        else if(responseData["Status"] === "File")
        {
          alert("File is Processing in Backend. Kindly try after sometime!!!");
          this.ngxService.stop();
        }
      }
    ),
    (error : any) => {
      this.HandleErrorResponse(error);
    };
  }

  public onAllExternalGridReady(params : any) : void {
    this.externalAllGridApi = params.api;
    this.externalAllColumnApi = params.columnApi;
  }

  public onAllInternalGridReady(params : any) : void {
    this.internalAllGridApi = params.api;
    this.internalAllColumnApi = params.columnApi;
  }

  public quickSearchAll() : void {
    this.externalAllGridApi.setQuickFilter(this.searchValueAll);
    this.internalAllGridApi.setQuickFilter(this.searchValueAll);
  }

  public allRecordsShow(data : any) : void {
    this.ngxService.start();
    this.summaryService.getTransactionRecordsFromServer(data)
    .subscribe(
      received_data => {
        let response_data = received_data;
        console.log("Matched Chart Click Response: ", response_data);

        let externalRecordsAllColumnDefs = response_data["external_records"]["headers"];
        let externalRecordsAllrowData = response_data["external_records"]["data"];
        let internalRecordsAllColumnDefs = response_data["internal_records"]["headers"];
        let internalRecordsAllrowData = response_data["internal_records"]["data"];
        this.amountTolerance = parseFloat(response_data["amount_tolerance"]);

        // External
        externalRecordsAllColumnDefs.forEach((item, index) => {
          if(item.sortable=="true"){
            if(index === 0){
              item["checkboxSelection"] = true;
              item["maxWidth"] = 40;
              item["pinned"] = 'left';
              item.sortable=true;
              item.filter=false;
              item.resizable=false;
              item.suppressAutoSize=true;
              item.suppressSizeToFit=true;
              item.lockPosition=true;
            }
            else if (index !== 0){
              item.sortable=true;
              item.filter=true;
              item.resizable=true;
              item.suppressAutoSize=true;
              item.suppressSizeToFit=true;
              item["minWidth"] = 50;
            }

            // Hiding
            if (item.field === "external_records_id" || item.field === "external_contra_id" || item.field === "external_group_id" || item.field === "ext_processing_status_1" || item.field === "external_debit" || item.field === "external_credit" || item.field === "ext_org_date")
            {
              item["hide"] = true;
            }

          }
        });

        // console.log(externalRecordsAllColumnDefs);

        this.allExternalColumnDefs = externalRecordsAllColumnDefs;
        this.allExternalRowData = externalRecordsAllrowData;

        // Internal
        internalRecordsAllColumnDefs.forEach((item, index) => {
          if(item.sortable=="true"){
            if(index === 0){
              item["checkboxSelection"] = true;
              item["maxWidth"] = 40;
              item["pinned"] = 'left';
              item.sortable=true;
              item.filter=false;
              item.resizable=false;
              item.suppressAutoSize=true;
              item.suppressSizeToFit=true;
              item.lockPosition=true;
            }
            else if (index !== 0){
              item.sortable=true;
              item.filter=true;
              item.resizable=true;
              item.suppressAutoSize=true;
              item.suppressSizeToFit=true;
              item["minWidth"] = 50;
            }

            // Hiding
            if (item.field === "internal_records_id" || item.field === "internal_contra_id" || item.field === "internal_group_id" || item.field === "int_processing_status_1" || item.field === "internal_debit" || item.field === "internal_credit")
            {
              item["hide"] = true;
            }

          }
        });

        this.allInternalColumnDefs = internalRecordsAllColumnDefs;
        this.allInternalRowData = internalRecordsAllrowData;
        this.ngxService.stop();

      },(error:any) => {
        this.HandleErrorResponse(error);
        this.ngxService.stop();
      })
  }

  public onAllExternalSelectionChanged(params : any) : void {
    try
    {
      let selectedData = params.api.getSelectedRows();
      console.log("External Row Data Selected", selectedData);
      if (selectedData.length > 0)
      {
        this.editButtonEnable = true;
        this.externalRecordsId = selectedData[0]["external_records_id"];
        let externalOriginalDate = selectedData[0]["ext_org_date"];
        let externalDate = externalOriginalDate.split(" ")[0];
        this.bankDate = externalDate
      }
      else
      {
        this.editButtonEnable = false;
      }
    }
    catch (error : any)
    {
      this.editButtonEnable = false;
    }
  }

  public onSaveButtonClick() : void {
    // console.log("Button Type Clicked", this.buttonTypeClicked)
    if(this.matchingCommentIdchosen == '0')
    {
      alert("Kindly Choose the Matching Comments!!!");
    }
    else if (this.buttonTypeClicked == 'MatchButtonUnMatchedSide')
    {
      this.onMatchButtonClick();
    }
    else if(this.buttonTypeClicked == 'ContraButtonUnMatchedSide')
    {
      this.onContraButtonClick();
    }
    else if(this.buttonTypeClicked == 'MatchButtonGroupUnMatchedSide')
    {
      this.onGroupUnMatchedMatchButtonClick();
    }
  }

  // public getBalances() : void {
  //   let params = {
  //     "tenantsId": this.tenantId,
  //     "groupsId": this.groupId,
  //     "entityId": this.entityId,
  //     "mProcessingLayerId": this.mProcessingLayerId,
  //     "mProcessingSubLayerId": this.mProcessingSubLayerId,
  //     "processingLayerId": this.processing_layer_id
  //   };

  //   this.summaryService.getBalancesFromServer(params)
  //   .subscribe(
  //     receivedData => {
  //       let responseData = receivedData;

  //       if(responseData["Status"] === "Success")
  //       {
  //         let data = responseData["data"];
  //         this.bankBalance = data["bank_balance"];
  //         this.glBalance = data["gl_balance"];
  //       }
  //     }
  //   )
  // };

  public updateDuplicates() : void {
    this.ngxService.start();
    let params = {
      "tenantsId": this.tenantId,
      "groupsId": this.groupId,
      "entityId": this.entityId,
      "mProcessingLayerId": this.mProcessingLayerId,
      "mProcessingSubLayerId": this.mProcessingSubLayerId,
      "processingLayerId": this.processing_layer_id,
      "userId": this.userId,
      "externalRecords": this.selectedUnMatchedExternalRowData,
      "internalRecords": this.selectedUnMatchedInternalRowData
    };

    this.summaryService.getUpdateDuplicateRecordsToServer(params)
    .subscribe(
      receivedData => {
        let responseData = receivedData;
        // console.log("Duplicate Records Update Response", responseData);
        if(responseData["Status"] === "Success")
        {
          this.displaySelectedUnMatchedGrid = false;
          this.getSelectedProcessingLayer(this.processing_layer_id);

          let data = {
            "tenant_id" : this.tenantId,
            "group_id" : this.groupId,
            "entity_id" : this.entityId,
            "m_processing_layer_id" : this.mProcessingLayerId,
            "m_processing_sub_layer_id" : this.mProcessingSubLayerId,
            "processing_layer_id" : this.processing_layer_id,
            "record_status" : "UnMatched"
          }

          this.unMatchedGridShow(data);
          this.unMatchedDisplayGrid = true;
          this.unMatchedSearchGrid = true;
          this.selectedUnMatchedExternalRowData = '';
          this.selectedUnMatchedInternalRowData = '';
          this.ngxService.stop();

        }
        else if(responseData["Status"] === "Error")
        {
          alert("Error in Matching Records. Kindly Contact Advents Support!!!");
          this.ngxService.stop();
        }
        else if(responseData["Status"] === "File")
        {
          alert("File is Processing in Backend. Kindly try after sometime!!!");
          this.ngxService.stop();
        }
      }
    ),
    (error : any) => {
      this.HandleErrorResponse(error);
      this.ngxService.stop();
    }

  }

  public resetFilter() : void {
    this.searchValue = null;
    this.searchValueUnMatched = null;
    this.searchValueGroupMatched = null;
    this.searchValueContra = null;
    this.searchValueGroupUnMatched = null;

    if(this.internalGridApi !== undefined && this.externalGridApi !== undefined)
    {
      if (this.matchedDisplayGrid)
      {
        this.quickSearch();
      }
    }
    
    if(this.externalUnMatchedGridApi !== undefined && this.internalUnMatchedGridApi !== undefined)
    {
      if (this.unMatchedDisplayGrid)
      {
        this.quickSearchUnMatched();
      }
    }

    if(this.externalGroupMatchedGridApi !== undefined && this.internalGroupMatchedGridApi !== undefined)
    {
      if (this.groupMatchedDisplayGrid)
      {
        this.quickSearchGroupMatched();
      }
    }

    if(this.externalContraGridApi !== undefined && this.internalContraGridApi !== undefined)
    {
      if (this.contraDisplayGrid)
      {
        this.quickSearchContra();
      }
    }

    if(this.externalGroupUnMatchedGridApi !== undefined && this.internalGroupUnMatchedGridApi !== undefined)
    {
      if (this.groupUnMatchedDisplayGrid)
      {
        this.quickSearchGroupUnMatched();
      }
    }
  }

  public HandleErrorResponse(err: any) : void {
    //  this.objerrhandler.handleError(String(err));
   console.log("Error",err);
  }

}
