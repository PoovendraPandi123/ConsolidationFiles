import { Component, OnInit, ViewChild } from '@angular/core';
import { AgGridAngular } from 'ag-grid-angular';
import { ChartType} from 'chart.js';
import { AlcsOperationService } from 'src/app/service/alcs-operation.service';
import { NgxUiLoaderService } from "ngx-ui-loader"; // Import NgxUiLoaderService

@Component({
  selector: 'app-alcs-operations',
  templateUrl: './alcs-operations.component.html',
  styleUrls: ['./alcs-operations.component.css']
})
export class AlcsOperationsComponent implements OnInit {

  @ViewChild('agGrid')
  agGrid!: AgGridAngular;

  public processingLayerList: any;
  public selectedProcessingLayerId: string;
  public barChartOptions = {
    scaleShowVerticalLines: false,
    responsive: true,
    title : {
      display : true,
      text : "Reconciliation Summary",
      fontSize : 16,
      fontColor : '#004e98',
    },
    legend : {
      position : "right",
      display : true
    }
  };
  public barChartLabels = [] as any;
  public barChartData = [{ data : []}] as any;
  public barChartLegend = true;
  public colorOptions : any;
  public barChartType: ChartType = 'doughnut';
  public chartSection: boolean;
  public letterDate: string;
  public chartTypeClicked: string;
  public bankTransfersGrid: boolean;
  public pagination: boolean;
  public paginationSize: number;
  public searchValue: string;
  public externalGridApi: any;
  public externalGridColumnApi: any;
  public internalGridApi: any;
  public internalGridColumnApi: any;
  public displaySelectedUnMatchedGrid: boolean;
  public paymentDateList: any;
  public matchButtonEnable: boolean;
  public rejectButtonEnable: boolean;

  public externalRowData: any;
  public externalColumnDefs: any;
  public selectedExternalRowData: any;
  public selectedExternalColumnDefs: any;
  public selectedUnMatchedExternalAmount: string;

  public internalRowData: any;
  public internalColumnDefs: any;
  public selectedInternalRowData: any;
  public selectedInternalColumnDefs: any;
  public selectedUnMatchedInternalAmount: string;
  public userDetails: any;
  public userId: number;

  constructor(private operationService: AlcsOperationService, private ngxService: NgxUiLoaderService) 
  {
    this.processingLayerList = [];
    this.selectedProcessingLayerId = '';
    this.chartSection = false;
    this.letterDate = '';
    this.chartTypeClicked = '';
    this.bankTransfersGrid = false;
    this.pagination = false;
    this.paginationSize = null;

    this.externalRowData = [];
    this.externalColumnDefs = [];
    this.selectedExternalRowData = [];
    this.selectedExternalColumnDefs = [];

    this.internalRowData = [];
    this.internalColumnDefs = [];
    this.selectedInternalRowData = [];
    this.selectedInternalColumnDefs = [];

    this.searchValue = '';
    this.displaySelectedUnMatchedGrid = false;
    this.paymentDateList = [];
    this.matchButtonEnable = false;
    this.selectedUnMatchedExternalAmount = '';
    this.selectedUnMatchedInternalAmount = '';
    this.rejectButtonEnable = false;
    this.userDetails = [];
    this.userId = null;
  }

  public ngOnInit(): void {
    this.userDetails = JSON.parse(sessionStorage.getItem("user_details"));
    this.userId = this.userDetails["user_id"];
    this.initProcessingLayerList();
    this.pagination = true;
    this.paginationSize = 10;
    this.selectedProcessingLayerId = '0';
    this.selectedExternalRowData = [];
  }

  public onExternalGridReady(params : any) : void {
    this.externalGridApi = params.api;
    this.externalGridColumnApi = params.columnApi;
  }

  public onInternalGridReady(params : any) : void {
    this.internalGridApi = params.api;
    this.internalGridColumnApi = params.columnApi;
  }


  public onExternalSelectionChanged(event : any) : void {
    this.displaySelectedUnMatchedGrid = true;

    this.selectedExternalRowData = event.api.getSelectedRows();

    let externalAmountTotal = 0.00;

    for (var i=0; i<this.selectedExternalRowData.length; i++)
    {
      externalAmountTotal = externalAmountTotal + Number(this.selectedExternalRowData[i]["ext_amount_1"]);
    }
    this.selectedUnMatchedExternalAmount = String(externalAmountTotal).replace("-", "");
  }

  public onInternalSelectionChanged(event : any) : void {
    this.displaySelectedUnMatchedGrid = true;
    this.matchButtonEnable = true;
    this.rejectButtonEnable = true;
    let selectedInternalRowDataVar = event.api.getSelectedRows();

    let internalRecordsUnMatchedForRemoval = [];

    for (var i=0; i<this.internalRowData.length; i++)
    {
      if (this.internalRowData[i]["int_reference_text_13"] == selectedInternalRowDataVar[0]["int_reference_text_13"])
      {

      }
      else
      {
        internalRecordsUnMatchedForRemoval.push(this.internalRowData[i]);
      }
    };
    this.internalRowData = internalRecordsUnMatchedForRemoval;

    this.paymentDateList.push(selectedInternalRowDataVar[0]["int_reference_text_13"])

    let params = {
      "processingLayerId": this.selectedProcessingLayerId,
      "paymentDateList": this.paymentDateList,
      "letterDate": this.letterDate
    };

    this.operationService.getIntUnMatchedDateRecordsFromServer(params)
    .subscribe(
      receivedData => {
        let responseData = receivedData;
        console.log("IntUnMatched Date Records Response ", responseData);
        this.selectedInternalRowData = responseData["data"]["data"];

        let internalAmountTotal = 0.00;
        for (var j=0; j<this.selectedInternalRowData.length; j++)
        {
          internalAmountTotal = internalAmountTotal + Number(this.selectedInternalRowData[j]["int_amount_1"]);
        };
        this.selectedUnMatchedInternalAmount = String(internalAmountTotal).replace("-", "");

      }
    ),
    (error : any) => {
      this.HandleErrorResponse(error);
    }
  }

  public onSelectedInternalUnMatchedSelectionChanged(event : any) : void {
    let selectedInternalUnMatchedRowData = event.api.getSelectedRows();
    console.log("Selected Internal", selectedInternalUnMatchedRowData);
  }
 
  public onExportButtonClick() : void {

  }

  public initProcessingLayerList() : void {
    this.processingLayerList = this.operationService.getProcessingLayerListFromServer();
  }

  public searchClick() : void {
    this.bankTransfersGrid = false;
    this.displaySelectedUnMatchedGrid = false;
    this.externalRowData = undefined;
    this.internalRowData = undefined;
    this.selectedExternalRowData = undefined;
    this.selectedInternalRowData = undefined;
    this.paymentDateList = [];
    this.selectedUnMatchedExternalAmount = '';
    this.selectedUnMatchedInternalAmount = '';

    if (this.selectedProcessingLayerId == '0' )
    {
      alert("Kindly choose Reconciliation Type!!!");
      this.chartSection = false;
    }
    else if (this.letterDate == '')
    {
      alert("Kindly choose the Input Date!!!");
    }
    else
    {
      this.chartSection = true;
      this.getTransactionCount();
      this.getGridHeaders();
    }
  }

  public onMatchButtonClick() : void {
    let externalAmountTotal = null;
    let internalAmountTotal = null;
    let internalRecordsList = [];

    for (var i=0; i<this.selectedExternalRowData.length; i++)
    {
      externalAmountTotal = externalAmountTotal + Number(String(this.selectedExternalRowData[i]["ext_amount_1"]).replace("-", ""));
    }

    for (var j=0; j<this.selectedInternalRowData.length; j++)
    {
      internalAmountTotal = internalAmountTotal + Number(String(this.selectedInternalRowData[j]["int_amount_1"]).replace("-", ""));
      internalRecordsList.push(this.selectedInternalRowData[j]["id"])
    }

    if (externalAmountTotal == null)
    {
      alert("Please Choose Bank Record to Match!!!");
    }
    else if (internalAmountTotal == null)
    {
      alert("Please Choose Internal Records to Match!!!");
    }
    else if (externalAmountTotal != internalAmountTotal)
    {
      alert("Bank Amount not Match with the Letters Consolidated Amount!!!");
    }
    else
    {
      this.ngxService.start();
      let params = {
        "externalRecordsId": this.selectedExternalRowData[0]["id"],
        "internalRecordsIdList": internalRecordsList
      };

      this.operationService.getUpdateUnMatchedTransactionsToServer(params)
      .subscribe(
        receivedData => {
          let responseData = receivedData;
          console.log("Update UnMatched Transactions Response ", responseData);
          alert("Records Matched Successfully!!!");
          this.displaySelectedUnMatchedGrid = false;
          this.externalRowData = undefined;
          this.internalRowData = undefined;
          this.selectedExternalRowData = undefined;
          this.selectedInternalRowData = undefined;
          this.paymentDateList = [];
          this.selectedUnMatchedExternalAmount = '';
          this.selectedUnMatchedInternalAmount = '';
          this.getTransactionRecords();
          this.getTransactionCount();
          this.ngxService.stop();
        }
      ),
      (error : any) => {
        this.HandleErrorResponse(error);
        this.ngxService.stop();
      }
    }
  }

  public onRejectButtonClick() : void {

    let internalRecordsIdList = [];

    for (var i=0; i<this.selectedInternalRowData.length; i++)
    {
      internalRecordsIdList.push(this.selectedInternalRowData[i]["id"]);
    }

    let params = {
      "internalRecordsIdList": internalRecordsIdList,
      "userId": this.userId
    };

    this.ngxService.start();

    this.operationService.getUpdateRejectAllTransactionsToServer(params)
    .subscribe(
      receivedData => {
        let responseData = receivedData;
        // console.log("Reject Button Click Response ", responseData);
        if (responseData["Status"] == "Success")
        {
          alert("All Records Rejected Successfully!!!");
        }
        else if (responseData["Status"] == "Error")
        {
          alert("Error in Updating Records as Rejected. Please contact Advents Support!!!");
        }
        this.displaySelectedUnMatchedGrid = false;
        this.externalRowData = undefined;
        this.internalRowData = undefined;
        this.selectedExternalRowData = undefined;
        this.selectedInternalRowData = undefined;
        this.paymentDateList = [];
        this.selectedUnMatchedExternalAmount = '';
        this.selectedUnMatchedInternalAmount = '';
        this.getTransactionRecords();
        this.getTransactionCount();
        this.ngxService.stop();
      }
    ),
    (error : any) => {
      this.HandleErrorResponse(error);
    }
  }

  public generateLetterNumber() : void {

    if (this.selectedProcessingLayerId == '0' )
    {
      alert("Kindly choose Reconciliation Type!!!");
      this.chartSection = false;
    }
    else if (this.letterDate == '')
    {
      alert("Kindly choose the Input Date!!!");
    }
    else
    {
      this.ngxService.start();
      let params = {
        "processingLayerId": this.selectedProcessingLayerId,
        "letterDate": this.letterDate
      };
  
      this.operationService.getUpdateLetterNumbersToServer(params)
      .subscribe(
        receivedData => {
          let responseData = receivedData;
          console.log("Generate Letter Number Response ", responseData);
          if (responseData["Status"] == "Success")
          {
            alert("Letter Numbers Re-Generated Successfully!!!");
          }
          else if (responseData["Status"] == "Error")
          {
            alert("Error in Re-Generating Letter Numbers. Please Contact Advents Support!!!");
          }
          this.ngxService.stop();
        }
      ),
      (error : any) => {
        this.HandleErrorResponse(error);
        this.ngxService.stop();
      }
    }
  }

  public getGridHeaders() : void {
    if (this.selectedProcessingLayerId == '400')
    {// suppressSizeToFit: true, headerCheckboxSelection: true, headerCheckboxSelectionFilteredOnly: true
      this.externalColumnDefs = [
        {headerName: 'Transaction Date', field: 'ext_reference_date_time_1', sortable: true, filter: true, resizable: true, checkboxSelection: true, maxWidth: 40, pinned: 'left', suppressAutoSize: true},
        {headerName: 'Transaction Particulars', field: 'ext_reference_text_1', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Chq No', field: 'ext_reference_text_2', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'CR/DR', field: 'ext_reference_text_3', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Amount (Rs.)', field: 'ext_amount_1', sortable: true, filter: true, resizable: true, minWidth: 50},
      ];
      this.internalColumnDefs = [
        {headerName: 'Bank Name', field: 'int_reference_text_1', sortable: true, filter: true, resizable: true, checkboxSelection: true, maxWidth: 40, pinned: 'left'},
        {headerName: 'Account No', field: 'int_reference_text_2', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Accpac Code', field: 'int_reference_text_3', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Date', field: 'int_reference_date_time_1', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Acc #', field: 'int_reference_text_4', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Issued Amt', field: 'int_amount_1', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Name', field: 'int_reference_text_5', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Company', field: 'int_reference_text_6', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Emp#', field: 'int_reference_text_7', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Client Id', field: 'int_reference_text_8', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Remarks', field: 'int_reference_text_9', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Invoice Number', field: 'int_reference_text_10', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'IFSC CODES', field: 'int_reference_text_11', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Letter upload No', field: 'int_reference_text_12', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'PM_Payment_Date', field: 'int_reference_text_13', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'UTR Number', field: 'int_reference_text_14', sortable: true, filter: true, resizable: true, minWidth: 50}
      ];
      this.selectedExternalColumnDefs = [
        {headerName: 'Transaction Date', field: 'ext_reference_date_time_1', sortable: true, filter: true, resizable: true, checkboxSelection: true, maxWidth: 40, pinned: 'left'},
        {headerName: 'Transaction Particulars', field: 'ext_reference_text_1', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Chq No', field: 'ext_reference_text_2', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'CR/DR', field: 'ext_reference_text_3', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Amount (Rs.)', field: 'ext_amount_1', sortable: true, filter: true, resizable: true, minWidth: 50},
      ];
      this.selectedInternalColumnDefs = [
        {headerName: 'Bank Name', field: 'int_reference_text_1', sortable: true, filter: true, resizable: true, checkboxSelection: true, maxWidth: 40, pinned: 'left'},
        {headerName: 'Account No', field: 'int_reference_text_2', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Accpac Code', field: 'int_reference_text_3', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Date', field: 'int_reference_date_time_1', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Acc #', field: 'int_reference_text_4', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Issued Amt', field: 'int_amount_1', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Name', field: 'int_reference_text_5', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Company', field: 'int_reference_text_6', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Emp#', field: 'int_reference_text_7', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Client Id', field: 'int_reference_text_8', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Remarks', field: 'int_reference_text_9', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Invoice Number', field: 'int_reference_text_10', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'IFSC CODES', field: 'int_reference_text_11', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Letter upload No', field: 'int_reference_text_12', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'PM_Payment_Date', field: 'int_reference_text_13', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'UTR Number', field: 'int_reference_text_14', sortable: true, filter: true, resizable: true, minWidth: 50}
      ];
    }
    else if (this.selectedProcessingLayerId == '401')
    {
      this.externalColumnDefs = [
        {headerName: 'Tran. Id', field: 'ext_reference_text_1', sortable: true, filter: true, resizable: true, checkboxSelection: true, maxWidth: 40, pinned: 'left'},
        {headerName: 'Value Date', field: 'ext_reference_date_time_1', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Transaction Date', field: 'ext_reference_date_time_2', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Transaction Posted Date', field: 'ext_reference_date_time_3', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Cheque. No./Ref. No.', field: 'ext_reference_text_2', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Transaction Remarks', field: 'ext_reference_text_3', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Withdrawal Amt (INR)', field: 'ext_amount_1', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Deposit Amt (INR)', field: 'ext_amount_3', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Balance (INR)', field: 'ext_amount_2', sortable: true, filter: true, resizable: true, minWidth: 50}
      ];
      this.internalColumnDefs = [
        {headerName: 'Bank Name', field: 'int_reference_text_1', sortable: true, filter: true, resizable: true, checkboxSelection: true, maxWidth: 40, pinned: 'left'},
        {headerName: 'Account No', field: 'int_reference_text_2', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Accpac Code', field: 'int_reference_text_3', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Date', field: 'int_reference_date_time_1', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Acc #', field: 'int_reference_text_4', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Issued Amt', field: 'int_amount_1', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Name', field: 'int_reference_text_5', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Company', field: 'int_reference_text_6', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Emp#', field: 'int_reference_text_7', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Client Id', field: 'int_reference_text_8', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Remarks', field: 'int_reference_text_9', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Invoice Number', field: 'int_reference_text_10', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'IFSC CODES', field: 'int_reference_text_11', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Letter upload No', field: 'int_reference_text_12', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'PM_Payment_Date', field: 'int_reference_text_13', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'UTR Number', field: 'int_reference_text_14', sortable: true, filter: true, resizable: true, minWidth: 50}
      ];
      this.selectedExternalColumnDefs = [
        {headerName: 'Tran. Id', field: 'ext_reference_text_1', sortable: true, filter: true, resizable: true, checkboxSelection: true, maxWidth: 40, pinned: 'left'},
        {headerName: 'Value Date', field: 'ext_reference_date_time_1', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Transaction Date', field: 'ext_reference_date_time_2', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Transaction Posted Date', field: 'ext_reference_date_time_3', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Cheque. No./Ref. No.', field: 'ext_reference_text_2', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Transaction Remarks', field: 'ext_reference_text_3', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Withdrawal Amt (INR)', field: 'ext_amount_1', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Deposit Amt (INR)', field: 'ext_amount_3', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Balance (INR)', field: 'ext_amount_2', sortable: true, filter: true, resizable: true, minWidth: 50}
      ];
      this.selectedInternalColumnDefs = [
        {headerName: 'Bank Name', field: 'int_reference_text_1', sortable: true, filter: true, resizable: true, checkboxSelection: true, maxWidth: 40, pinned: 'left'},
        {headerName: 'Account No', field: 'int_reference_text_2', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Accpac Code', field: 'int_reference_text_3', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Date', field: 'int_reference_date_time_1', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Acc #', field: 'int_reference_text_4', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Issued Amt', field: 'int_amount_1', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Name', field: 'int_reference_text_5', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Company', field: 'int_reference_text_6', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Emp#', field: 'int_reference_text_7', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Client Id', field: 'int_reference_text_8', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Remarks', field: 'int_reference_text_9', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Invoice Number', field: 'int_reference_text_10', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'IFSC CODES', field: 'int_reference_text_11', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Letter upload No', field: 'int_reference_text_12', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'PM_Payment_Date', field: 'int_reference_text_13', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'UTR Number', field: 'int_reference_text_14', sortable: true, filter: true, resizable: true, minWidth: 50}
      ]
    }
    else if (this.selectedProcessingLayerId == '402')
    {
      this.externalColumnDefs = [
        {headerName: 'Txn Date', field: 'ext_reference_date_time_1', sortable: true, filter: true, resizable: true, checkboxSelection: true, maxWidth: 40, pinned: 'left'},
        {headerName: 'Value Date', field: 'ext_reference_date_time_2', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Description', field: 'ext_reference_text_1', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Ref No./Cheque No.', field: 'ext_reference_text_2', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Branch Code', field: 'ext_reference_text_3', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Debit', field: 'ext_amount_1', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Credit', field: 'ext_amount_3', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Balance', field: 'ext_amount_2', sortable: true, filter: true, resizable: true, minWidth: 50}
      ];
      this.internalColumnDefs = [
        {headerName: 'Bank Name', field: 'int_reference_text_1', sortable: true, filter: true, resizable: true, checkboxSelection: true, maxWidth: 40, pinned: 'left'},
        {headerName: 'Account No', field: 'int_reference_text_2', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Accpac Code', field: 'int_reference_text_3', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Date', field: 'int_reference_date_time_1', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Acc #', field: 'int_reference_text_4', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Issued Amt', field: 'int_amount_1', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Name', field: 'int_reference_text_5', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Company', field: 'int_reference_text_6', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Emp#', field: 'int_reference_text_7', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Client Id', field: 'int_reference_text_8', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Remarks', field: 'int_reference_text_9', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Invoice Number', field: 'int_reference_text_10', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'IFSC CODES', field: 'int_reference_text_11', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Letter upload No', field: 'int_reference_text_12', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'PM_Payment_Date', field: 'int_reference_text_13', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'UTR Number', field: 'int_reference_text_14', sortable: true, filter: true, resizable: true, minWidth: 50}
      ];
      this.selectedExternalColumnDefs = [
        {headerName: 'Txn Date', field: 'ext_reference_date_time_1', sortable: true, filter: true, resizable: true, checkboxSelection: true, maxWidth: 40, pinned: 'left'},
        {headerName: 'Value Date', field: 'ext_reference_date_time_2', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Description', field: 'ext_reference_text_1', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Ref No./Cheque No.', field: 'ext_reference_text_2', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Branch Code', field: 'ext_reference_text_3', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Debit', field: 'ext_amount_1', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Credit', field: 'ext_amount_3', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Balance', field: 'ext_amount_2', sortable: true, filter: true, resizable: true, minWidth: 50}
      ];
      this.selectedInternalColumnDefs = [
        {headerName: 'Bank Name', field: 'int_reference_text_1', sortable: true, filter: true, resizable: true, checkboxSelection: true, maxWidth: 40, pinned: 'left'},
        {headerName: 'Account No', field: 'int_reference_text_2', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Accpac Code', field: 'int_reference_text_3', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Date', field: 'int_reference_date_time_1', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Acc #', field: 'int_reference_text_4', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Issued Amt', field: 'int_amount_1', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Name', field: 'int_reference_text_5', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Company', field: 'int_reference_text_6', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Emp#', field: 'int_reference_text_7', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Client Id', field: 'int_reference_text_8', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Remarks', field: 'int_reference_text_9', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Invoice Number', field: 'int_reference_text_10', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'IFSC CODES', field: 'int_reference_text_11', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Letter upload No', field: 'int_reference_text_12', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'PM_Payment_Date', field: 'int_reference_text_13', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'UTR Number', field: 'int_reference_text_14', sortable: true, filter: true, resizable: true, minWidth: 50}
      ];
    }
    else if (this.selectedProcessingLayerId == '403')
    {
      this.externalColumnDefs = [
        {headerName: 'Date', field: 'ext_reference_date_time_1', sortable: true, filter: true, resizable: true, checkboxSelection: true, maxWidth: 40, pinned: 'left'},
        {headerName: 'Narration', field: 'ext_reference_text_1', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Chq./Ref.No.', field: 'ext_reference_text_2', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Value Dt', field: 'ext_reference_date_time_2', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Withdrawal Amt.', field: 'ext_amount_1', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Deposit Amt.', field: 'ext_amount_3', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Closing Balance', field: 'ext_amount_2', sortable: true, filter: true, resizable: true, minWidth: 50}
      ];
      this.internalColumnDefs = [
        {headerName: 'Bank Name', field: 'int_reference_text_1', sortable: true, filter: true, resizable: true, checkboxSelection: true, maxWidth: 40, pinned: 'left'},
        {headerName: 'Account No', field: 'int_reference_text_2', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Accpac Code', field: 'int_reference_text_3', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Date', field: 'int_reference_date_time_1', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Acc #', field: 'int_reference_text_4', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Issued Amt', field: 'int_amount_1', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Name', field: 'int_reference_text_5', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Company', field: 'int_reference_text_6', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Emp#', field: 'int_reference_text_7', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Client Id', field: 'int_reference_text_8', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Remarks', field: 'int_reference_text_9', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Invoice Number', field: 'int_reference_text_10', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'IFSC CODES', field: 'int_reference_text_11', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Letter upload No', field: 'int_reference_text_12', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'PM_Payment_Date', field: 'int_reference_text_13', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'UTR Number', field: 'int_reference_text_14', sortable: true, filter: true, resizable: true, minWidth: 50}
      ];
      this.selectedExternalColumnDefs = [
        {headerName: 'Date', field: 'ext_reference_date_time_1', sortable: true, filter: true, resizable: true, checkboxSelection: true, maxWidth: 40, pinned: 'left'},
        {headerName: 'Narration', field: 'ext_reference_text_1', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Chq./Ref.No.', field: 'ext_reference_text_2', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Value Dt', field: 'ext_reference_date_time_2', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Withdrawal Amt.', field: 'ext_amount_1', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Deposit Amt.', field: 'ext_amount_3', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Closing Balance', field: 'ext_amount_2', sortable: true, filter: true, resizable: true, minWidth: 50}
      ];
      this.selectedInternalColumnDefs = [
        {headerName: 'Bank Name', field: 'int_reference_text_1', sortable: true, filter: true, resizable: true, checkboxSelection: true, maxWidth: 40, pinned: 'left'},
        {headerName: 'Account No', field: 'int_reference_text_2', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Accpac Code', field: 'int_reference_text_3', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Date', field: 'int_reference_date_time_1', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Acc #', field: 'int_reference_text_4', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Issued Amt', field: 'int_amount_1', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Name', field: 'int_reference_text_5', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Company', field: 'int_reference_text_6', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Emp#', field: 'int_reference_text_7', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Client Id', field: 'int_reference_text_8', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Remarks', field: 'int_reference_text_9', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Invoice Number', field: 'int_reference_text_10', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'IFSC CODES', field: 'int_reference_text_11', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Letter upload No', field: 'int_reference_text_12', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'PM_Payment_Date', field: 'int_reference_text_13', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'UTR Number', field: 'int_reference_text_14', sortable: true, filter: true, resizable: true, minWidth: 50}
      ];
    }
    else if (this.selectedProcessingLayerId == '404')
    {
      this.externalColumnDefs = [
        {headerName: 'Date', field: 'ext_reference_date_time_1', sortable: true, filter: true, resizable: true, checkboxSelection: true, maxWidth: 40, pinned: 'left'},
        {headerName: 'Narration', field: 'ext_reference_text_1', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Chq./Ref.No.', field: 'ext_reference_text_2', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Value Dt', field: 'ext_reference_date_time_2', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Withdrawal Amt.', field: 'ext_amount_1', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Deposit Amt.', field: 'ext_amount_3', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Closing Balance', field: 'ext_amount_2', sortable: true, filter: true, resizable: true, minWidth: 50}
      ];
      this.internalColumnDefs = [
        {headerName: 'Bank Name', field: 'int_reference_text_1', sortable: true, filter: true, resizable: true, checkboxSelection: true, maxWidth: 40, pinned: 'left'},
        {headerName: 'Account No', field: 'int_reference_text_2', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Accpac Code', field: 'int_reference_text_3', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Date', field: 'int_reference_date_time_1', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Acc #', field: 'int_reference_text_4', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Issued Amt', field: 'int_amount_1', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Name', field: 'int_reference_text_5', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Company', field: 'int_reference_text_6', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Emp#', field: 'int_reference_text_7', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Client Id', field: 'int_reference_text_8', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Remarks', field: 'int_reference_text_9', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Invoice Number', field: 'int_reference_text_10', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'IFSC CODES', field: 'int_reference_text_11', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Letter upload No', field: 'int_reference_text_12', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'PM_Payment_Date', field: 'int_reference_text_13', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'UTR Number', field: 'int_reference_text_14', sortable: true, filter: true, resizable: true, minWidth: 50}
      ];
      this.selectedExternalColumnDefs = [
        {headerName: 'Date', field: 'ext_reference_date_time_1', sortable: true, filter: true, resizable: true, checkboxSelection: true, maxWidth: 40, pinned: 'left'},
        {headerName: 'Narration', field: 'ext_reference_text_1', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Chq./Ref.No.', field: 'ext_reference_text_2', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Value Dt', field: 'ext_reference_date_time_2', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Withdrawal Amt.', field: 'ext_amount_1', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Deposit Amt.', field: 'ext_amount_3', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Closing Balance', field: 'ext_amount_2', sortable: true, filter: true, resizable: true, minWidth: 50}
      ];
      this.selectedInternalColumnDefs = [
        {headerName: 'Bank Name', field: 'int_reference_text_1', sortable: true, filter: true, resizable: true, checkboxSelection: true, maxWidth: 40, pinned: 'left'},
        {headerName: 'Account No', field: 'int_reference_text_2', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Accpac Code', field: 'int_reference_text_3', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Date', field: 'int_reference_date_time_1', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Acc #', field: 'int_reference_text_4', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Issued Amt', field: 'int_amount_1', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Name', field: 'int_reference_text_5', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Company', field: 'int_reference_text_6', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Emp#', field: 'int_reference_text_7', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Client Id', field: 'int_reference_text_8', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Remarks', field: 'int_reference_text_9', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Invoice Number', field: 'int_reference_text_10', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'IFSC CODES', field: 'int_reference_text_11', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Letter upload No', field: 'int_reference_text_12', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'PM_Payment_Date', field: 'int_reference_text_13', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'UTR Number', field: 'int_reference_text_14', sortable: true, filter: true, resizable: true, minWidth: 50}
      ];
    }
    else if (this.selectedProcessingLayerId == '405')
    {
      this.externalColumnDefs = [
        {headerName: 'Tran. Id', field: 'ext_reference_text_1', sortable: true, filter: true, resizable: true, checkboxSelection: true, maxWidth: 40, pinned: 'left'},
        {headerName: 'Value Date', field: 'ext_reference_date_time_1', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Transaction Date', field: 'ext_reference_date_time_2', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Transaction Posted Date', field: 'ext_reference_date_time_3', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Cheque. No./Ref. No.', field: 'ext_reference_text_2', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Transaction Remarks', field: 'ext_reference_text_3', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Withdrawal Amt (INR)', field: 'ext_amount_1', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Deposit Amt (INR)', field: 'ext_amount_3', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Balance (INR)', field: 'ext_amount_2', sortable: true, filter: true, resizable: true, minWidth: 50}
      ];
      this.internalColumnDefs = [
        {headerName: 'Bank Name', field: 'int_reference_text_1', sortable: true, filter: true, resizable: true, checkboxSelection: true, maxWidth: 40, pinned: 'left'},
        {headerName: 'Account No', field: 'int_reference_text_2', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Accpac Code', field: 'int_reference_text_3', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Date', field: 'int_reference_date_time_1', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Acc #', field: 'int_reference_text_4', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Issued Amt', field: 'int_amount_1', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Name', field: 'int_reference_text_5', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Company', field: 'int_reference_text_6', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Emp#', field: 'int_reference_text_7', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Client Id', field: 'int_reference_text_8', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Remarks', field: 'int_reference_text_9', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Invoice Number', field: 'int_reference_text_10', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'IFSC CODES', field: 'int_reference_text_11', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Letter upload No', field: 'int_reference_text_12', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'PM_Payment_Date', field: 'int_reference_text_13', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'UTR Number', field: 'int_reference_text_14', sortable: true, filter: true, resizable: true, minWidth: 50}
      ];
      this.selectedExternalColumnDefs = [
        {headerName: 'Tran. Id', field: 'ext_reference_text_1', sortable: true, filter: true, resizable: true, checkboxSelection: true, maxWidth: 40, pinned: 'left'},
        {headerName: 'Value Date', field: 'ext_reference_date_time_1', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Transaction Date', field: 'ext_reference_date_time_2', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Transaction Posted Date', field: 'ext_reference_date_time_3', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Cheque. No./Ref. No.', field: 'ext_reference_text_2', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Transaction Remarks', field: 'ext_reference_text_3', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Withdrawal Amt (INR)', field: 'ext_amount_1', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Deposit Amt (INR)', field: 'ext_amount_3', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Balance (INR)', field: 'ext_amount_2', sortable: true, filter: true, resizable: true, minWidth: 50}
      ];
      this.selectedInternalColumnDefs = [
        {headerName: 'Bank Name', field: 'int_reference_text_1', sortable: true, filter: true, resizable: true, checkboxSelection: true, maxWidth: 40, pinned: 'left'},
        {headerName: 'Account No', field: 'int_reference_text_2', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Accpac Code', field: 'int_reference_text_3', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Date', field: 'int_reference_date_time_1', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Acc #', field: 'int_reference_text_4', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Issued Amt', field: 'int_amount_1', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Name', field: 'int_reference_text_5', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Company', field: 'int_reference_text_6', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Emp#', field: 'int_reference_text_7', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Client Id', field: 'int_reference_text_8', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Remarks', field: 'int_reference_text_9', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Invoice Number', field: 'int_reference_text_10', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'IFSC CODES', field: 'int_reference_text_11', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'Letter upload No', field: 'int_reference_text_12', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'PM_Payment_Date', field: 'int_reference_text_13', sortable: true, filter: true, resizable: true, minWidth: 50},
        {headerName: 'UTR Number', field: 'int_reference_text_14', sortable: true, filter: true, resizable: true, minWidth: 50}
      ];
    }
  }

  public quickSearch() : void {
    this.internalGridApi.setQuickFilter(this.searchValue);
    this.externalGridApi.setQuickFilter(this.searchValue);
  }

  public getTransactionCount() : void {
    let params = {
      "processingLayerId": this.selectedProcessingLayerId,
      "letterDate": this.letterDate
    };
    this.ngxService.start();
    this.operationService.getTransactionCountFromServer(params)
    .subscribe(
      receivedData => {
        let responseData = receivedData;
        console.log("Transaction Count Response ", responseData);
        this.barChartLabels = ["UnMatched", "Matched"];
        this.barChartData = [
          {
            data : [responseData["data"]["data"][0]["open_count"], responseData["data"]["data"][0]["matched_count"]]
          }
        ];
        this.colorOptions = [
          {
            backgroundColor: ['#547caf', '#acc3a6']
          }
        ];
        this.ngxService.stop();
      }
    ),
    (error : any) => {
      this.HandleErrorResponse(error);
      this.ngxService.stop();
    }
  }

  public onChartClick(event : any) : void {
    if (event.active.length > 0)
    {
      const chart = event.active[0]._chart;
      const activePoints = chart.getElementAtEvent(event.event);
      if ( activePoints.length > 0) 
      {
          // get the internal index of slice in pie chart
          const clickedElementIndex = activePoints[0]._index;
          const label = chart.data.labels[clickedElementIndex];
          // get value by index
          const value = chart.data.datasets[0].data[clickedElementIndex];
          // console.log(clickedElementIndex, label, value);
          console.log(label);
          this.chartTypeClicked = label;
          this.getTransactionRecords();
      }
    }
  }

  public getTransactionRecords() : void {
    if (this.chartTypeClicked == 'Matched')
    {
      this.bankTransfersGrid = false;
      this.displaySelectedUnMatchedGrid = false;
      this.selectedExternalRowData = undefined;
      this.selectedInternalRowData = undefined;
      this.externalRowData = undefined;
      this.internalRowData = undefined;
      this.paymentDateList = [];
      this.selectedUnMatchedExternalAmount = '';
      this.selectedUnMatchedInternalAmount = '';
    }
    else if (this.chartTypeClicked == 'UnMatched')
    {
      this.ngxService.start();
      this.bankTransfersGrid = true;
      let params = {
        "procesingLayerId": this.selectedProcessingLayerId,
        "status": this.chartTypeClicked,
        "letterDate": this.letterDate
      };

      this.operationService.getTransactionRecordsFromServer(params)
      .subscribe(
        receivedData => {
          let responseData = receivedData;
          console.log("Transaction Records Response ", responseData);
          this.externalRowData = responseData["data"]["bank"]["data"];
          this.internalRowData = responseData["data"]["alcs"]["data"];
          this.ngxService.stop();
        }
      ),
      (error: any) => {
        this.HandleErrorResponse(error);
      }
    }
  }

  public HandleErrorResponse(err: any)
  {
   console.log("Error",err);
  }

}
