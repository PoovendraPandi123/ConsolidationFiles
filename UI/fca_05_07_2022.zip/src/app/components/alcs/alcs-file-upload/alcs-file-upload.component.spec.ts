import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AlcsFileUploadComponent } from './alcs-file-upload.component';

describe('AlcsFileUploadComponent', () => {
  let component: AlcsFileUploadComponent;
  let fixture: ComponentFixture<AlcsFileUploadComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AlcsFileUploadComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AlcsFileUploadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
