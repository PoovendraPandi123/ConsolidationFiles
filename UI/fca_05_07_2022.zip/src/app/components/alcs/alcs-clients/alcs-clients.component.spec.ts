import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AlcsClientsComponent } from './alcs-clients.component';

describe('AlcsClientsComponent', () => {
  let component: AlcsClientsComponent;
  let fixture: ComponentFixture<AlcsClientsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AlcsClientsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AlcsClientsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
