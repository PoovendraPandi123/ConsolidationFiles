import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ConsolFilesProcessComponent } from './consol-files-process.component';

describe('ConsolFilesProcessComponent', () => {
  let component: ConsolFilesProcessComponent;
  let fixture: ComponentFixture<ConsolFilesProcessComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ConsolFilesProcessComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ConsolFilesProcessComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
