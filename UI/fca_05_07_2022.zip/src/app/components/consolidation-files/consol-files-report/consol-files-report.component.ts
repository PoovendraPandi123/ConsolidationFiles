import { Component, OnInit } from '@angular/core';
import { ConsolFilesReportService } from 'src/app/service/consol-files-report.service';
import { NgxUiLoaderService } from "ngx-ui-loader"; // Import NgxUiLoaderService

@Component({
  selector: 'app-consol-files-report',
  templateUrl: './consol-files-report.component.html',
  styleUrls: ['./consol-files-report.component.css']
})
export class ConsolFilesReportComponent implements OnInit {

  public reportTypeChosen: string;
  public targetList: any;
  public userModelList: any;
  public userDetails: any;
  public tenantId: number;
  public groupId: number;
  public entityId: number;
  public mProcessingLayerId: number;
  public mProcessingSubLayerId: number;
  public processingLayerId: number;
  public userId: any;
  public targetNameChosen: string;
  public gstMonthChosen: string;
  public pagination: boolean;
  public reportVisible: boolean;
  public paginationSize: number;
  public fileRowData: any;
  public fileColumnDefs: any;

  constructor(private reportService: ConsolFilesReportService, private ngxService: NgxUiLoaderService) {
    this.reportTypeChosen = '';
    this.targetList = [];
    this.userModelList = JSON.parse(sessionStorage.getItem('user_model_list'));
    this.userDetails = JSON.parse(sessionStorage.getItem('user_details'));
    this.userId = this.userDetails["user_id"];
    this.tenantId = this.userModelList["tenant_id"];
    this.groupId = this.userModelList["group_id"];
    this.entityId = this.userModelList["entity_id"];
    this.mProcessingLayerId = this.userModelList["m_processing_layer_id"];
    this.mProcessingSubLayerId = this.userModelList["m_processing_sub_layer_id"];
    this.processingLayerId = 1000;
    this.targetNameChosen = '';
    this.gstMonthChosen = '';
    this.pagination = false;
    this.reportVisible = false;
    this.paginationSize = null;
    this.fileRowData = [];
    this.fileColumnDefs = [];
   }

  public ngOnInit(): void {
    this.reportTypeChosen = '-1';
    this.targetNameChosen = '-1';
    this.getTargetList();
    this.pagination = true;
    this.paginationSize = 20;
  }

  public getTargetList() : void {
    this.ngxService.start();
    let data = {
      "tenants_id": this.tenantId,
      "groups_id": this.groupId,
      "entities_id": this.entityId,
      "m_processing_layer_id": this.mProcessingLayerId,
      "m_processing_sub_layer_id": this.mProcessingSubLayerId,
      "processing_layer_id": this.processingLayerId,
      "is_active": "yes"
    };

    this.reportService.getTragetListFromServer(data)
    .subscribe(
      (receivedData : any) => {
        let responseData = receivedData;
        console.log("Get Target List Response ", responseData);
        this.targetList = responseData;
        this.ngxService.stop();
      }
    ),
    (error : any) => {
      this.HanlerErrorResponse(error);
      this.ngxService.stop();
    }
  }

  public searchClick() : void {
    if (this.reportTypeChosen == '-1')
    {
      alert("Kindly Chooose Report Type!!!");
    }
    else if (this.targetNameChosen == '-1')
    {
      alert("Kindly Choose Target Name!!!");
    }
    else if(this.gstMonthChosen == '')
    {
      alert("Kindly Choose GST Remittance Month!!!");
    }
    else
    {
      this.ngxService.start();
      this.reportVisible = true;
      this.ngxService.stop();
    }
  }

  public onGridReady(event : any) : void {

  }

  public onRowClicked(e : any) : void {

  }

  public HanlerErrorResponse(err : any) : void {
    console.log(err);
  }

}
