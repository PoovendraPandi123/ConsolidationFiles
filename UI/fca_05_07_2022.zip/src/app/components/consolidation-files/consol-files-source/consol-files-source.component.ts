import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { Source } from './consol-files-source.model';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { Subject } from 'rxjs';
import { ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { NgxUiLoaderService } from "ngx-ui-loader"; // Import NgxUiLoaderService
import { ConsoleFilesSourceService } from 'src/app/service/console-files-source.service';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-consol-files-source',
  templateUrl: './consol-files-source.component.html',
  styleUrls: ['./consol-files-source.component.css']
})
export class ConsolFilesSourceComponent implements OnInit {

  @ViewChild('content') content : ElementRef;
  @ViewChild('editSourceContent') editSourceContent : ElementRef;

  public objsource: Source;
  public listButton: boolean = true;
  public createButton: boolean = false;
  public sourceName: boolean = true;
  public sourceType: boolean = true;
  public fileType: boolean = false;
  public textSeparator: boolean = false;
  public otherSeparator: boolean = false;
  public filePasswordRequired: boolean = false;
  public filePassword: boolean = false;
  public sheetNameRequired: boolean = false;
  public sheetName: boolean = false;
  public sheetPasswordRequired: boolean = false;
  public sheetPassword: boolean = false;
  public columnStartRow: boolean = true;
  public database: boolean = false;
  public dbUserName: boolean = false;
  public dbPassword: boolean = false;
  public dbHost: boolean = false;
  public dbPort: boolean = false;
  public schema: boolean = false;
  public table: boolean = false;
  public psqlDatabase: boolean = false;
  public importSequence: boolean = true;
  public keywords: boolean = true;
  public pagination: boolean = true;
  public paginationSize: number = 15;
  public externalRowData: any;
  public externalColumnDefs: any;
  public schemaList: any;
  public tableList: any;
  public userModelList: any;
  public userDetails: any;
  public tenantId: number;
  public groupId: number;
  public entityId: number;
  public mProcessingLayerId: number;
  public mProcessingSubLayerId: number;
  public processingLayerId: number;
  public userId: any;
  public psqlDatabaseList: any;
  public actionType: string;
  public clickedData : any;
  public createSourceEnable : boolean = false;
  public listSourceEnable : boolean = false;
  public closeResult: any;
  public sourceNameClicked: string;
  public sourceNameEdit: string;
  public sourceColumnStartRowEdit: string;
  public sourceKeyWordsEdit: string;

  dtOptions: DataTables.Settings = {};
  dtTrigger: Subject<any> = new Subject<any>();

  constructor(public ngxService: NgxUiLoaderService, private dialog: MatDialog, private sourceService: ConsoleFilesSourceService, private router: Router, private http: HttpClient, private modalService: NgbModal) { 
    this.sourceNameClicked = '';
    this.sourceNameEdit = '';
    this.sourceColumnStartRowEdit = '';
    this.sourceKeyWordsEdit = '';
  }

  public ngOnInit(): void {
    this.listSourceEnable = true;
    this.objsource = new Source();
    this.userModelList = JSON.parse(sessionStorage.getItem('user_model_list'));
    this.userDetails = JSON.parse(sessionStorage.getItem('user_details'));
    this.userId = this.userDetails["user_id"];
    this.tenantId = this.userModelList["tenant_id"];
    this.groupId = this.userModelList["group_id"];
    this.entityId = this.userModelList["entity_id"];
    this.mProcessingLayerId = this.userModelList["m_processing_layer_id"];
    this.mProcessingSubLayerId = this.userModelList["m_processing_sub_layer_id"];
    this.processingLayerId = 1000;
    this.objsource.sourceType = '0';
    this.objsource.fileType = '0';
    this.objsource.filePasswordRequired = '0';
    this.objsource.sheetNameRequired = '0';
    this.objsource.sheetPasswordRequired = '0';
    this.objsource.database = '0';
    this.objsource.textSeparator = '0';
    this.setColumnDefs();
    this.getSourceList();
  }

  public ngOnDestroy(): void {
    this.dtTrigger.unsubscribe();
  }

  public getSourceType(sourceType : any) : void {
    if (sourceType === "file")
    {
      this.fileType = true;
      this.columnStartRow = true;
      this.textSeparator = false;
      this.otherSeparator = false;
      this.filePasswordRequired = false;
      this.filePassword = false;
      this.sheetNameRequired = false;
      this.sheetName = false;
      this.sheetPasswordRequired = false;
      this.sheetPassword = false;
      this.database = false;
      this.dbUserName = false;
      this.dbPassword = false;
      this.dbHost = false;
      this.dbPort = false;
      this.schema = false;
      this.table = false;
      this.psqlDatabase = false;

      this.objsource.textSeparator = '';
      this.objsource.otherSeparator = '';
      this.objsource.filePasswordRequired = '';
      this.objsource.filePassword = '';
      this.objsource.sheetNameRequired = '';
      this.objsource.sheetName = '';
      this.objsource.sheetPasswordRequired = '';
      this.objsource.sheetPassword = '';
      this.objsource.database = '';
      this.objsource.dbUserName = '';
      this.objsource.dbPassword = '';
      this.objsource.dbHost = '';
      this.objsource.dbPort = '';
      this.objsource.schema = '';
      this.objsource.table = '';
      this.objsource.psqlDatabase = '';
    }
    else if (sourceType === "db")
    {
      this.fileType = false;
      this.columnStartRow = false;
      this.textSeparator = false;
      this.otherSeparator = false;
      this.filePasswordRequired = false;
      this.filePassword = false;
      this.sheetNameRequired = false;
      this.sheetName = false;
      this.sheetPasswordRequired = false;
      this.sheetPassword = false;
      this.database = true;
      this.dbUserName = true;
      this.dbPassword = true;
      this.dbHost = true;
      this.dbPort = true;
      this.schema = true;
      this.table = true;

      this.objsource.fileType = '';
      this.objsource.columnStartRow = '';
      this.objsource.textSeparator = '';
      this.objsource.otherSeparator = '';
      this.objsource.filePasswordRequired = '';
      this.objsource.filePassword = '';
      this.objsource.sheetNameRequired = '';
      this.objsource.sheetName = '';
      this.objsource.sheetPasswordRequired = '';
      this.objsource.sheetPassword = '';
    }
    else
    {
      this.fileType = false;
      this.textSeparator = false;
      this.otherSeparator = false;
      this.filePasswordRequired = false;
      this.filePassword = false;
      this.sheetNameRequired = false;
      this.sheetName = false;
      this.sheetPasswordRequired = false;
      this.sheetPassword = false;
      this.database = false;
      this.dbUserName = false;
      this.dbPassword = false;
      this.dbHost = false;
      this.dbPort = false;
      this.schema = false;
      this.table = false;
      this.psqlDatabase = false;

      this.objsource.fileType = '';
      this.objsource.textSeparator = '';
      this.objsource.otherSeparator = '';
      this.objsource.filePasswordRequired = '';
      this.objsource.filePassword = '';
      this.objsource.sheetNameRequired = '';
      this.objsource.sheetName = '';
      this.objsource.sheetPasswordRequired = '';
      this.objsource.sheetPassword = '';
      this.objsource.database = '';
      this.objsource.dbUserName = '';
      this.objsource.dbPassword = '';
      this.objsource.dbHost = '';
      this.objsource.dbPort = '';
      this.objsource.schema = '';
      this.objsource.table = '';
      this.objsource.psqlDatabase = '';
    }
  }

  public getFileType(fileType : any) : void {
    if (fileType === "excel")
    {
      this.filePasswordRequired = true;
      this.sheetNameRequired = true;
      this.otherSeparator = false;
      this.textSeparator = false;

      this.objsource.otherSeparator = '';
      this.objsource.textSeparator = '';
    }
    else if (fileType === "text")
    {
      this.textSeparator = true;
      this.filePasswordRequired = false;
      this.sheetNameRequired = false;
      this.filePassword = false;
      this.sheetName = false;
      this.sheetPasswordRequired = false;
      this.sheetPassword = false;

      this.objsource.filePasswordRequired = '';
      this.objsource.sheetNameRequired = '';
      this.objsource.filePassword = '';
      this.objsource.sheetName = '';
      this.objsource.sheetPasswordRequired = '';
      this.objsource.sheetPassword = '';
    }
    else
    {
      this.textSeparator = false;
      this.filePasswordRequired = false;
      this.sheetNameRequired = false;
      this.filePassword = false;
      this.sheetName = false;
      this.sheetPasswordRequired = false;
      this.sheetPassword = false;
      this.otherSeparator = false;

      this.objsource.textSeparator = '';
      this.objsource.filePasswordRequired = '';
      this.objsource.sheetNameRequired = '';
      this.objsource.filePassword = '';
      this.objsource.sheetName = '';
      this.objsource.sheetPasswordRequired = '';
      this.objsource.sheetPassword = '';
      this.objsource.otherSeparator = '';
    }
  }

  public getFilePasswordRequired(filePasswordRequired : string) : void {
    if (filePasswordRequired === "yes")
    {
      this.filePassword = true;
    }
    else
    {
      this.filePassword = false;
      this.objsource.filePassword = '';
    }
  }

  public getSheetNameRequired(sheetNameRequired : string) : void {
    if (sheetNameRequired === "yes")
    {
      this.sheetName = true;
      this.sheetPasswordRequired = true;
    }
    else
    {
      this.sheetName = false;
      this.sheetPasswordRequired = false;
      this.sheetPassword = false;

      this.objsource.sheetName = '';
      this.objsource.sheetPasswordRequired = '';
      this.objsource.sheetPassword = '';
    }
  }

  public getSheetPasswordRequired(sheetPasswordRequired : string) : void {
    if (sheetPasswordRequired === "yes")
    {
      this.sheetPassword = true;
    }
    else
    {
      this.sheetPassword = false;

      this.objsource.sheetPassword = '';
    }
  }

  public getTextSeparator(textSeparator : string) : void {
    if (textSeparator === "others")
    {
      this.otherSeparator = true;
    }
    else
    {
      this.otherSeparator = false;

      this.objsource.otherSeparator = '';
    }
  }

  public getDatabase(database : string) : void {
    if (database === "postgres")
    {
      this.psqlDatabase = true;
    }
    else
    {
      this.psqlDatabase = false;

      this.objsource.psqlDatabase = '';
    }
  }

  public getpsqlDatabase(psqlDatabase : string) : void {
    // this.objsource.psqlDatabase = psqlDatabase;
    if (psqlDatabase === "select")
    {
      this.psqlDatabaseList = [
        {"result" : ""}
      ];
      this.schemaList = [
        {"result" : ""}
      ];
      this.tableList = [
        {"result" : ""}
      ];
      if (this.objsource.dbPort === "" || this.objsource.database === "" || this.objsource.dbHost === "" || this.objsource.dbUserName === "" || this.objsource.dbPassword === "")
      {
        alert("Kindly Fill Database, Port, UserName, Password and Host to choose the Schema!!!");
      }
      else
      {
        this.ngxService.start();
        
        let data = {
          "database": this.objsource.database,
          "host": this.objsource.dbHost,
          "port": this.objsource.dbPort,
          "username": this.objsource.dbUserName,
          "password": this.objsource.dbPassword,
          "type": "database"
        };

      //   this.objservice.getDatabaseValuesFromServer(data)
      //   .subscribe(
      //     receivedData => {
      //       let responseData = receivedData;
      //       if (responseData["Status"] === "Error")
      //       {
      //         alert(responseData["Message"]);
      //         this.ngxService.stop();
      //       }
      //       else if (responseData["Status"] === "Success")
      //       {
      //         // console.log(responseData);
      //         let data = responseData["data"];
      //         this.psqlDatabaseList = data;
      //         this.ngxService.stop();
      //       }
      //     }, 
      //     (error:any) => {
      //       this.HandleErrorResponse(error);
      //       this.ngxService.stop();
      //     }
      //   )
      }
    }
  }

  public getSchema(schema : string) : void {
    if (schema === "select")
    {
      this.schemaList = [
        {"result" : ""}
      ];
      this.tableList = [
        {"result" : ""}
      ];
      if (this.objsource.dbPort === "" || this.objsource.database === "" || this.objsource.dbHost === "" || this.objsource.dbUserName === "" || this.objsource.dbPassword === "")
      {
        alert("Kindly Fill Database, Port, UserName, Password and Host to choose the Schema!!!");
      }
      else
      {
        this.ngxService.start();

        let data = {
          "database": this.objsource.database,
          "host": this.objsource.dbHost,
          "port": this.objsource.dbPort,
          "username": this.objsource.dbUserName,
          "password": this.objsource.dbPassword,
          "type": "schema",
          "psqlDatabase": this.objsource.psqlDatabase
        };

        // this.objservice.getDatabaseValuesFromServer(data)
        // .subscribe(
        //   receivedData => {
        //     let responseData = receivedData;
        //     if (responseData["Status"] === "Error")
        //     {
        //       alert(responseData["Message"]);
        //       this.ngxService.stop();
        //     }
        //     else if (responseData["Status"] === "Success")
        //     {
        //       // console.log(responseData);
        //       let data = responseData["data"];
        //       this.schemaList = data;
        //       this.ngxService.stop();
        //     }
        //   },
        //   (error:any) => {
        //     this.HandleErrorResponse(error);
        //     this.ngxService.stop();
        //   }
        // )
      }
    }
  }

  public getTable(table : string) : void {
    if (table === "select")
    {
      this.tableList = [
        {"result" : ""}
      ];
      if (this.objsource.schema === "" || this.objsource.schema === "select")
      {
        alert("Kindly choose Schema!!!");
      }
      else
      {
        this.ngxService.start();

        let data = {
          "database": this.objsource.database,
          "host": this.objsource.dbHost,
          "port": this.objsource.dbPort,
          "username": this.objsource.dbUserName,
          "password": this.objsource.dbPassword,
          "type": "table",
          "schema": this.objsource.schema,
          "psqlDatabase": this.objsource.psqlDatabase
        }

        // this.objservice.getDatabaseValuesFromServer(data)
        // .subscribe(
        //   receivedData => {
        //     let responseData = receivedData;
        //     if (responseData["Status"] === "Error")
        //     {
        //       alert(responseData["Message"]);
        //       this.ngxService.stop();
        //     }
        //     else if (responseData["Status"] === "Success")
        //     {
        //       // console.log(responseData);
        //       let data = responseData["data"];
        //       this.tableList = data;
        //       this.ngxService.stop();
        //     }
        //   },
        //   (error:any) => {
        //     this.HandleErrorResponse(error);
        //     this.ngxService.stop();
        //   }
        // )
      }
    }
  }

  public onSaveButtonClick() : void {

    if (this.objsource.sourceName === '')
    {
      alert("Source Name should not be Empty!!!");
    }
    else if (this.objsource.sourceType == "0")
    {
      alert("Please Choose Source Type!!!");
    }
    else if (this.objsource.sourceType == "file" && this.objsource.fileType == "0")
    {
      alert("Please Choose File Type!!!");
    }
    else if (this.objsource.fileType == "excel" && this.objsource.filePasswordRequired == "0")
    {
      alert("Please Choose Excel File has a Password or not!!!");
    }
    else if (this.objsource.fileType == "excel" && this.objsource.sheetNameRequired == "0")
    {
      alert("Please Choose Whether Sheet Name is Necessary or not!!!");
    }
    else if (this.objsource.filePasswordRequired == "yes" && this.objsource.filePassword == "0")
    {
      alert("Please Enter the File Password!!!");
    }
    else if (this.objsource.sheetNameRequired == "yes" && this.objsource.sheetName === "")
    {
      alert("Please Enter the Sheet Name!!!");
    }
    else if (this.objsource.sheetNameRequired == "yes" && this.objsource.sheetPasswordRequired == "0")
    {
      alert("Please Choose the Sheet has a Password or not!!!");
    }
    else if (this.objsource.sheetPasswordRequired == "yes" && this.objsource.sheetPassword == "0")
    {
      alert("Please Enter the Sheet Password!!!");
    }
    else if (this.objsource.fileType == "text" && this.objsource.textSeparator == "0")
    {
      alert("Please Choose the Text Separator!!!");
    }
    else if (this.objsource.textSeparator == "others" && this.objsource.otherSeparator === "")
    {
      alert("Please Enter the Other Separator!!!");
    }
    else if (this.objsource.sourceType == "db" && this.objsource.database == "0")
    {
      alert("Please Choose the Type of Database!!!");
    }
    else if (this.objsource.sourceType == "db" && this.objsource.dbUserName === "")
    {
      alert("Please Enter the Database User Name!!!");
    }
    else if (this.objsource.sourceType == "db" && this.objsource.dbPassword === "")
    {
      alert("Please Enter the Database Password!!!");
    }
    else if (this.objsource.sourceType == "db" && this.objsource.dbHost === "")
    {
      alert("Please Enter the Host IP Address!!!");
    }
    else if (this.objsource.sourceType == "db" && this.objsource.dbHost === "")
    {
      alert("Please Enter the Database Port Number!!!");
    }
    else if (this.objsource.sourceType == "db" && (this.objsource.schema === "" || this.objsource.schema == "select"))
    {
      alert("Please Choose the Schema Name!!!");
    }
    else if (this.objsource.sourceType == "db" && (this.objsource.table === "" || this.objsource.table == "select"))
    {
      alert("Please Choose the Database Table!!!");
    }
    else if (this.objsource.database == "postgres" && (this.objsource.psqlDatabase === "" || this.objsource.psqlDatabase == "select"))
    {
      alert("Please Choose the PSQL Database!!!");
    }
    else if (this.objsource.keywords == "")
    {
      alert("Please Enter the Keywords!!!");
    }
    else if (this.objsource.keywords != "" && this.getCheckSpecialCharacters(this.objsource.keywords))
    {
      alert("Please use keywords without spaces and separator as ',' only!!!");
    }
    else
    {
      this.ngxService.start();

      let sourceName = this.objsource.sourceName;
      let re = / /gi;
      let sourceNameReplaced = sourceName.replace(re, "_").toUpperCase();

      let data = {
        "tenants_id": this.tenantId,
        "groups_id": this.groupId,
        "entities_id": this.entityId,
        "m_processing_layer_id": this.mProcessingLayerId,
        "m_processing_sub_layer_id": this.mProcessingSubLayerId,
        "processing_layer_id": this.processingLayerId,
        "source_code": "{bk_update}",
        "source_name": sourceNameReplaced,
        "source_config": {
          "table": this.objsource.table,
          "schema": this.objsource.schema,
          "db_host": this.objsource.dbHost,
          "db_port": this.objsource.dbPort,
          "database": this.objsource.database,
          "file_type": this.objsource.fileType,
          "sheet_name": this.objsource.sheetName,
          "db_password": this.objsource.dbPassword,
          "source_type": this.objsource.sourceType,
          "db_user_name": this.objsource.dbUserName,
          "file_password": this.objsource.filePassword,
          "psql_database": this.objsource.psqlDatabase,
          "sheet_password": this.objsource.sheetPassword,
          "text_separator": this.objsource.textSeparator,
          "other_separator": this.objsource.otherSeparator,
          "column_start_row": this.objsource.columnStartRow,
          "sheet_name_required": this.objsource.sheetNameRequired,
          "file_password_required": this.objsource.filePasswordRequired,
          "sheet_password_required": this.objsource.sheetPasswordRequired
        },
        "source_input_location": "{bk_update}",
        "source_import_seq": this.objsource.importSequence,
        "source_field_number": null,
        "key_words": {"keywords": this.objsource.keywords},
        "is_active": true,
        "created_by": this.userId,
        "created_date": "{bk_update}",
        "modified_by": this.userId,
        "modified_date": "{bk_update}",
        "source_definitions": []
    }
    // console.log("Post Source To Server Input Params ", data);
    this.sourceService.postSourceToServer(data)
    .subscribe(
      (receivedData : any) => {
        let responseData = receivedData;
        // console.log("Post Sourece to Server Data Response ", responseData);
        if ("id" in responseData)
        {
          alert("Source Created Successfully!!!");
          window.location.reload();
        }
        else
        {
          alert("Error in Creating Source. Please Contact Advents Support!!!");
        };
        this.ngxService.stop();
      },
      (error : any) => {
        let responseError = error;
        this.HandleErrorResponse(responseError);
        // let err = responseError["error"];
        // console.log("err", err);
        // if ("source_name" in err)
        // {
        //   alert(err["source_name"]);
        // }
        // else if (err["Status"] == "Error")
        // {
        //   alert(err["Message"]);
        // }
        alert("Error in Creating Source. Please Contact Advents Support!!!");
        this.ngxService.stop();
      }
    );
    // console.log("Post Sourece to Server Data Response ", responseData);


    // this.http.post('http://localhost:50012/api/v1/consol_files/source/', data).subscribe(
    //   data => {
    //     console.log(data);
    //   },
    //   error => {
    //     console.log("Error", error);
    //   }
    // );

    // this.sourceService.postSourceToServer(data)
    // .subscribe(
    //     receivedData => {
    //       let responseData = receivedData;
    //       console.log("Post Source To Server Response ", responseData);
    //       this.ngxService.stop();
        //   if ("id" in responseData)
        //   {
        //     alert("Source Created Successfully!!!");
        //     window.location.reload();
        //   }
        //   else if("source_name" in responseData)
        //   {
        //     alert("Same Source Already Exists!!!");
        //   }
        //   else
        //   {
        //     alert("Error in Creating Source. Please Contact Advents Support!!!");
        //   }
        //   this.ngxService.stop();
        // },
        // (error:any) => {
        //   this.HandleErrorResponse(error);
        //   this.ngxService.stop();
        // }
      // );
    }

  }

  public getCheckSpecialCharacters(inputText: string) : boolean {
    var format = /[ `!@#$%^&*()_+\-=\[\]{};':"\\|.<>\/?~]/;
    if (format.test(inputText))
    {
      return true;
    }
    else
    {
      return false;
    }
  }

  public getSourceList() : void {

    this.ngxService.start();

    this.listButton = true;
    this.createButton = false;
    this.createSourceEnable = false;
    this.listSourceEnable = true;

    let params = {
      "tenants_id": this.tenantId,
      "groups_id": this.groupId,
      "entities_id": this.entityId,
      "m_processing_layer_id": this.mProcessingLayerId,
      "m_processing_sub_layer_id": this.mProcessingSubLayerId,
      "processing_layer_id": this.processingLayerId
    };
    this.sourceService.getActiveSourceListFromServer(params)
    .subscribe(
      (receivedData : any) => {
        let responseData = receivedData;
        console.log("Get Source List Response ", responseData);

        let externalRowData = [];

        for (var i=0; i<responseData.length; i++) 
        {
          let sourceConfig = responseData[i]["source_config"];
          let columnDefsData = {
            "source_name": responseData[i]["source_name"],
            "source_import_seq": responseData[i]["source_import_seq"],
            "file_type": sourceConfig["file_type"],
            "column_start_row": sourceConfig["column_start_row"],
            // "keywords": sourceConfig[""],
            "id": responseData[i]["id"]
          };
          columnDefsData["keywords"] = this.getKeywordsSource(responseData[i]["key_words"]);
          externalRowData.push(columnDefsData);
        }
        // console.log("External Row Data", externalRowData);
        this.externalRowData = externalRowData;

        this.ngxService.stop();
      }
    ),
    (error : any) => {
      this.HandleErrorResponse(error);
      this.ngxService.stop();
    }
  }

  public getKeywordsSource(inputArray : any) : string {
    console.log("Array", inputArray);
    let keywordArray = inputArray["keywords"];
    let resultString = '';
    for (let i = 0; i < keywordArray.length; i++)
    {
      resultString = resultString + "," + keywordArray[i];
    }
    return resultString.replace(",", "");
  }

  public getCreateSource() : void {
    this.listButton = false;
    this.createButton = true;
    this.createSourceEnable = true;
    this.listSourceEnable = false;
  }

  public onGridReady(event : any) : void {

  };

  public setColumnDefs() : void {
    this.externalColumnDefs = [
      {
        headerName: 'Action',
        width: 80,
        template:
        `
        <a>
          <i class='far fa-edit' data-action-type="Edit" title="Edit" aria-hidden="true"></i>
        </a>
        <a style="margin-left:3px;">
          <i class='fas fa-trash-alt' data-action-type="Delete" title="Delete" style="color:red"></i>
        </a>
        <a style="margin-left:3px;">
          <i class='fa fa-angle-double-right' data-action-type="Next" title="Source Definitions" aria-hidden="true"></i>
        </a>
        `
      },
      {headerName: 'Source Name', field: 'source_name', sortable: true, filter: true, resizable: true, width: 300},
      {headerName: 'File Type', field: 'file_type', sortable: true, filter: true, resizable: true},
      {headerName: 'Column Start Row', field: 'column_start_row', sortable: true, filter: true, resizable: true},
      {headerName: 'Key Words', field: 'keywords', sortable: true, filter: true, resizable: true, width: 400},
    ]
  }

  public onRowClicked(e : any) : void {
    if (e.event.target !== undefined) {
      let data = e.data;
      let actionType = e.event.target.getAttribute("data-action-type");
      this.actionType = actionType;
      this.clickedData = data;
      switch (actionType) {
        case 'Edit':
          return this.editSourcePopup();
        case 'Next':
          return this.sourceDefinitions();
        case 'Delete':
          return this.deleteSourcePopup();
      }
    }
  };

  public sourceDefinitions() : void {
    // console.log("clicked Data", this.clickedData);
    this.router.navigate(['/SideMenu/ConsolidationSourceDefinition'], {
      queryParams : this.clickedData
    });
  }

  public open(content) {
    this.modalService.open(content, {ariaLabelledBy: 'modal-basic-title'}).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }

  public editSourcePopup() : void {
    // console.log(this.clickedData);
    this.sourceNameEdit = this.clickedData["source_name"];
    this.sourceColumnStartRowEdit = this.clickedData["column_start_row"];
    this.sourceKeyWordsEdit = this.clickedData["keywords"];
    this.open(this.editSourceContent);
  }

  public editSource() : void {
    if (this.sourceKeyWordsEdit == "")
    {
      alert("Keywords Column Should Not be Empty!!!");
    }
    else if (this.sourceKeyWordsEdit != "" && this.getCheckSpecialCharacters(this.sourceKeyWordsEdit))
    {
      alert("Please use keywords without spaces and separator as ',' only!!!");
    }
    else
    {
      this.ngxService.start();
      let params = {
        "sources_id": this.clickedData["id"],
        "table_start_row": this.sourceColumnStartRowEdit,
        "keywords": this.sourceKeyWordsEdit
      };

      this.sourceService.getEditSourceToSeerver(params)
      .subscribe(
        (receivedData : any) => {
          let responseData = receivedData;
          console.log("Edit Source Response ", responseData);
          if (responseData["Status"] == "Success")
          {
            alert("Source Values Updated Successfully!!!");
            this.getSourceList();
            this.ngxService.stop();
          }
          else if (responseData["Status"] == "Not Unique")
          {
            alert("Keyword already Exists!!!");
            this.ngxService.stop();
          }
          else if (responseData["Status"] == "Error")
          {
            alert("Error in Updating Source. Kindly contact Advents Support!!!");
            this.ngxService.stop();
          }
        }
      ),
      (error : any) => {
        this.HandleErrorResponse(error);
        this.ngxService.stop();
      }
    }
  }

  public deleteSourcePopup() : void {
    // console.log(this.clickedData);
    this.sourceNameClicked = this.clickedData["source_name"];
    this.open(this.content);
  }

  public deleteSource() : void {
    this.ngxService.start();
    let data = {
      "id": this.clickedData["id"],
      "is_active": 0
    };
    this.sourceService.getDeleteSourceToServer(data)
    .subscribe(
      (receivedData : any) => {
        let responseData = receivedData;
        // console.log("Delete Source Response ", responseData);
        this.getSourceList();
        this.ngxService.stop();
      }
    ),
    (error : any) => {
      let responseError = error;
      this.HandleErrorResponse(responseError);
      let err = responseError["error"];
      // console.log("Delete Source Error Response ", err);
      this.ngxService.stop();
    }
  }

  public onClearButtonClick() : void {
    this.objsource.sourceName = '';
    this.objsource.sourceType = '';
  }

  public HandleErrorResponse(err: any)
  {
   console.log("Error",err);
  }

}
