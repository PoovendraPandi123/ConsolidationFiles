export interface ITargetDefinitionMapping {
    sourceId: String,
    sourceDefinitionId: String
}