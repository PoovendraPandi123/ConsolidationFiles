import { TestBed } from '@angular/core/testing';

import { BrsLandingPageService } from './brs-landing-page.service';

describe('BrsLandingPageService', () => {
  let service: BrsLandingPageService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(BrsLandingPageService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
