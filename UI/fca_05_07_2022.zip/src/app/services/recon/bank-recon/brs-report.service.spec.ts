import { TestBed } from '@angular/core/testing';

import { BrsReportService } from './brs-report.service';

describe('BrsReportService', () => {
  let service: BrsReportService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(BrsReportService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
