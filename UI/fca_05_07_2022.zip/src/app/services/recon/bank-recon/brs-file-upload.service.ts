import { Injectable } from '@angular/core';
import { CommonService } from 'src/app/service/common.service';

@Injectable({
  providedIn: 'root'
})
export class BrsFileUploadService {

  public sourcePort = "50003";
  public reconPort = "5004";

  constructor(private CS: CommonService) { }

  public getProcessingLayerListFromServer(prminputs) : any {
    var resData = CommonService.authReq(this.sourcePort+'/source/get_processing_layer_list/');
    return this.CS.SendToAPI("post", resData, prminputs);
  }

  public getFileListFromServer(prminputs) : any {
    var resData = CommonService.authReq(this.reconPort+'/api/v1/bank_recon/file_uploads/');
    return this.CS.SendToAPI("get", resData, prminputs);
  }

  public postFileToServer(prminputs) : any {
    var resData = CommonService.authReq(this.reconPort+'/api/v1/bank_recon/get_file_upload/');
    return this.CS.SendFileToAPI("post", resData, prminputs);
  }
}
