import { TestBed } from '@angular/core/testing';

import { VrReconReportService } from './vr-recon-report.service';

describe('VrReconReportService', () => {
  let service: VrReconReportService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(VrReconReportService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
