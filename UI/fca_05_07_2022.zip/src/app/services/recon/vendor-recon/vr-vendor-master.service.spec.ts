import { TestBed } from '@angular/core/testing';

import { VrVendorMasterService } from './vr-vendor-master.service';

describe('VrVendorMasterService', () => {
  let service: VrVendorMasterService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(VrVendorMasterService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
