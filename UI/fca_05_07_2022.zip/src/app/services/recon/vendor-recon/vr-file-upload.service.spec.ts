import { TestBed } from '@angular/core/testing';

import { VrFileUploadService } from './vr-file-upload.service';

describe('VrFileUploadService', () => {
  let service: VrFileUploadService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(VrFileUploadService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
