import { TestBed } from '@angular/core/testing';

import { VrMatchingCommentsService } from './vr-matching-comments.service';

describe('VrMatchingCommentsService', () => {
  let service: VrMatchingCommentsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(VrMatchingCommentsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
