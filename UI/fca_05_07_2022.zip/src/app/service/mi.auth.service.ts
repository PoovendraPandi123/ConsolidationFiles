import { Injectable } from '@angular/core';
// import { Http, Response } from '@angular/http';
import { HttpClient,HttpHeaders  } from '@angular/common/http';
import { CommonService } from './common.service';
// import { Util } from './Util';
import { RouteConfigLoadStart, Router } from '@angular/router';
@Injectable({
  providedIn: 'root'
})
export class AuthService{
  lstReturn: any;
  public modulePort = "50001";
  public reconPort = "50008";
  public reconEtlPort = "50009";
  public sourcePort = "50003";
  constructor(private httpClient: HttpClient, private router: Router, 
    // private Util: Util, 
    private CS: CommonService) {
  }

  getLoginstatusFromServer(prminputs) {
    console.log("prminputs",prminputs);
    var resData = CommonService.authReq(this.modulePort+'/modules/login/');
    return this.CS.SendToAPI("post", resData, prminputs);
  }

  getModuleListFromServer(prminputs) {
    var resData = CommonService.authReq(this.modulePort+'/modules/user_rights/');
    return this.CS.SendToAPI("post", resData, prminputs);
  }

  getModelListFromServer(prminputs) {
    var resData = CommonService.authReq(this.modulePort+'/modules/user_credentials/');
    return this.CS.SendToAPI("post", resData, prminputs);
  }

  getProcessingLayerListFromServer(prminputs){
    var resData = CommonService.authReq(this.sourcePort+'/source/get_processing_layer_list/');
    return this.CS.SendToAPI("post", resData, prminputs);
  }

  getMisDataFromServer(prminputs){
    var resData = CommonService.authReq(this.reconEtlPort+'/med_ins_recon_etl/get_mis_data/');
    return this.CS.SendToAPI("post", resData, prminputs);
  }

  getAdditionDataFromServer(prminputs){
    var resData = CommonService.authReq(this.reconEtlPort+'/med_ins_recon_etl/get_addition_data/');
    return this.CS.SendToAPI("post", resData, prminputs);
  }

  getDeletionDataFromServer(prminputs){
    var resData = CommonService.authReq(this.reconEtlPort+'/med_ins_recon_etl/get_deletion_data/');
    return this.CS.SendToAPI("post", resData, prminputs);
  }

  getExceptionDataFromServer(prminputs){
    var resData = CommonService.authReq(this.reconEtlPort+'/med_ins_recon_etl/get_exception_data/');
    return this.CS.SendToAPI("post", resData, prminputs);
  }

  getMiDashboardDataFromServer(prminputs){
    var resData = CommonService.authReq(this.reconEtlPort+'/med_ins_recon_etl/get_dashboard_values/');
    return this.CS.SendToAPI("post", resData, prminputs);
  }

  getActiveInactiveValuesFromServer(prminputs){
    var resData = CommonService.authReq(this.reconEtlPort+'/med_ins_recon_etl/get_act_inact_values/');
    return this.CS.SendToAPI("post", resData, prminputs);
  }

  getClientValuesFromServer(prminputs){
    var resData = CommonService.authReq(this.reconEtlPort+'/med_ins_recon_etl/get_client_values/');
    return this.CS.SendToAPI("post", resData, prminputs);
  }

  getInsurerListFromServer(prminputs){
    var resData = CommonService.authReq(this.reconEtlPort+'/med_ins_recon_etl/get_master_insurer_records/');
    return this.CS.SendToAPI("post", resData, prminputs);
  }

  getPolicyListFromServer(prminputs){
    var resData = CommonService.authReq(this.reconEtlPort+'/med_ins_recon_etl/get_master_policy_type/');
    return this.CS.SendToAPI("post", resData, prminputs);
  }

  getClientListFromServer(prminputs){
    var resData = CommonService.authReq(this.reconEtlPort+'/med_ins_recon_etl/get_client_details/');
    return this.CS.SendToAPI("post", resData, prminputs);
  }

  getMasterDetailsFromServer(prminputs){
    var resData = CommonService.authReq(this.reconEtlPort+'/med_ins_recon_etl/get_insurer_details/');
    return this.CS.SendToAPI("post", resData, prminputs);
  }

  getClientDetailsListFromServer(prminputs){
    var resData = CommonService.authReq(this.reconEtlPort+'/med_ins_recon_etl/get_client_details_list/');
    return this.CS.SendToAPI("post", resData, prminputs);
  }

  getMailIdListFromServer(prminputs){
    var resData = CommonService.authReq(this.reconEtlPort+'/med_ins_recon_etl/get_mail_id_list/');
    return this.CS.SendToAPI("post", resData, prminputs);
  }

  postInsurerNameToServer(prminputs){
    var resData = CommonService.authReq(this.reconEtlPort+'/med_ins_recon_etl/get_add_insurer/');
    return this.CS.SendToAPI("post", resData, prminputs);
  }

  updateInsurerNameToServer(prminputs){
    var resData = CommonService.authReq(this.reconEtlPort+'/med_ins_recon_etl/get_edit_insurer/');
    return this.CS.SendToAPI("post", resData, prminputs);
  }

  postClientDetailsToServer(prminputs){
    var resData = CommonService.authReq(this.reconEtlPort+'/med_ins_recon_etl/get_add_client_details/');
    return this.CS.SendToAPI("post", resData, prminputs);
  }

  updateClientDetailsToServer(prminputs){
    var resData = CommonService.authReq(this.reconEtlPort+'/med_ins_recon_etl/get_edit_client_details/');
    return this.CS.SendToAPI("post", resData, prminputs);
  }

  postMailAddressToServer(prminputs){
    var resData = CommonService.authReq(this.reconEtlPort+'/med_ins_recon_etl/get_add_mail_address/');
    return this.CS.SendToAPI("post", resData, prminputs);
  }

  updateMailAddressToServer(prminputs){
    var resData = CommonService.authReq(this.reconEtlPort+'/med_ins_recon_etl/get_edit_email_address/');
    return this.CS.SendToAPI("post", resData, prminputs);
  }

}
