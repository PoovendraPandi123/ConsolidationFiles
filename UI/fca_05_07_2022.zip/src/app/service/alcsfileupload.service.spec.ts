import { TestBed } from '@angular/core/testing';

import { AlcsfileuploadService } from './alcsfileupload.service';

describe('AlcsfileuploadService', () => {
  let service: AlcsfileuploadService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AlcsfileuploadService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
