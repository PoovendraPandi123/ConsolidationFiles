import { TestBed } from '@angular/core/testing';

import { ConsolFilesReportService } from './consol-files-report.service';

describe('ConsolFilesReportService', () => {
  let service: ConsolFilesReportService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ConsolFilesReportService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
