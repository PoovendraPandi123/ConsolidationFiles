import { TestBed } from '@angular/core/testing';

import { ConsolFilesTargetMappingService } from './consol-files-target-mapping.service';

describe('ConsolFilesTargetMappingService', () => {
  let service: ConsolFilesTargetMappingService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ConsolFilesTargetMappingService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
