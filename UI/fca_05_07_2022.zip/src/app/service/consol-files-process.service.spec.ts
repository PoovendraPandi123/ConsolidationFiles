import { TestBed } from '@angular/core/testing';

import { ConsolFilesProcessService } from './consol-files-process.service';

describe('ConsolFilesProcessService', () => {
  let service: ConsolFilesProcessService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ConsolFilesProcessService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
