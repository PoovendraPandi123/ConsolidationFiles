import { TestBed } from '@angular/core/testing';

import { BusinesslogiclayerdefinitionService } from './businesslogiclayerdefinition.service';

describe('BusinesslogiclayerdefinitionService', () => {
  let service: BusinesslogiclayerdefinitionService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(BusinesslogiclayerdefinitionService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
