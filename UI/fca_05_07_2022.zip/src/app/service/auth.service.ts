import { Injectable } from '@angular/core';
// import { Http, Response } from '@angular/http';
import { HttpClient,HttpHeaders  } from '@angular/common/http';
import { CommonService } from './common.service';
// import { Util } from './Util';
import { RouteConfigLoadStart, Router } from '@angular/router';
@Injectable({
  providedIn: 'root'
})
export class AuthService{
  lstReturn: any;
  public modulePort = "50001";
  public reconPort = "50004";
  public sourcePort = "50003";
  constructor(private httpClient: HttpClient, private router: Router, 
    // private Util: Util, 
    private CS: CommonService) {
  }

  getLoginstatusFromServer(prminputs) {
    console.log("prminputs",prminputs);
    var resData = CommonService.authReq(this.modulePort+'/modules/login/');
    // var resData = CommonService.authReq('/modules/login/');
    return this.CS.SendToAPI("post", resData, prminputs);
  }

  getLogutUserToServer(prminputs) {
    var resData = CommonService.authReq(this.modulePort+'/modules/logout/');
    return this.CS.SendToAPI("post", resData, prminputs);
  }

  getModuleListFromServer(prminputs) {
    var resData = CommonService.authReq(this.modulePort+'/modules/user_rights/');
    return this.CS.SendToAPI("post", resData, prminputs);
  }

  getModelListFromServer(prminputs) {
    var resData = CommonService.authReq(this.modulePort+'/modules/user_credentials/');
    return this.CS.SendToAPI("post", resData, prminputs);
  }

  getTransactionCountFromServer(prminputs){
    var resData = CommonService.authReq(this.reconPort+'/recon/get_transaction_count/');
    return this.CS.SendToAPI("post", resData, prminputs);
  }

  getProcessingLayerListFromServer(prminputs){
    var resData = CommonService.authReq(this.sourcePort+'/source/get_processing_layer_list/');
    return this.CS.SendToAPI("post", resData, prminputs);
  }

  getTransactionRecordsFromServer(prminputs){
    var resData = CommonService.authReq(this.reconPort+'/recon/get_transaction_records/');
    return this.CS.SendToAPI("post", resData, prminputs);
  }

  getIntExtRecordsFromServer(prminputs){
    var resData = CommonService.authReq(this.reconPort+'/recon/get_int_ext_transactions/');
    return this.CS.SendToAPI("post", resData, prminputs);
  }

  sendUnMatchedToMatchToServer(prminputs){
    var resData = CommonService.authReq(this.reconPort+'/recon/get_update_unmatched_matched/');
    return this.CS.SendToAPI("post", resData, prminputs);
  }

  sendMatchedToUnMatchToServer(prminputs){
    var resData = CommonService.authReq(this.reconPort+'/recon/get_update_matched_unmatched/');
    return this.CS.SendToAPI("post", resData, prminputs);
  }

  getGroupIdTransactionsFromServer(prminputs){
    var resData = CommonService.authReq(this.reconPort+'/recon/get_group_id_transactions/');
    return this.CS.SendToAPI("post", resData, prminputs);
  }

  setGroupMatchedToUnMatchToServer(prminputs){
    var resData = CommonService.authReq(this.reconPort+'/recon/get_update_group_records_unmatched/');
    return this.CS.SendToAPI("post", resData, prminputs);
  }

  sendUnmatchedToContraToServer(prminputs){
    var resData = CommonService.authReq(this.reconPort+'/recon/get_update_contra/');
    return this.CS.SendToAPI("post", resData, prminputs);
  }

  getSelectedContraRecordsFromServer(prminputs){
    let resData = CommonService.authReq(this.reconPort+'/recon/get_selected_contra_records/');
    return this.CS.SendToAPI("post", resData, prminputs);
  }

  getInternalExternalHeadersFromServer(prminputs){
    let resData = CommonService.authReq(this.reconPort+'/recon/get_internal_external_headers/');
    return this.CS.SendToAPI("post", resData, prminputs);
  }

  setContraMatchedToUnMatchedToServer(prminputs){
    let resData = CommonService.authReq(this.reconPort+'/recon/get_unmatch_matched_contra/');
    return this.CS.SendToAPI("post", resData, prminputs);
  }

  getBrsReportFromServer(prminputs){
    let resData = CommonService.authReq(this.reconPort+'/recon/get_brs_report/');
    return this.CS.SendToAPI("post", resData, prminputs);
  }

  getMonthCloseMonthsFromServer(prminputs){
    let resData = CommonService.authReq(this.reconPort+'/recon/get_month_close/');
    return this.CS.SendToAPI("post", resData, prminputs);
  }

  sendMonthCloseDateToServer(prminputs){
    let resData = CommonService.authReq(this.reconPort+'/recon/approve_month_close/');
    return this.CS.SendToAPI("post", resData, prminputs);
  }

  getBrsConsolidationReportFromServer(prminputs){
    let resData = CommonService.authReq(this.reconPort+'/recon/get_consolidation_report/');
    return this.CS.SendToAPI("post", resData, prminputs);
  }
}
