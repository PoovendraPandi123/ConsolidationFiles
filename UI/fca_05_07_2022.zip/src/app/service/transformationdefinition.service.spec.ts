import { TestBed } from '@angular/core/testing';

import { TransformationdefinitionService } from './transformationdefinition.service';

describe('TransformationdefinitionService', () => {
  let service: TransformationdefinitionService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(TransformationdefinitionService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
