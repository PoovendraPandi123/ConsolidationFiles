import { Injectable } from '@angular/core';
import { ApiCallService } from './api-call.service';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ConsolFilesProcessService {

  public port : string = '50012';

  constructor(private http: HttpClient) { }

  public getValidateDataFromServer(prminputs : any) : any {
    var resData = ApiCallService.authRequest(this.port+`/api/v1/consol_files/generic/file_uploads/?tenants_id=${prminputs["tenants_id"]}&groups_id=${prminputs["groups_id"]}&entities_id=${prminputs["entities_id"]}&m_processing_layer_id=${prminputs["m_processing_layer_id"]}&m_processing_sub_layer_id=${prminputs["m_processing_sub_layer_id"]}&processing_layer_id=${prminputs["processing_layer_id"]}&sources_id=${prminputs["sources_id"]}&is_active=${prminputs["is_active"]}&status=${prminputs["status"]}`);
    return this.http.get(resData["url"], resData["headers"]);
  }
}
