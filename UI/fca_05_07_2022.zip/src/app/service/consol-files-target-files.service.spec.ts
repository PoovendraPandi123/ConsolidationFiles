import { TestBed } from '@angular/core/testing';

import { ConsolFilesTargetFilesService } from './consol-files-target-files.service';

describe('ConsolFilesTargetFilesService', () => {
  let service: ConsolFilesTargetFilesService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ConsolFilesTargetFilesService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
