import { Injectable } from '@angular/core';
import { CommonService } from './common.service';

@Injectable({
  providedIn: 'root'
})
export class AlcsOperationService {

  public alcsPort = "50010";

  constructor(private CS: CommonService) { }

  public getProcessingLayerListFromServer() : any {
    return [
      {"processing_layer_id": "400", "processing_layer_name": "AXIS-RECON"},
      {"processing_layer_id": "401", "processing_layer_name": "ICICI-RECON"},
      {"processing_layer_id": "402", "processing_layer_name": "SBI-RECON"},
      {"processing_layer_id": "403", "processing_layer_name": "HDFC-RECON"},
      {"processing_layer_id": "404", "processing_layer_name": "HDFC-NEFT-RECON"},
      {"processing_layer_id": "405", "processing_layer_name": "ICICI-NEFT-RECON"}
    ];
  }

  public getTransactionCountFromServer(prminputs) : any {
    var resData = CommonService.authReq(this.alcsPort+'/api/v1/alcs/common/get_transaction_count/');
    return this.CS.SendFileToAPI("post", resData, prminputs);
  }

  public getTransactionRecordsFromServer(prminputs) : any {
    var resData = CommonService.authReq(this.alcsPort+'/api/v1/alcs/common/get_transaction_records/');
    return this.CS.SendFileToAPI("post", resData, prminputs);
  }

  public getIntUnMatchedDateRecordsFromServer(prminputs) : any {
    var resData = CommonService.authReq(this.alcsPort+'/api/v1/alcs/common/get_internal_transaction_records/');
    return this.CS.SendFileToAPI("post", resData, prminputs);
  }

  public getUpdateUnMatchedTransactionsToServer(prminputs) : any {
    var resData = CommonService.authReq(this.alcsPort+'/api/v1/alcs/common/get_update_unmatched_transactions/');
    return this.CS.SendFileToAPI("post", resData, prminputs);
  }
  
  public getUpdateLetterNumbersToServer(prminputs) : any {
    var resData = CommonService.authReq(this.alcsPort+'/api/v1/alcs/common/get_update_letter_numbers/');
    return this.CS.SendFileToAPI("post", resData, prminputs);
  }

  public getUpdateRejectAllTransactionsToServer(prminputs) : any {
    var resData = CommonService.authReq(this.alcsPort+'/api/v1/alcs/common/get_update_reject_all_transactions/');
    return this.CS.SendFileToAPI("post", resData, prminputs);
  }

}
