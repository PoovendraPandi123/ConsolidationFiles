import { TestBed } from '@angular/core/testing';

import { AlcsOperationService } from './alcs-operation.service';

describe('AlcsOperationService', () => {
  let service: AlcsOperationService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AlcsOperationService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
