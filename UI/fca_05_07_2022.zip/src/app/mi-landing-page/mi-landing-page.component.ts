import { Component, OnInit, ViewChild } from '@angular/core';
import { ChartType} from 'chart.js';
import { HttpClient  } from '@angular/common/http';
import { AuthService } from '../service/mi.auth.service';
import { NgxUiLoaderService } from "ngx-ui-loader"; // Import NgxUiLoaderService

@Component({
  selector: 'app-mi-landing-page',
  templateUrl: './mi-landing-page.component.html',
  styleUrls: ['./mi-landing-page.component.css']
})
export class MiLandingPageComponent implements OnInit {

  public userModelList: any;
  public userId: any;
  public tenantId: any;
  public groupId: any;
  public entityId: any;
  public mProcessingLayerId: any;
  public mProcessingSubLayerId: any;
  public insurerType: any;
  public insuranceType: any;
  public fromDate: any;
  public processingLayerIdsUser: any;
  public doughnutChartData: any;
  public doughnutChartLabels = [] as any;
  public doughnutChartOptions: any;
  public doughnutChartLegend: any;
  public doughnutColorOptions: any;
  public doughnutChartType: ChartType = 'doughnut';
  public pieChartData: any;
  public pieChartLabels = [] as any;
  public pieChartOptions: any;
  public pieChartLegend: any;
  public pieColorOptions: any;
  public pieChartType: ChartType = 'pie';
  public barChartData: any;
  public barChartLabels = [] as any;
  public barChartOptions: any;
  public barChartLegend: any;
  public barColorOptions: any;
  public barChartType: ChartType = 'bar';
  public displayMiChart:boolean = false;
  public displayMiPieChart:boolean = false;
  public displayMiBarChart:boolean = false;
  public insuerId: any;
  public insurerList: any;
  public clientId: any;
  public clientList: any;
  public clientType: any;

  constructor(public http:HttpClient, public obj_auth_service: AuthService, public ngxService: NgxUiLoaderService) { }

  ngOnInit(): void {
    this.ngxService.start();
    this.userModelList = JSON.parse(sessionStorage.getItem("user_model_list"));
    this.userId = JSON.parse(sessionStorage.getItem("user_details"))["user_id"];
    this.tenantId = this.userModelList["tenant_id"];
    this.groupId = this.userModelList["group_id"];
    this.entityId = this.userModelList["entity_id"];
    this.mProcessingLayerId = this.userModelList["m_processing_layer_id"];
    this.mProcessingSubLayerId = this.userModelList["m_processing_sub_layer_id"];
    this.processingLayerIdsUser = this.userModelList["processing_layer_ids"];
    this.insuranceType = "Empty";
    this.fromDate = "Empty";
    this.insuerId = 0;
    this.insurerType = {
      "m_insurer_id": 0
    }
    this.clientId = 0;
    this.clientType = {
      "m_client_details_id" : 0
    }

    this.getInsurerList();
    // this.getMiDashboard();
    this.ngxService.stop();
  };

  getInsurerList()
  {
    this.ngxService.start();

    let data = {
      "tenantId" : this.tenantId,
      "groupId" : this.groupId,
      "entityId" : this.entityId,
      "mProcessingLayerId" : this.mProcessingLayerId,
      "mProcessingSubLayerId" : this.mProcessingSubLayerId
    }

    this.obj_auth_service.getInsurerListFromServer(data)
    .subscribe(
      received_data => {
        let response_data = received_data["data"]["insurer_list"]["data"];
        this.insurerList = response_data;
        this.ngxService.stop();
      }
    )
  }

  getClientList()
  {
    this.ngxService.start();

    let data = {
      "tenantId" : this.tenantId,
      "groupId" : this.groupId,
      "entityId" : this.entityId,
      "mProcessingLayerId" : this.mProcessingLayerId,
      "mProcessingSubLayerId" : this.mProcessingSubLayerId,
      "mInsurerId" : this.insuerId
    }

    this.obj_auth_service.getClientListFromServer(data)
    .subscribe(
      receivedData => {
        let responseData = receivedData["data"]["client_list"]["data"];
        this.clientList = responseData;
        this.ngxService.stop();
      }
    )
  }

  searchClick()
  {
    if(this.insuerId === 0)
    {
      alert("Kindly Choose Insurance Company!!!");
    }
    else if (this.clientId === 0)
    {
      alert("Please choose the Client for the Insurance Company Chosen!!!");
    }
    else if(this.fromDate === "Empty")
    {
      alert("Kindly Choose the Insurance Month!!!");
    }
    else
    {
      this.getMiDashboard();
      this.getActiveInactiveDashboard();
      this.getClientDashbaord();
    }
  }

  getMiDashboard()
  {
    this.ngxService.start();
    let data = {
      "tenantId" : this.tenantId,
      "groupId" : this.groupId,
      "entityId" : this.entityId,
      "mProcessingLayerId" : this.mProcessingLayerId,
      "mProcessingSubLayerId" : this.mProcessingSubLayerId,
      "insurerId": this.insuerId,
      "clientId": this.clientId,
      "chosenDate": this.fromDate
    }
    this.obj_auth_service.getMiDashboardDataFromServer(data)
    .subscribe(
      received_data => {
        this.displayMiChart = true;
        let response_data = received_data["data"];
        this.doughnutChartLabels = response_data["label"];
        this.doughnutChartData = [
          {
            data : response_data["data"]
          }
        ];

        this.doughnutChartOptions = {
          scaleShowVerticalLines: false,
          responsive: true,
          title : {
            display : true,
            text : "Count of Insurance Recon Categories",
            fontSize : 16,
            fontColor : '#004e98',
          },
          legend : {
            position : "right",
            display : true
          }
        };

        // console.log(response_data);

        this.ngxService.stop();
      }
    )
  }

  getActiveInactiveDashboard()
  {
    this.ngxService.start();
    let data = {
      "tenantId" : this.tenantId,
      "groupId" : this.groupId,
      "entityId" : this.entityId,
      "mProcessingLayerId" : this.mProcessingLayerId,
      "mProcessingSubLayerId" : this.mProcessingSubLayerId,
      "insurerId": this.insuerId,
      "clientId": this.clientId,
      "chosenDate": this.fromDate
    }
    this.obj_auth_service.getActiveInactiveValuesFromServer(data)
    .subscribe(
      received_data => {
        console.log(received_data);
        this.displayMiPieChart = true;
        let response_data = received_data["data"];
        console.log(response_data);
        this.pieChartLabels = response_data["label"];
        this.pieChartData = [
          {
            data : response_data["data"]
          }
        ];

        this.pieChartOptions = {
          scaleShowVerticalLines: false,
          responsive: true,
          title : {
            display : true,
            text : "Active And Inactive Employees Count",
            fontSize : 16,
            fontColor : '#004e98',
          },
          legend : {
            position : "right",
            display : true
          }
        };

        this.ngxService.stop();
      }
    )
  }

  getClientDashbaord()
  {
    this.ngxService.start();
    let data = {
      "tenantId" : this.tenantId,
      "groupId" : this.groupId,
      "entityId" : this.entityId,
      "mProcessingLayerId" : this.mProcessingLayerId,
      "mProcessingSubLayerId" : this.mProcessingSubLayerId,
      "insurerId": this.insuerId,
      "clientId": this.clientId,
      "chosenDate": this.fromDate
    }
    this.obj_auth_service.getClientValuesFromServer(data)
    .subscribe(
      received_data => {
        console.log(received_data);
        this.displayMiBarChart = true;
        let response_data = received_data["data"];
        console.log(response_data);
        this.barChartLabels = response_data["label"];
        this.barChartData = [
          {
            data : response_data["data"]
          }
        ];

        this.barChartOptions = {
          scaleShowVerticalLines: false,
          responsive: true,
          title : {
            display : true,
            text : "TOP 10 Client for an Insurer",
            fontSize : 16,
            fontColor : '#004e98',
          },
          legend : {
            position : "right",
            display : false
          }
        };

        this.barColorOptions = [
          {
            backgroundColor: ['#547caf', '#547caf', '#547caf', '#547caf', '#547caf', '#547caf', '#547caf', '#547caf', '#547caf', '#547caf']
          }
        ];

        this.ngxService.stop();
      }
    )
  }

  getInsuerType(m_insurer_id)
  {
    this.insuerId = m_insurer_id;
    this.getClientList();
  };

  getClientChange(m_client_details_id)
  {
    this.clientId = m_client_details_id;
  }

}
