import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MiLandingPageComponent } from './mi-landing-page.component';

describe('MiLandingPageComponent', () => {
  let component: MiLandingPageComponent;
  let fixture: ComponentFixture<MiLandingPageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MiLandingPageComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MiLandingPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
