import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-task-management-landing-page',
  templateUrl: './task-management-landing-page.component.html',
  styleUrls: ['./task-management-landing-page.component.css']
})
export class TaskManagementLandingPageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
