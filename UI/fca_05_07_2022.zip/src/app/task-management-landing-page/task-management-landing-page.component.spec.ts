import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TaskManagementLandingPageComponent } from './task-management-landing-page.component';

describe('TaskManagementLandingPageComponent', () => {
  let component: TaskManagementLandingPageComponent;
  let fixture: ComponentFixture<TaskManagementLandingPageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TaskManagementLandingPageComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TaskManagementLandingPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
