import { Component, OnInit } from '@angular/core';
import { HttpClient  } from '@angular/common/http';
import { AuthService } from '../service/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-side-menu',
  templateUrl: './side-menu.component.html',
  styleUrls: ['./side-menu.component.css']
})
export class SideMenuComponent implements OnInit {

  public opened:boolean = false;
  public userModelList:any;
  public userSection:boolean = false;
  public brsLandingPage:boolean = false;
  public aggregators:boolean = false;
  public source:boolean = false;
  public sourceDefnition:boolean = false;
  public transformationDefinition:boolean = false;
  public proecessigLayerDefinitions:boolean = false;
  public businessLogicLayer:boolean = false;
  public businessLogicLayerDefinition:boolean = false;
  public brsFileUpload:boolean = false;
  public reconOperation:boolean = false;
  public report:boolean = false;
  public monthEndClose:boolean = false;
  public brsConsolidationReport = false;
  public asLandingPage:boolean = false;
  public asReconOperation:boolean = false;
  public asFileUpload:boolean = false;
  public asNationalAccountDetails:boolean = false;
  public asTanReport:boolean = false;
  public asNADReport:boolean = false;
  public asErpTanUpdate:boolean = false;
  public miLandingPage:boolean = false;
  public miFileUpload:boolean = false;
  public miMisPage:boolean = false;
  public miReportAddition:boolean = false;
  public miReportDeletion:boolean = false;
  public miReportExplicit:boolean = false;
  public asNadOpen:boolean = false;
  public miInsurerPage:boolean = false;
  public userDetails:  any;
  public currentUser: string = '';
  public userId: any;
  public ipAddress: any;

  constructor(public http:HttpClient, public obj_service:AuthService, public router: Router) { }

  ngOnInit(): void {
    this.showSideMenu();
    this.userDetails = JSON.parse(sessionStorage.getItem("user_details"));
    this.currentUser = this.userDetails["user_name"];
    this.userId = this.userDetails["user_id"];
    this.ipAddress = this.userDetails["system_ip"];
    let mProcessingSubLayerId = this.userModelList["m_processing_sub_layer_id"];
    // if(mProcessingSubLayerId == 9)
    // {
    //   this.router.navigate(['/SideMenu/AlcsFileUpload']);
    // };
  }

  toggle(){
    this.opened = ! this.opened;
  }

  toggleUser(){
    this.userSection = ! this.userSection;
  }

  showSideMenu(){
    this.userModelList = JSON.parse(sessionStorage.getItem("user_model_list"));
    console.log("User Model List", this.userModelList);
  }

  loadOriginalComponent(urlPath){
    this.opened = false;
    if (urlPath === "BrsLandingPage")
    {
      this.brsLandingPage = true;
      this.aggregators = false;
      this.source = false;
      this.sourceDefnition = false;
      this.transformationDefinition = false;
      this.proecessigLayerDefinitions = false;
      this.businessLogicLayer = false;
      this.businessLogicLayerDefinition = false;
      this.brsFileUpload = false;
      this.reconOperation = false;
      this.report = false;
      this.monthEndClose = false;
      this.brsConsolidationReport = false;
      this.asLandingPage = false;
      this.asReconOperation = false;
      this.asFileUpload = false;
      this.asNationalAccountDetails = false;
      this.asTanReport = false;
      this.asNADReport = false;
      this.asErpTanUpdate = false;
      this.asNadOpen = false;
      this.miLandingPage = false;
      this.miFileUpload = false;
      this.miMisPage = false;
      this.miReportAddition = false;
      this.miReportDeletion = false;
      this.miReportExplicit = false;
      this.miInsurerPage = false;
    }
    else if(urlPath === "Aggregators")
    {
      this.brsLandingPage = false;
      this.aggregators = true;
      this.source = false;
      this.sourceDefnition = false;
      this.transformationDefinition = false;
      this.proecessigLayerDefinitions = false;
      this.businessLogicLayer = false;
      this.businessLogicLayerDefinition = false;
      this.brsFileUpload = false;
      this.reconOperation = false;
      this.report = false;
      this.monthEndClose = false;
      this.brsConsolidationReport = false;
      this.asLandingPage = false;
      this.asReconOperation = false;
      this.asFileUpload = false;
      this.asNationalAccountDetails = false;
      this.asTanReport = false;
      this.asNADReport = false;
      this.asErpTanUpdate = false;
      this.asNadOpen = false;
      this.miLandingPage = false;
      this.miFileUpload = false;
      this.miMisPage = false;
      this.miReportAddition = false;
      this.miReportDeletion = false;
      this.miReportExplicit = false;
      this.miInsurerPage = false;
    }
    else if(urlPath === "BrsSource" || urlPath === "ConsolidationSource")
    {
      this.brsLandingPage = false;
      this.aggregators = false;
      this.source = true;
      this.sourceDefnition = false;
      this.transformationDefinition = false;
      this.proecessigLayerDefinitions = false;
      this.businessLogicLayer = false;
      this.businessLogicLayerDefinition = false;
      this.brsFileUpload = false;
      this.reconOperation = false;
      this.report = false;
      this.monthEndClose = false;
      this.brsConsolidationReport = false;
      this.asLandingPage = false;
      this.asReconOperation = false;
      this.asFileUpload = false;
      this.asNationalAccountDetails = false;
      this.asTanReport = false;
      this.asNADReport = false;
      this.asErpTanUpdate = false;
      this.asNadOpen = false;
      this.miLandingPage = false;
      this.miFileUpload = false;
      this.miMisPage = false;
      this.miReportAddition = false;
      this.miReportDeletion = false;
      this.miReportExplicit = false;
      this.miInsurerPage = false;
    }
    else if(urlPath === "BrsSourcedefinition" || urlPath === "ConsolidationSourceDefinition")
    {
      this.brsLandingPage = false;
      this.aggregators = false;
      this.source = false;
      this.sourceDefnition = true;
      this.transformationDefinition = false;
      this.proecessigLayerDefinitions = false;
      this.businessLogicLayer = false;
      this.businessLogicLayerDefinition = false;
      this.brsFileUpload = false;
      this.reconOperation = false;
      this.report = false;
      this.monthEndClose = false;
      this.brsConsolidationReport = false;
      this.asLandingPage = false;
      this.asReconOperation = false;
      this.asFileUpload = false;
      this.asNationalAccountDetails = false;
      this.asTanReport = false;
      this.asNADReport = false;
      this.asErpTanUpdate = false;
      this.asNadOpen = false;
      this.miLandingPage = false;
      this.miFileUpload = false;
      this.miMisPage = false;
      this.miReportAddition = false;
      this.miReportDeletion = false;
      this.miReportExplicit = false;
      this.miInsurerPage = false;
    }
    else if(urlPath === "BrsTransformationDefinition")
    {
      this.brsLandingPage = false;
      this.aggregators = false;
      this.source = false;
      this.sourceDefnition = false;
      this.transformationDefinition = true;
      this.proecessigLayerDefinitions = false;
      this.businessLogicLayer = false;
      this.businessLogicLayerDefinition = false;
      this.brsFileUpload = false;
      this.reconOperation = false;
      this.report = false;
      this.monthEndClose = false;
      this.brsConsolidationReport = false;
      this.asLandingPage = false;
      this.asReconOperation = false;
      this.asFileUpload = false;
      this.asNationalAccountDetails = false;
      this.asTanReport = false;
      this.asNADReport = false;
      this.asErpTanUpdate = false;
      this.asNadOpen = false;
      this.miLandingPage = false;
      this.miFileUpload = false;
      this.miMisPage = false;
      this.miReportAddition = false;
      this.miReportDeletion = false;
      this.miReportExplicit = false;
      this.miInsurerPage = false;
    }
    else if(urlPath === "BrsProcessingLayerDefinition")
    {
      this.brsLandingPage = false;
      this.aggregators = false;
      this.source = false;
      this.sourceDefnition = false;
      this.transformationDefinition = false;
      this.proecessigLayerDefinitions = true;
      this.businessLogicLayer = false;
      this.businessLogicLayerDefinition = false;
      this.brsFileUpload = false;
      this.reconOperation = false;
      this.report = false;
      this.monthEndClose = false;
      this.brsConsolidationReport = false;
      this.asLandingPage = false;
      this.asReconOperation = false;
      this.asFileUpload = false;
      this.asNationalAccountDetails = false;
      this.asTanReport = false;
      this.asNADReport = false;
      this.asErpTanUpdate = false;
      this.asNadOpen = false;
      this.miLandingPage = false;
      this.miFileUpload = false;
      this.miMisPage = false;
      this.miReportAddition = false;
      this.miReportDeletion = false;
      this.miReportExplicit = false;
      this.miInsurerPage = false;
    }
    else if(urlPath === "BrsBusinessLogicLayer")
    {
      this.brsLandingPage = false;
      this.aggregators = false;
      this.source = false;
      this.sourceDefnition = false;
      this.transformationDefinition = false;
      this.proecessigLayerDefinitions = false;
      this.businessLogicLayer = true;
      this.businessLogicLayerDefinition = false;
      this.brsFileUpload = false;
      this.reconOperation = false;
      this.report = false;
      this.monthEndClose = false;
      this.brsConsolidationReport = false;
      this.asLandingPage = false;
      this.asReconOperation = false;
      this.asFileUpload = false;
      this.asNationalAccountDetails = false;
      this.asTanReport = false;
      this.asNADReport = false;
      this.asErpTanUpdate = false;
      this.asNadOpen = false;
      this.miLandingPage = false;
      this.miFileUpload = false;
      this.miMisPage = false;
      this.miReportAddition = false;
      this.miReportDeletion = false;
      this.miReportExplicit = false;
      this.miInsurerPage = false;
    }
    else if(urlPath === "BrsBusinessLogicLayerDefinition")
    {
      this.brsLandingPage = false;
      this.aggregators = false;
      this.source = false;
      this.sourceDefnition = false;
      this.transformationDefinition = false;
      this.proecessigLayerDefinitions = false;
      this.businessLogicLayer = false;
      this.businessLogicLayerDefinition = true;
      this.brsFileUpload = false;
      this.reconOperation = false;
      this.report = false;
      this.monthEndClose = false;
      this.brsConsolidationReport = false;
      this.asLandingPage = false;
      this.asReconOperation = false;
      this.asFileUpload = false;
      this.asNationalAccountDetails = false;
      this.asTanReport = false;
      this.asNADReport = false;
      this.asErpTanUpdate = false;
      this.asNadOpen = false;
      this.miLandingPage = false;
      this.miFileUpload = false;
      this.miMisPage = false;
      this.miReportAddition = false;
      this.miReportDeletion = false;
      this.miReportExplicit = false;
      this.miInsurerPage = false;
    }
    else if(urlPath === "BrsFileUpload")
    {
      this.brsLandingPage = false;
      this.aggregators = false;
      this.source = false;
      this.sourceDefnition = false;
      this.transformationDefinition = false;
      this.proecessigLayerDefinitions = false;
      this.businessLogicLayer = false;
      this.businessLogicLayerDefinition = false;
      this.brsFileUpload = true;
      this.reconOperation = false;
      this.report = false;
      this.monthEndClose = false;
      this.brsConsolidationReport = false;
      this.asLandingPage = false;
      this.asReconOperation = false;
      this.asFileUpload = false;
      this.asNationalAccountDetails = false;
      this.asTanReport = false;
      this.asNADReport = false;
      this.asErpTanUpdate = false;
      this.asNadOpen = false;
      this.miLandingPage = false;
      this.miFileUpload = false;
      this.miMisPage = false;
      this.miReportAddition = false;
      this.miReportDeletion = false;
      this.miReportExplicit = false;
      this.miInsurerPage = false;
    }
    else if(urlPath === "BrsReconOperation")
    {
      this.brsLandingPage = false;
      this.aggregators = false;
      this.source = false;
      this.sourceDefnition = false;
      this.transformationDefinition = false;
      this.proecessigLayerDefinitions = false;
      this.businessLogicLayer = false;
      this.businessLogicLayerDefinition = false;
      this.brsFileUpload = false;
      this.reconOperation = true;
      this.report = false;
      this.monthEndClose = false;
      this.brsConsolidationReport = false;
      this.asLandingPage = false;
      this.asReconOperation = false;
      this.asFileUpload = false;
      this.asNationalAccountDetails = false;
      this.asTanReport = false;
      this.asNADReport = false;
      this.asErpTanUpdate = false;
      this.asNadOpen = false;
      this.miLandingPage = false;
      this.miFileUpload = false;
      this.miMisPage = false;
      this.miReportAddition = false;
      this.miReportDeletion = false;
      this.miReportExplicit = false;
      this.miInsurerPage = false;
    }
    else if(urlPath === "BrsReports")
    {
      this.brsLandingPage = false;
      this.aggregators = false;
      this.source = false;
      this.sourceDefnition = false;
      this.transformationDefinition = false;
      this.proecessigLayerDefinitions = false;
      this.businessLogicLayer = false;
      this.businessLogicLayerDefinition = false;
      this.brsFileUpload = false;
      this.reconOperation = false;
      this.report = true;
      this.monthEndClose = false;
      this.brsConsolidationReport = false;
      this.asLandingPage = false;
      this.asReconOperation = false;
      this.asFileUpload = false;
      this.asNationalAccountDetails = false;
      this.asTanReport = false;
      this.asNADReport = false;
      this.asErpTanUpdate = false;
      this.asNadOpen = false;
      this.miLandingPage = false;
      this.miFileUpload = false;
      this.miMisPage = false;
      this.miReportAddition = false;
      this.miReportDeletion = false;
      this.miReportExplicit = false;
      this.miInsurerPage = false;
    }
    else if(urlPath === "BrsMonthEndCycle")
    {
      this.brsLandingPage = false;
      this.aggregators = false;
      this.source = false;
      this.sourceDefnition = false;
      this.transformationDefinition = false;
      this.proecessigLayerDefinitions = false;
      this.businessLogicLayer = false;
      this.businessLogicLayerDefinition = false;
      this.brsFileUpload = false;
      this.reconOperation = false;
      this.report = false;
      this.monthEndClose = true;
      this.brsConsolidationReport = false;
      this.asLandingPage = false;
      this.asReconOperation = false;
      this.asFileUpload = false;
      this.asNationalAccountDetails = false;
      this.asTanReport = false;
      this.asNADReport = false;
      this.asErpTanUpdate = false;
      this.asNadOpen = false;
      this.miLandingPage = false;
      this.miFileUpload = false;
      this.miMisPage = false;
      this.miReportAddition = false;
      this.miReportDeletion = false;
      this.miReportExplicit = false;
      this.miInsurerPage = false;
    }
    else if(urlPath === "BrsConsolidationReport")
    {
      this.brsLandingPage = false;
      this.aggregators = false;
      this.source = false;
      this.sourceDefnition = false;
      this.transformationDefinition = false;
      this.proecessigLayerDefinitions = false;
      this.businessLogicLayer = false;
      this.businessLogicLayerDefinition = false;
      this.brsFileUpload = false;
      this.reconOperation = false;
      this.report = false;
      this.monthEndClose = false;
      this.brsConsolidationReport = true;
      this.asLandingPage = false;
      this.asReconOperation = false;
      this.asFileUpload = false;
      this.asNationalAccountDetails = false;
      this.asTanReport = false;
      this.asNADReport = false;
      this.asErpTanUpdate = false;
      this.asNadOpen = false;
      this.miLandingPage = false;
      this.miFileUpload = false;
      this.miMisPage = false;
      this.miReportAddition = false;
      this.miReportDeletion = false;
      this.miReportExplicit = false;
      this.miInsurerPage = false;
    }
    else if(urlPath === "26ASLandingPage")
    {
      this.brsLandingPage = false;
      this.aggregators = false;
      this.source = false;
      this.sourceDefnition = false;
      this.transformationDefinition = false;
      this.proecessigLayerDefinitions = false;
      this.businessLogicLayer = false;
      this.businessLogicLayerDefinition = false;
      this.brsFileUpload = false;
      this.reconOperation = false;
      this.report = false;
      this.monthEndClose = false;
      this.brsConsolidationReport = false;
      this.asLandingPage = true;
      this.asReconOperation = false;
      this.asFileUpload = false;
      this.asNationalAccountDetails = false;
      this.asTanReport = false;
      this.asNADReport = false;
      this.asErpTanUpdate = false;
      this.asNadOpen = false;
      this.miLandingPage = false;
      this.miFileUpload = false;
      this.miMisPage = false;
      this.miReportAddition = false;
      this.miReportDeletion = false;
      this.miReportExplicit = false;
      this.miInsurerPage = false;
    }
    else if(urlPath === "26ASReconOperation")
    {
      this.brsLandingPage = false;
      this.aggregators = false;
      this.source = false;
      this.sourceDefnition = false;
      this.transformationDefinition = false;
      this.proecessigLayerDefinitions = false;
      this.businessLogicLayer = false;
      this.businessLogicLayerDefinition = false;
      this.brsFileUpload = false;
      this.reconOperation = false;
      this.report = false;
      this.monthEndClose = false;
      this.brsConsolidationReport = false;
      this.asLandingPage = false;
      this.asReconOperation = true;
      this.asFileUpload = false;
      this.asNationalAccountDetails = false;
      this.asTanReport = false;
      this.asNADReport = false;
      this.asErpTanUpdate = false;
      this.asNadOpen = false;
      this.miLandingPage = false;
      this.miFileUpload = false;
      this.miMisPage = false;
      this.miReportAddition = false;
      this.miReportDeletion = false;
      this.miReportExplicit = false;
      this.miInsurerPage = false;
    }
    else if(urlPath === "26ASFileUpload")
    {
      this.brsLandingPage = false;
      this.aggregators = false;
      this.source = false;
      this.sourceDefnition = false;
      this.transformationDefinition = false;
      this.proecessigLayerDefinitions = false;
      this.businessLogicLayer = false;
      this.businessLogicLayerDefinition = false;
      this.brsFileUpload = false;
      this.reconOperation = false;
      this.report = false;
      this.monthEndClose = false;
      this.brsConsolidationReport = false;
      this.asLandingPage = false;
      this.asReconOperation = false;
      this.asFileUpload = true;
      this.asNationalAccountDetails = false;
      this.asTanReport = false;
      this.asNADReport = false;
      this.asErpTanUpdate = false;
      this.asNadOpen = false;
      this.miLandingPage = false;
      this.miFileUpload = false;
      this.miMisPage = false;
      this.miReportAddition = false;
      this.miReportDeletion = false;
      this.miReportExplicit = false;
      this.miInsurerPage = false;
    }
    else if(urlPath === "26ASNationalAccountDetails")
    {
      this.brsLandingPage = false;
      this.aggregators = false;
      this.source = false;
      this.sourceDefnition = false;
      this.transformationDefinition = false;
      this.proecessigLayerDefinitions = false;
      this.businessLogicLayer = false;
      this.businessLogicLayerDefinition = false;
      this.brsFileUpload = false;
      this.reconOperation = false;
      this.report = false;
      this.monthEndClose = false;
      this.brsConsolidationReport = false;
      this.asLandingPage = false;
      this.asReconOperation = false;
      this.asFileUpload = false;
      this.asNationalAccountDetails = true;
      this.asTanReport = false;
      this.asNADReport = false;
      this.asErpTanUpdate = false;
      this.asNadOpen = false;
      this.miLandingPage = false;
      this.miFileUpload = false;
      this.miMisPage = false;
      this.miReportAddition = false;
      this.miReportDeletion = false;
      this.miReportExplicit = false;
      this.miInsurerPage = false;
    }
    else if(urlPath === "26ASTanReport")
    {
      this.brsLandingPage = false;
      this.aggregators = false;
      this.source = false;
      this.sourceDefnition = false;
      this.transformationDefinition = false;
      this.proecessigLayerDefinitions = false;
      this.businessLogicLayer = false;
      this.businessLogicLayerDefinition = false;
      this.brsFileUpload = false;
      this.reconOperation = false;
      this.report = false;
      this.monthEndClose = false;
      this.brsConsolidationReport = false;
      this.asLandingPage = false;
      this.asReconOperation = false;
      this.asFileUpload = false;
      this.asNationalAccountDetails = false;
      this.asTanReport = true;
      this.asNADReport = false;
      this.asErpTanUpdate = false;
      this.asNadOpen = false;
      this.miLandingPage = false;
      this.miFileUpload = false;
      this.miMisPage = false;
      this.miReportAddition = false;
      this.miReportDeletion = false;
      this.miReportExplicit = false;
      this.miInsurerPage = false;
    }
    else if(urlPath === "26ASNADReport")
    {
      this.brsLandingPage = false;
      this.aggregators = false;
      this.source = false;
      this.sourceDefnition = false;
      this.transformationDefinition = false;
      this.proecessigLayerDefinitions = false;
      this.businessLogicLayer = false;
      this.businessLogicLayerDefinition = false;
      this.brsFileUpload = false;
      this.reconOperation = false;
      this.report = false;
      this.monthEndClose = false;
      this.brsConsolidationReport = false;
      this.asLandingPage = false;
      this.asReconOperation = false;
      this.asFileUpload = false;
      this.asNationalAccountDetails = false;
      this.asTanReport = false;
      this.asNADReport = true;
      this.asErpTanUpdate = false;
      this.asNadOpen = false;
      this.miLandingPage = false;
      this.miFileUpload = false;
      this.miMisPage = false;
      this.miReportAddition = false;
      this.miReportDeletion = false;
      this.miReportExplicit = false;
      this.miInsurerPage = false;
    }
    else if(urlPath === "26SASErpTanUpdate")
    {
      this.brsLandingPage = false;
      this.aggregators = false;
      this.source = false;
      this.sourceDefnition = false;
      this.transformationDefinition = false;
      this.proecessigLayerDefinitions = false;
      this.businessLogicLayer = false;
      this.businessLogicLayerDefinition = false;
      this.brsFileUpload = false;
      this.reconOperation = false;
      this.report = false;
      this.monthEndClose = false;
      this.brsConsolidationReport = false;
      this.asLandingPage = false;
      this.asReconOperation = false;
      this.asFileUpload = false;
      this.asNationalAccountDetails = false;
      this.asTanReport = false;
      this.asNADReport = false;
      this.asErpTanUpdate = true;
      this.asNadOpen = false;
      this.miLandingPage = false;
      this.miFileUpload = false;
      this.miMisPage = false;
      this.miReportAddition = false;
      this.miReportDeletion = false;
      this.miReportExplicit = false;
      this.miInsurerPage = false;
    }
    else if(urlPath === "26ASNadOpen")
    {
      this.brsLandingPage = false;
      this.aggregators = false;
      this.source = false;
      this.sourceDefnition = false;
      this.transformationDefinition = false;
      this.proecessigLayerDefinitions = false;
      this.businessLogicLayer = false;
      this.businessLogicLayerDefinition = false;
      this.brsFileUpload = false;
      this.reconOperation = false;
      this.report = false;
      this.monthEndClose = false;
      this.brsConsolidationReport = false;
      this.asLandingPage = false;
      this.asReconOperation = false;
      this.asFileUpload = false;
      this.asNationalAccountDetails = false;
      this.asTanReport = false;
      this.asNADReport = false;
      this.asErpTanUpdate = false;
      this.asNadOpen = true;
      this.miLandingPage = false;
      this.miFileUpload = false;
      this.miMisPage = false;
      this.miReportAddition = false;
      this.miReportDeletion = false;
      this.miReportExplicit = false;
      this.miInsurerPage = false;
    }
    else if(urlPath === "MedInsLandingPage")
    {
      this.brsLandingPage = false;
      this.aggregators = false;
      this.source = false;
      this.sourceDefnition = false;
      this.transformationDefinition = false;
      this.proecessigLayerDefinitions = false;
      this.businessLogicLayer = false;
      this.businessLogicLayerDefinition = false;
      this.brsFileUpload = false;
      this.reconOperation = false;
      this.report = false;
      this.monthEndClose = false;
      this.brsConsolidationReport = false;
      this.asLandingPage = false;
      this.asReconOperation = false;
      this.asFileUpload = false;
      this.asNationalAccountDetails = false;
      this.asTanReport = false;
      this.asNADReport = false;
      this.asErpTanUpdate = false;
      this.asNadOpen = false;
      this.miLandingPage = true;
      this.miFileUpload = false;
      this.miMisPage = false;
      this.miReportAddition = false;
      this.miReportDeletion = false;
      this.miReportExplicit = false;
      this.miInsurerPage = false;
    }
    else if(urlPath === "MedInsFileUpload")
    {
      this.brsLandingPage = false;
      this.aggregators = false;
      this.source = false;
      this.sourceDefnition = false;
      this.transformationDefinition = false;
      this.proecessigLayerDefinitions = false;
      this.businessLogicLayer = false;
      this.businessLogicLayerDefinition = false;
      this.brsFileUpload = false;
      this.reconOperation = false;
      this.report = false;
      this.monthEndClose = false;
      this.brsConsolidationReport = false;
      this.asLandingPage = false;
      this.asReconOperation = false;
      this.asFileUpload = false;
      this.asNationalAccountDetails = false;
      this.asTanReport = false;
      this.asNADReport = false;
      this.asErpTanUpdate = false;
      this.asNadOpen = false;
      this.miLandingPage = false;
      this.miFileUpload = true;
      this.miMisPage = false;
      this.miReportAddition = false;
      this.miReportDeletion = false;
      this.miReportExplicit = false;
      this.miInsurerPage = false;
    }
    else if(urlPath === "MedInsMis")
    {
      this.brsLandingPage = false;
      this.aggregators = false;
      this.source = false;
      this.sourceDefnition = false;
      this.transformationDefinition = false;
      this.proecessigLayerDefinitions = false;
      this.businessLogicLayer = false;
      this.businessLogicLayerDefinition = false;
      this.brsFileUpload = false;
      this.reconOperation = false;
      this.report = false;
      this.monthEndClose = false;
      this.brsConsolidationReport = false;
      this.asLandingPage = false;
      this.asReconOperation = false;
      this.asFileUpload = false;
      this.asNationalAccountDetails = false;
      this.asTanReport = false;
      this.asNADReport = false;
      this.asErpTanUpdate = false;
      this.asNadOpen = false;
      this.miLandingPage = false;
      this.miFileUpload = false;
      this.miMisPage = true;
      this.miReportAddition = false;
      this.miReportDeletion = false;
      this.miReportExplicit = false;
      this.miInsurerPage = false;
    }
    else if(urlPath === "MedInsAddition")
    {
      this.brsLandingPage = false;
      this.aggregators = false;
      this.source = false;
      this.sourceDefnition = false;
      this.transformationDefinition = false;
      this.proecessigLayerDefinitions = false;
      this.businessLogicLayer = false;
      this.businessLogicLayerDefinition = false;
      this.brsFileUpload = false;
      this.reconOperation = false;
      this.report = false;
      this.monthEndClose = false;
      this.brsConsolidationReport = false;
      this.asLandingPage = false;
      this.asReconOperation = false;
      this.asFileUpload = false;
      this.asNationalAccountDetails = false;
      this.asTanReport = false;
      this.asNADReport = false;
      this.asErpTanUpdate = false;
      this.asNadOpen = false;
      this.miLandingPage = false;
      this.miFileUpload = false;
      this.miMisPage = false;
      this.miReportAddition = true;
      this.miReportDeletion = false;
      this.miReportExplicit = false;
      this.miInsurerPage = false;
    }
    else if(urlPath === "MedInsDeletion")
    {
      this.brsLandingPage = false;
      this.aggregators = false;
      this.source = false;
      this.sourceDefnition = false;
      this.transformationDefinition = false;
      this.proecessigLayerDefinitions = false;
      this.businessLogicLayer = false;
      this.businessLogicLayerDefinition = false;
      this.brsFileUpload = false;
      this.reconOperation = false;
      this.report = false;
      this.monthEndClose = false;
      this.brsConsolidationReport = false;
      this.asLandingPage = false;
      this.asReconOperation = false;
      this.asFileUpload = false;
      this.asNationalAccountDetails = false;
      this.asTanReport = false;
      this.asNADReport = false;
      this.asErpTanUpdate = false;
      this.asNadOpen = false;
      this.miLandingPage = false;
      this.miFileUpload = false;
      this.miMisPage = false;
      this.miReportAddition = false;
      this.miReportDeletion = true;
      this.miReportExplicit = false;
      this.miInsurerPage = false;
    }
    else if(urlPath === "MedInsExplicit")
    {
      this.brsLandingPage = false;
      this.aggregators = false;
      this.source = false;
      this.sourceDefnition = false;
      this.transformationDefinition = false;
      this.proecessigLayerDefinitions = false;
      this.businessLogicLayer = false;
      this.businessLogicLayerDefinition = false;
      this.brsFileUpload = false;
      this.reconOperation = false;
      this.report = false;
      this.monthEndClose = false;
      this.brsConsolidationReport = false;
      this.asLandingPage = false;
      this.asReconOperation = false;
      this.asFileUpload = false;
      this.asNationalAccountDetails = false;
      this.asTanReport = false;
      this.asNADReport = false;
      this.asErpTanUpdate = false;
      this.asNadOpen = false;
      this.miLandingPage = false;
      this.miFileUpload = false;
      this.miMisPage = false;
      this.miReportAddition = false;
      this.miReportDeletion = false;
      this.miReportExplicit = true;
      this.miInsurerPage = false;
    }
    else if(urlPath === "MedInsInsurer")
    {
      this.brsLandingPage = false;
      this.aggregators = false;
      this.source = false;
      this.sourceDefnition = false;
      this.transformationDefinition = false;
      this.proecessigLayerDefinitions = false;
      this.businessLogicLayer = false;
      this.businessLogicLayerDefinition = false;
      this.brsFileUpload = false;
      this.reconOperation = false;
      this.report = false;
      this.monthEndClose = false;
      this.brsConsolidationReport = false;
      this.asLandingPage = false;
      this.asReconOperation = false;
      this.asFileUpload = false;
      this.asNationalAccountDetails = false;
      this.asTanReport = false;
      this.asNADReport = false;
      this.asErpTanUpdate = false;
      this.asNadOpen = false;
      this.miLandingPage = false;
      this.miFileUpload = false;
      this.miMisPage = false;
      this.miReportAddition = false;
      this.miReportDeletion = false;
      this.miReportExplicit = false;
      this.miInsurerPage = true;
    }
  }

  closeExpansion(){
    this.opened = false;
    this.userSection = false;
  };

  closeUserSelection(){
    this.userSection = false;
  };

  getLogout()
  {
    let data = {
      "system_ip" : this.ipAddress,
      "user_id" : this.userId
    };

    console.log(data);

    this.obj_service.getLogutUserToServer(data)
    .subscribe(
      receivedData => {
        let responseData = receivedData;
        if (responseData["Status"] === "Success")
        {
          // console.log("User Logged out Successfully!!!");
          alert("User Logged out Successfully!!! ");
          this.router.navigate(["/SignIn"]);
        }
        else if (responseData["Status"] === "Error")
        {
          console.log("Error in Logging Out User!!!");
        };
      },
      (error : any) => {
        this.HandleErrorResponse(error);
      }
    );
  };

  HandleErrorResponse(err: any)
  {
    //  this.objerrhandler.handleError(String(err));
   console.log("Error",err);
  }

}
