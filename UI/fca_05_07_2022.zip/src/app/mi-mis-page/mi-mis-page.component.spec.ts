import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MiMisPageComponent } from './mi-mis-page.component';

describe('MiMisPageComponent', () => {
  let component: MiMisPageComponent;
  let fixture: ComponentFixture<MiMisPageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MiMisPageComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MiMisPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
