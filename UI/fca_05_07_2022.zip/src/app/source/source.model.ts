export class Source {

    public source_id: number=0;
    public source_name: string='';
    public source_type: string='';
    public delimiter: string= '';
    public source_extension: string= '';
    public sheet_name: string='';
    public password_protected: string='';
    public column_start_row: number=0;
    public database: string='';
    public user_name: string='';
    public password: string='';
    public schema_name: string='';
    public table_name: string='';
    public import_sequence: number=0;


    constructor() {  }

  }