import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AsRecoOperationComponent } from './as-reco-operation.component';

describe('AsRecoOperationComponent', () => {
  let component: AsRecoOperationComponent;
  let fixture: ComponentFixture<AsRecoOperationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AsRecoOperationComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AsRecoOperationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
