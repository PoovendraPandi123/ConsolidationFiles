import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import { ProcessinglayerdefinitionService } from '../service/processinglayerdefinition.service';
import { HttpClient  } from '@angular/common/http';
declare const $: any;

@Component({
  selector: 'app-processing-layer-definitions',
  templateUrl: './processing-layer-definitions.component.html',
  styleUrls: ['./processing-layer-definitions.component.css']
})
export class ProcessingLayerDefinitionsComponent implements OnInit {

  public processinglayerdefinition;
  public processinglayerdefinitionview;
  public userdtl;
  public user;
  public processingdata;
  public processinglayerlist;
  public processinglayermainlist;

  public subtypedata;
  public subtypelist;
  public objprocessinglayerdefinition;
  public aggregatordata;
  public aggregatorlist;
  public doc;
  public processinglist;
  public cardTitle;
  constructor(private router: Router,private objservice:ProcessinglayerdefinitionService,public http:HttpClient) { }


  ngOnInit(): void {

    this.userdtl=JSON.parse(localStorage.getItem('useracess'));
    this.user=JSON.parse(localStorage.getItem('Userdtl'));
    console.log("userdtl",this.user);
    this.processinglayerdefinitionview=false;
    this.objprocessinglayerdefinition={"processing_layer_id":0,"sub_type_id":0,"processing_layer_name":""}
    this.processinglist=[{"side_name":"","aggregator_id":0,"side":""},{"side_name":"","aggregator_id":0,"side":""}];
    
this.getprocessinglayerlist();
this.getaggregatorlist();
  }


  list(){


    this.processinglayerdefinitionview=true;
    // this.getsourcelist();
  
  }
  backlist(){
    this.processinglayerdefinitionview=false;
    // this.objsource= new Source();
  
  }
  cancelEdit(){
    
  }


  getprocessinglayerlist(){
    let Indata={
      "tenant_id": 1,
      "group_id": 1,
      "entity_id": 1,
      "user_id": 1,
      
    }
    console.log("inputprocessing",Indata);
    this.objservice.getprocessinglayerdefinitionFromServer(Indata)
    .subscribe(
    recieveddata  => {
      let tempresponsedata = recieveddata;
      console.log("processinglistresponse---",tempresponsedata)
      this.processingdata=tempresponsedata;
      this.processinglayerlist=this.processingdata.Data;
      // setTimeout(() => {
      //   this.loadData();
      //      }, 300);
    });
  }

  changeprocessinglayer(param){

    let Indata={
      "tenant_id": 1,
      "group_id": 1,
      "entity_id": 1,
      "user_id": 1,
      "processing_layer_id":param
	
    }
    console.log("inputprocessing",Indata);
    this.objservice.getprocessingsubtypeFromServer(Indata)
    .subscribe(
    recieveddata  => {
      let tempresponsedata = recieveddata;
      console.log("processinglistresponse---",tempresponsedata)
      this.subtypedata=tempresponsedata;
      this.subtypelist=this.subtypedata.Data;
      // setTimeout(() => {
      //   this.loadData();
      //      }, 300);
    });
  }

  getaggregatorlist(){
    let Indata={
      "tenant_id": 1,
      "group_id": 1,
      "entity_id": 1,
      "user_id": 1,
      "operation_flag":"AD"              
    }
    console.log("inputaggregator",Indata);
    this.objservice.getaggregatorFromServer(Indata)
    .subscribe(
    recieveddata  => {
      let tempresponsedata = recieveddata;
      console.log("aggregatorlistresponse---",tempresponsedata)
      this.aggregatordata=tempresponsedata;
      this.aggregatorlist=this.aggregatordata.Data;
    });
  }

  saveprocessinglayerdetails(){
    let Indata={
      "tenant_id": 1,
      "group_id": 1,
      "entity_id": 1,
      "user_id": 1,
      "processing_layer_id":this.objprocessinglayerdefinition.processing_layer_id, 
      "name":this.objprocessinglayerdefinition.processing_layer_name,              
      "m_processing_sub_layer_id":this.objprocessinglayerdefinition.sub_type_id,      
      "processing_layer_list":this.processinglist

    }
    console.log("inputsaveprocess",Indata);
    this.objservice.postprocessinglayersFromServer(Indata)
    .subscribe(
    recieveddata  => {
      let tempresponsedata = recieveddata;
      console.log("processlayersaveresponse---",tempresponsedata)
    
    });
  }

  Editprocesslayerdetail(param){

  }

}
