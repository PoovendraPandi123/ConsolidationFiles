export class ModuleList{
    constructor(
        public username: string = ""
    ){};
}