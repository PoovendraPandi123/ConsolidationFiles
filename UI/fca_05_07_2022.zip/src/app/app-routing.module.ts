import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ModulelistComponent } from './modulelist/modulelist.component';
import { PoIssueLandingPageComponent } from './po-issue-landing-page/po-issue-landing-page.component';
import { SideMenuComponent } from './side-menu/side-menu.component';
import { SigninComponent } from './signin/signin.component';
import { TaskManagementLandingPageComponent } from './task-management-landing-page/task-management-landing-page.component';
import { TdsReconLandingPageComponent } from './tds-recon-landing-page/tds-recon-landing-page.component';
import { VendorPaymentsLandingPageComponent } from './vendor-payments-landing-page/vendor-payments-landing-page.component';
import { AlcsFileUploadComponent } from './components/alcs/alcs-file-upload/alcs-file-upload.component';
import { AlcsClientsComponent } from './components/alcs/alcs-clients/alcs-clients.component';
import { AlcsDashboardComponent } from './components/alcs/alcs-dashboard/alcs-dashboard.component';
import { AlcsReportComponent } from './components/alcs/alcs-report/alcs-report.component';
import { AlcsOperationsComponent } from './components/alcs/alcs-operations/alcs-operations.component';
import { ConsolFilesFileUploadComponent } from './components/consolidation-files/consol-files-file-upload/consol-files-file-upload.component';
import { ConsolFilesProcessComponent } from './components/consolidation-files/consol-files-process/consol-files-process.component';
import { ConsolFilesReportComponent } from './components/consolidation-files/consol-files-report/consol-files-report.component';
import { ConsolFilesDraftReportComponent } from './components/consolidation-files/consol-files-draft-report/consol-files-draft-report.component';
import { ConsolFilesDashboardComponent } from './components/consolidation-files/consol-files-dashboard/consol-files-dashboard.component';
import { ConsolFilesSourceComponent } from './components/consolidation-files/consol-files-source/consol-files-source.component';
import { ConsolFilesSourceDefinitionComponent } from './components/consolidation-files/consol-files-source-definition/consol-files-source-definition.component';
import { ConsolFilesTargetFilesComponent } from './components/consolidation-files/consol-files-target-files/consol-files-target-files.component';
import { ConsolFilesTargetMappingComponent } from './components/consolidation-files/consol-files-target-mapping/consol-files-target-mapping.component';
import { VrLandingPageComponent } from './components/recon/vendor-recon/vr-landing-page/vr-landing-page.component';
import { VrFileUploadComponent } from './components/recon/vendor-recon/vr-file-upload/vr-file-upload.component';
import { VrSummaryComponent } from './components/recon/vendor-recon/vr-summary/vr-summary.component';
import { VrPeriodAssignmentComponent } from './components/recon/vendor-recon/vr-period-assignment/vr-period-assignment.component';
import { VrBalanceConfirmationComponent } from './components/recon/vendor-recon/vr-balance-confirmation/vr-balance-confirmation.component';
import { VrVendorMasterComponent } from './components/recon/vendor-recon/vr-vendor-master/vr-vendor-master.component';
import { VrReconReportComponent } from './components/recon/vendor-recon/vr-recon-report/vr-recon-report.component';
import { VrMatchingCommentsComponent } from './components/recon/vendor-recon/vr-matching-comments/vr-matching-comments.component';
import { BrsLandingPageComponent } from './components/recon/bank-recon/brs-landing-page/brs-landing-page.component';
import { BrsFileUploadComponent } from './components/recon/bank-recon/brs-file-upload/brs-file-upload.component';
import { BrsSummaryComponent } from './components/recon/bank-recon/brs-summary/brs-summary.component';
import { BrsReportComponent } from './components/recon/bank-recon/brs-report/brs-report.component';
import { BrsConsolidationReportComponent } from './components/recon/bank-recon/brs-consolidation-report/brs-consolidation-report.component';
import { BrsMonthCloseComponent } from './components/recon/bank-recon/brs-month-close/brs-month-close.component';

const routes: Routes = [
  { path: '', redirectTo: '/SignIn', pathMatch: 'full' },
  {path:'SignIn', component:SigninComponent},
  {path:'ModuleList', component:ModulelistComponent},
  {path:'SideMenu', component:SideMenuComponent},
  {path:'PoLandingPage', component:PoIssueLandingPageComponent},
  {path:'TaskManagementLangingPage', component:TaskManagementLandingPageComponent},
  {path:'VendorPaymentsLandingPage', component:VendorPaymentsLandingPageComponent},
  {path:'TdsLandingPage', component:TdsReconLandingPageComponent},
  {
    path:'SideMenu', component:SideMenuComponent,
    children: [
      {path: 'AlcsFileUpload', component:AlcsFileUploadComponent},
      {path: 'AlcsClients', component:AlcsClientsComponent},
      {path: 'AlcsDashboard', component:AlcsDashboardComponent},
      {path: 'AlcsReport', component:AlcsReportComponent},
      {path: 'AlcsOperations', component:AlcsOperationsComponent},
      {path: 'ConsolidationFileUpload', component:ConsolFilesFileUploadComponent},
      {path: 'ConsolidationProcess', component:ConsolFilesProcessComponent},
      {path: 'ConsolidationReport', component:ConsolFilesReportComponent},
      {path: 'ConsolidationDraftReport', component:ConsolFilesDraftReportComponent},
      {path: 'ConsolFilesDashboard', component:ConsolFilesDashboardComponent},
      {path: 'ConsolidationSource', component:ConsolFilesSourceComponent},
      {path: 'ConsolidationSourceDefinition', component:ConsolFilesSourceDefinitionComponent},
      {path: 'ConsolidationTargetFiles', component:ConsolFilesTargetFilesComponent},
      {path: 'ConsolidationMapping', component:ConsolFilesTargetMappingComponent},
      {path: 'VRLandingPage', component:VrLandingPageComponent},
      {path: 'VRFileUpload', component:VrFileUploadComponent},
      {path: 'VendorReconOperation', component:VrSummaryComponent},
      {path: 'VRPeriodAssignment', component:VrPeriodAssignmentComponent},
      {path: 'VRPBalanceConfirmation', component:VrBalanceConfirmationComponent},
      {path: 'VRVendorMaster', component:VrVendorMasterComponent},
      {path: 'VRVendorReconReport', component:VrReconReportComponent},
      {path: 'VRMatchingComments', component:VrMatchingCommentsComponent},
      {path: 'BrsLandingPage', component:BrsLandingPageComponent},
      {path: 'BrsFileUpload', component:BrsFileUploadComponent},
      {path: 'BrsReconOperation', component:BrsSummaryComponent},
      {path: 'BrsReports', component:BrsReportComponent},
      {path: 'BrsConsolidationReport', component:BrsConsolidationReportComponent},
      {path: 'BrsMonthEndCycle', component:BrsMonthCloseComponent}
    ]
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
